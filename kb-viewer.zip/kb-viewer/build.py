#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 src/ 与 assets/ 打包成单个自包含的 kb-viewer.html(完全离线可用)。

用法:
    python3 build.py                # 内嵌 sample.db 作为示例数据
    python3 build.py --no-sample    # 不内嵌示例数据(文件更小)
"""
import base64
import sys
from pathlib import Path

ROOT = Path(__file__).parent


def read(p):
    return (ROOT / p).read_text(encoding="utf-8")


def read_b64(p):
    return base64.b64encode((ROOT / p).read_bytes()).decode("ascii")


def main():
    with_sample = "--no-sample" not in sys.argv

    tpl = read("src/template.html")
    parts = {
        "%%CSS%%": read("src/style.css"),
        "%%D3%%": read("assets/d3.min.js"),
        "%%SQLJS%%": read("assets/sql-wasm.js"),
        "%%WASM_B64%%": read_b64("assets/sql-wasm.wasm"),
        "%%SAMPLE_B64%%": read_b64("sample.db") if with_sample and (ROOT / "sample.db").exists() else "",
        "%%APP%%": read("src/app.js"),
    }
    # 内联 JS 里如果出现 </script> 会截断页面,构建时直接报错
    for key in ("%%D3%%", "%%SQLJS%%", "%%APP%%"):
        if "</script" in parts[key].lower():
            raise SystemExit("错误:%s 内容包含 </script>,需要先转义" % key)

    out = tpl
    for key, val in parts.items():
        assert key in out, key + " 不在模板中"
        out = out.replace(key, val)

    dst = ROOT / "kb-viewer.html"
    dst.write_text(out, encoding="utf-8")
    print("生成 %s (%.1f MB, 示例数据: %s)" % (
        dst, dst.stat().st_size / 1048576, "内嵌" if parts["%%SAMPLE_B64%%"] else "无"))


if __name__ == "__main__":
    main()
