#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成模拟 winseoffice 扫描结果的测试数据库(结构与 imart-impact/schema.sql 一致)。

只用 Python 标准库。用法:
    python3 make_testdata.py [输出路径, 默认 sample.db]
"""
import random
import sqlite3
import sys

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS files (
    id        INTEGER PRIMARY KEY,
    path      TEXT NOT NULL,
    rel_path  TEXT NOT NULL UNIQUE,
    type      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS nodes (
    id       INTEGER PRIMARY KEY,
    file_id  INTEGER REFERENCES files(id),
    kind     TEXT NOT NULL,
    name     TEXT NOT NULL,
    fqn      TEXT,
    line     INTEGER,
    UNIQUE(kind, fqn)
);
CREATE TABLE IF NOT EXISTS edges (
    id        INTEGER PRIMARY KEY,
    src_id    INTEGER NOT NULL REFERENCES nodes(id),
    dst_id    INTEGER NOT NULL REFERENCES nodes(id),
    kind      TEXT NOT NULL,
    evidence  TEXT,
    line      INTEGER,
    UNIQUE(src_id, dst_id, kind)
);
CREATE TABLE IF NOT EXISTS glossary (
    term_cn      TEXT NOT NULL,
    keyword_code TEXT NOT NULL,
    UNIQUE(term_cn, keyword_code)
);
CREATE INDEX IF NOT EXISTS idx_nodes_name  ON nodes(name);
CREATE INDEX IF NOT EXISTS idx_nodes_kind  ON nodes(kind);
CREATE INDEX IF NOT EXISTS idx_edges_src   ON edges(src_id);
CREATE INDEX IF NOT EXISTS idx_edges_dst   ON edges(dst_id);
CREATE INDEX IF NOT EXISTS idx_files_rel   ON files(rel_path);
"""

# 业务模块:  (英文名, 中文术语, 表, 每模块画面数)
MODULES = [
    ("order",    "受注管理", ["T_ORDER", "T_ORDER_DETAIL", "T_ORDER_HISTORY"], 4),
    ("stock",    "库存管理", ["T_STOCK", "T_STOCK_MOVE"], 3),
    ("member",   "会员管理", ["T_MEMBER", "T_MEMBER_ADDR"], 3),
    ("product",  "商品管理", ["M_PRODUCT", "M_PRODUCT_CATEGORY", "M_PRICE"], 3),
    ("purchase", "采购管理", ["T_PURCHASE", "T_PURCHASE_DETAIL"], 3),
    ("report",   "报表输出", ["T_REPORT_LOG"], 2),
    ("approval", "审批流程", ["T_APPROVAL", "T_APPROVAL_ROUTE"], 3),
    ("master",   "主数据维护", ["M_CODE", "M_DEPT", "M_WAREHOUSE"], 3),
    ("billing",  "结算管理", ["T_INVOICE", "T_PAYMENT"], 3),
    ("batch",    "夜间批处理", ["T_BATCH_LOG"], 2),
]

ACTIONS = ["list", "detail", "search", "regist", "update", "delete", "confirm", "export"]
SQL_VERBS = {"list": "select", "detail": "select", "search": "select",
             "regist": "insert", "update": "update", "delete": "delete",
             "confirm": "update", "export": "select"}


def cap(s):
    return s[0].upper() + s[1:]


def main(out_path):
    rng = random.Random(20260712)
    con = sqlite3.connect(out_path)
    con.executescript(SCHEMA)
    cur = con.cursor()

    def add_file(rel, ftype):
        cur.execute("INSERT OR IGNORE INTO files(path, rel_path, type) VALUES (?,?,?)",
                    ("/opt/winseoffice/src/" + rel, rel, ftype))
        cur.execute("SELECT id FROM files WHERE rel_path=?", (rel,))
        return cur.fetchone()[0]

    def add_node(kind, name, fqn, file_id=None, line=None):
        cur.execute("INSERT OR IGNORE INTO nodes(file_id, kind, name, fqn, line) VALUES (?,?,?,?,?)",
                    (file_id, kind, name, fqn, line))
        cur.execute("SELECT id FROM nodes WHERE kind=? AND fqn=?", (kind, fqn))
        return cur.fetchone()[0]

    def add_edge(src, dst, kind, evidence, line=None):
        cur.execute("INSERT OR IGNORE INTO edges(src_id, dst_id, kind, evidence, line) VALUES (?,?,?,?,?)",
                    (src, dst, kind, evidence, line))

    # ---- 公共层:共通表 / 共通 service / 共通 JSP -------------------------
    f_common_svc = add_file("main/java/jp/co/winseoffice/common/CommonService.java", "java")
    common_svc = add_node("service", "CommonService",
                          "jp.co.winseoffice.common.CommonService", f_common_svc, 18)
    common_methods = {}
    for i, m in enumerate(["getLoginUser", "checkAuthority", "writeAuditLog", "getCodeName"]):
        common_methods[m] = add_node("method", m,
                                     "jp.co.winseoffice.common.CommonService#" + m,
                                     f_common_svc, 40 + i * 25)
        add_edge(common_svc, common_methods[m], "calls", "public ... %s(...)" % m, 40 + i * 25)

    f_common_map = add_file("main/resources/mapper/CommonMapper.xml", "mybatis_xml")
    t_user = add_node("table", "T_USER", "T_USER")
    t_audit = add_node("table", "T_AUDIT_LOG", "T_AUDIT_LOG")
    m_code = None  # M_CODE 由 master 模块创建后回填
    sql_user = add_node("sql", "selectLoginUser", "CommonMapper.selectLoginUser", f_common_map, 12)
    sql_audit = add_node("sql", "insertAuditLog", "CommonMapper.insertAuditLog", f_common_map, 31)
    add_edge(sql_user, t_user, "queries", "SELECT * FROM T_USER WHERE USER_ID = #{userId}", 13)
    add_edge(sql_audit, t_audit, "queries", "INSERT INTO T_AUDIT_LOG (...) VALUES (...)", 32)
    add_edge(common_methods["getLoginUser"], sql_user, "maps_to", "commonMapper.selectLoginUser(userId)", 44)
    add_edge(common_methods["writeAuditLog"], sql_audit, "maps_to", "commonMapper.insertAuditLog(log)", 92)

    f_header = add_file("main/webapp/WEB-INF/jsp/common/header.jsp", "jsp")
    f_footer = add_file("main/webapp/WEB-INF/jsp/common/footer.jsp", "jsp")
    jsp_header = add_node("jsp_page", "header.jsp", "WEB-INF/jsp/common/header.jsp", f_header, 1)
    jsp_footer = add_node("jsp_page", "footer.jsp", "WEB-INF/jsp/common/footer.jsp", f_footer, 1)

    f_common_js = add_file("main/webapp/js/common.js", "js")
    js_common = {}
    for i, fn in enumerate(["showDialog", "postForm", "formatDate"]):
        js_common[fn] = add_node("js_func", fn, "js/common.js#" + fn, f_common_js, 5 + i * 30)

    glossary = [
        ("登录用户", "getLoginUser"), ("权限检查", "checkAuthority"),
        ("审计日志", "T_AUDIT_LOG"), ("用户", "T_USER"),
    ]

    # ---- 各业务模块 ------------------------------------------------------
    tables = {}
    for mod, term_cn, tbls, n_screens in MODULES:
        Mod = cap(mod)
        pkg = "jp.co.winseoffice." + mod

        for t in tbls:
            tables[t] = add_node("table", t, t)
        if mod == "master":
            m_code = tables["M_CODE"]
            add_edge(common_methods["getCodeName"], m_code, "queries",
                     "SELECT CODE_NAME FROM M_CODE WHERE ...", 118)

        f_ctrl = add_file("main/java/jp/co/winseoffice/%s/%sController.java" % (mod, Mod), "java")
        f_svc = add_file("main/java/jp/co/winseoffice/%s/%sService.java" % (mod, Mod), "java")
        f_mapi = add_file("main/java/jp/co/winseoffice/%s/%sMapper.java" % (mod, Mod), "java")
        f_mapx = add_file("main/resources/mapper/%sMapper.xml" % Mod, "mybatis_xml")
        f_js = add_file("main/webapp/js/%s.js" % mod, "js")

        ctrl = add_node("controller", Mod + "Controller", pkg + "." + Mod + "Controller", f_ctrl, 25)
        svc = add_node("service", Mod + "Service", pkg + "." + Mod + "Service", f_svc, 22)
        mapi = add_node("mapper_interface", Mod + "Mapper", pkg + "." + Mod + "Mapper", f_mapi, 15)
        add_edge(ctrl, svc, "calls", "@Autowired private %sService %sService;" % (Mod, mod), 30)
        add_edge(svc, mapi, "calls", "@Autowired private %sMapper %sMapper;" % (Mod, mod), 27)

        glossary.append((term_cn, mod))
        glossary.append((term_cn, tbls[0]))

        acts = ACTIONS[:n_screens * 2]
        for i, act in enumerate(acts):
            line0 = 40 + i * 30
            url = add_node("url", "/%s/%s" % (mod, act), "/%s/%s" % (mod, act))
            cm = add_node("method", act, "%s.%sController#%s" % (pkg, Mod, act), f_ctrl, line0)
            sm = add_node("method", act + Mod, "%s.%sService#%s%s" % (pkg, Mod, act, Mod), f_svc, line0)
            verb = SQL_VERBS[act]
            mm = add_node("mapper_method", verb + Mod + cap(act),
                          "%s.%sMapper#%s%s%s" % (pkg, Mod, verb, Mod, cap(act)), f_mapi, 20 + i * 4)
            sq = add_node("sql", verb + Mod + cap(act),
                          "%sMapper.%s%s%s" % (Mod, verb, Mod, cap(act)), f_mapx, 10 + i * 22)

            add_edge(url, cm, "routes", '@RequestMapping("/%s/%s")' % (mod, act), line0 - 1)
            add_edge(cm, sm, "calls", "%sService.%s%s(form);" % (mod, act, Mod), line0 + 6)
            add_edge(sm, mm, "calls", "%sMapper.%s%s%s(param);" % (mod, verb, Mod, cap(act)), line0 + 9)
            add_edge(mm, sq, "maps_to", '<%s id="%s%s%s">' % (verb, verb, Mod, cap(act)), 10 + i * 22)

            # SQL 访问表:主表 + 偶尔的关联表 / 公共表
            main_tbl = tbls[i % len(tbls)]
            add_edge(sq, tables[main_tbl], "queries",
                     "%s ... %s ..." % (verb.upper(), main_tbl), 11 + i * 22)
            if rng.random() < 0.4 and len(tbls) > 1:
                other = tbls[(i + 1) % len(tbls)]
                add_edge(sq, tables[other], "queries", "JOIN %s ON ..." % other, 12 + i * 22)
            if rng.random() < 0.25:
                add_edge(sq, t_user, "queries", "JOIN T_USER U ON U.USER_ID = ...", 13 + i * 22)

            # 画面系 action 渲染 JSP
            if act in ("list", "detail", "search", "regist", "update"):
                f_jsp = add_file("main/webapp/WEB-INF/jsp/%s/%s_%s.jsp" % (mod, mod, act), "jsp")
                jsp = add_node("jsp_page", "%s_%s.jsp" % (mod, act),
                               "WEB-INF/jsp/%s/%s_%s.jsp" % (mod, mod, act), f_jsp, 1)
                add_edge(cm, jsp, "renders", 'return "%s/%s_%s";' % (mod, mod, act), line0 + 12)
                add_edge(jsp, jsp_header, "includes", '<%%@ include file="../common/header.jsp" %%>', 3)
                add_edge(jsp, jsp_footer, "includes", '<%%@ include file="../common/footer.jsp" %%>', 88)
                # JSP 里的 JS 函数发 ajax 回后端
                jsf = add_node("js_func", "on%s%s" % (Mod, cap(act)),
                               "js/%s.js#on%s%s" % (mod, Mod, cap(act)), f_js, 8 + i * 20)
                add_edge(jsp, jsf, "calls", 'onclick="on%s%s()"' % (Mod, cap(act)), 45)
                ajax_act = acts[(i + 1) % len(acts)]
                ajax_url = add_node("url", "/%s/%s" % (mod, ajax_act), "/%s/%s" % (mod, ajax_act))
                add_edge(jsf, ajax_url, "ajax",
                         "$.ajax({url: '/%s/%s', ...})" % (mod, ajax_act), 12 + i * 20)
                if rng.random() < 0.5:
                    add_edge(jsf, js_common["postForm"], "calls", "postForm(form, url);", 15 + i * 20)
            else:
                # 非画面 action 处理完 forward 回列表
                list_url = add_node("url", "/%s/list" % mod, "/%s/list" % mod)
                add_edge(cm, list_url, "forward",
                         'return "redirect:/%s/list";' % mod, line0 + 12)

            # service 调公共方法
            if act in ("regist", "update", "delete", "confirm"):
                add_edge(sm, common_methods["writeAuditLog"], "calls",
                         "commonService.writeAuditLog(...);", line0 + 10)
            if rng.random() < 0.35:
                add_edge(sm, common_methods["checkAuthority"], "calls",
                         "commonService.checkAuthority(user, ...);", line0 + 8)

    # ---- 模块间的少量真实耦合 -------------------------------------------
    cross = [
        ("OrderService#registOrder", "StockService#updateStock", "下单扣库存"),
        ("OrderService#registOrder", "M_PRODUCT", None),
        ("PurchaseService#registPurchase", "StockService#updateStock", "入库"),
        ("BillingService#registBilling", "T_ORDER", None),
        ("ReportService#listReport", "T_ORDER", None),
        ("ReportService#listReport", "T_STOCK", None),
        ("ApprovalService#confirmApproval", "T_PURCHASE", None),
    ]
    def find(fqn_tail):
        cur.execute("SELECT id FROM nodes WHERE fqn LIKE ?", ("%" + fqn_tail,))
        r = cur.fetchone()
        return r[0] if r else None
    for src_t, dst_t, note in cross:
        s, d = find(src_t), find(dst_t)
        if s and d:
            kind = "calls" if "#" in dst_t else "queries"
            add_edge(s, d, kind, note or ("ref " + dst_t), 77)

    # ---- 少量孤立节点(数据质量检查用) ----------------------------------
    f_legacy = add_file("main/webapp/js/legacy_util.js", "js")
    for i, fn in enumerate(["oldCalc", "unusedHelper", "deprecatedFmt"]):
        add_node("js_func", fn, "js/legacy_util.js#" + fn, f_legacy, 5 + i * 12)
    add_node("table", "T_OLD_MIGRATION", "T_OLD_MIGRATION")
    add_file("main/webapp/css/style.css", "css")  # 无节点的文件

    for term, kw in glossary:
        cur.execute("INSERT OR IGNORE INTO glossary(term_cn, keyword_code) VALUES (?,?)", (term, kw))

    con.commit()
    for t in ("files", "nodes", "edges", "glossary"):
        cur.execute("SELECT COUNT(*) FROM " + t)
        print("%-8s %d" % (t, cur.fetchone()[0]))
    con.close()


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "sample.db")
