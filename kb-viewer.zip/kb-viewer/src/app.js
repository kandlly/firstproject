/* KB Viewer — imart-impact 知识库(SQLite)离线可视化查看器
 * 单文件运行:sql.js(WASM) 在浏览器内读 .db,d3-force 画图谱。
 */
"use strict";

/* ========================= 常量 ========================= */
const KIND_CN = {
  controller: "Controller", service: "Service", mapper_interface: "Mapper接口",
  method: "方法", mapper_method: "Mapper方法", sql: "SQL",
  jsp_page: "JSP页面", url: "URL", table: "数据表", js_func: "JS函数",
};
const EDGE_CN = {
  routes: "路由", renders: "渲染", calls: "调用", maps_to: "映射",
  queries: "查询", includes: "包含", ajax: "AJAX", forward: "转发",
};
/* 需要有源文件的节点类型(url/table 天然无文件) */
const KINDS_NEED_FILE = new Set(["controller", "service", "mapper_interface",
  "method", "mapper_method", "sql", "jsp_page", "js_func"]);

const PALETTE = ["#3987e5", "#199e70", "#c98500", "#008300",
  "#9085e9", "#e66767", "#d55181", "#d95926"];
const OTHER_COLOR = "#62625d";
const DRAW_MAX = 3000;    // 每帧绘制预算:视野内按连接数优先取前 N 个,缩放/平移动态补入

/* ========================= 全局状态 ========================= */
const S = {
  sqljs: null, dbName: "",
  files: [], nodes: [], edges: [], glossary: [],
  nodeById: new Map(), fileById: new Map(),
  adj: new Map(),            // nodeId -> [{e, otherId, dir}]
  comms: [],                 // [{id,label,members,color,size}] 按大小降序
  commOfNode: new Map(),
  // 图谱状态
  sim: null, links: [], transform: null, canvas: null, ctx: null, zoom: null,
  graphBound: false,
  hoverNode: null, selNode: null, neighborIds: null,
  kindOn: new Set(),
  commIso: null,             // 被隔离的社区 id(-1 = "其他社区"合集)
  focusSet: null,            // 子图聚焦(双击邻域 / 影响分析子图)
  byDeg: [],                 // 节点按度数降序(绘制预算的优先顺序)
  shownNodes: [], frame: 0,  // 上一帧实际绘制的节点(命中测试用)
  // 表格状态
  tbl: { t: "nodes", q: "", kind: "", page: 0 },
  // 影响分析状态
  impactRoot: null,
};

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;");

function b64ToU8(b64) {
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

/* ========================= 数据库加载 ========================= */
async function ensureSqlJs() {
  if (!S.sqljs) {
    S.sqljs = await initSqlJs({ wasmBinary: b64ToU8(window.__WASM_B64).buffer });
  }
  return S.sqljs;
}

function q(db, sql) {
  const r = db.exec(sql);
  if (!r.length) return [];
  const { columns, values } = r[0];
  return values.map(row => {
    const o = {};
    columns.forEach((c, i) => { o[c] = row[i]; });
    return o;
  });
}

async function loadDb(u8, name) {
  const SQL = await ensureSqlJs();
  const db = new SQL.Database(u8);
  try {
    const tabs = new Set(q(db, "SELECT name FROM sqlite_master WHERE type='table'").map(r => r.name));
    for (const t of ["files", "nodes", "edges"]) {
      if (!tabs.has(t)) throw new Error("缺少表 " + t + ",这不像是 imart-impact 生成的库");
    }
    S.files = q(db, "SELECT id, path, rel_path, type FROM files");
    S.nodes = q(db, "SELECT id, file_id, kind, name, fqn, line FROM nodes");
    S.edges = q(db, "SELECT id, src_id, dst_id, kind, evidence, line FROM edges");
    S.glossary = tabs.has("glossary") ? q(db, "SELECT term_cn, keyword_code FROM glossary") : [];
  } finally {
    db.close();
  }
  S.dbName = name;
  buildModel();
  $("dbmeta").textContent = name + " — " + S.nodes.length + " 节点 / "
    + S.edges.length + " 边 / " + S.files.length + " 文件";
  $("landing").style.display = "none";
  resetGraphState();
  initGraph();
  renderSidebarStatics();
  renderOverview();
  S.tbl = { t: "nodes", q: "", kind: "", page: 0 };
  renderTables();
  resetImpact();
}

/* ========================= 模型构建 ========================= */
function buildModel() {
  S.nodeById = new Map(S.nodes.map(n => [n.id, n]));
  S.fileById = new Map(S.files.map(f => [f.id, f]));
  S.adj = new Map();
  const add = (id, rec) => {
    if (!S.adj.has(id)) S.adj.set(id, []);
    S.adj.get(id).push(rec);
  };
  for (const e of S.edges) {
    e._dangling = !(S.nodeById.has(e.src_id) && S.nodeById.has(e.dst_id));
    if (e._dangling) continue;
    add(e.src_id, { e, otherId: e.dst_id, dir: "out" });
    add(e.dst_id, { e, otherId: e.src_id, dir: "in" });
  }
  for (const n of S.nodes) {
    n.deg = (S.adj.get(n.id) || []).length;
    n.r = Math.min(3 + Math.sqrt(n.deg) * 1.5, 16);
  }
  detectCommunities();
  S.byDeg = [...S.nodes].sort((a, b) => b.deg - a.deg);
}

/* 标签传播社区检测(无向) */
function detectCommunities() {
  const ids = S.nodes.map(n => n.id);
  const label = new Map(ids.map(id => [id, id]));
  const order = [...ids];
  let seed = 42;
  const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  for (let iter = 0; iter < 30; iter++) {
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
    let changed = 0;
    for (const id of order) {
      const nbrs = S.adj.get(id);
      if (!nbrs || !nbrs.length) continue;
      const cnt = new Map();
      for (const { otherId } of nbrs) {
        const l = label.get(otherId);
        cnt.set(l, (cnt.get(l) || 0) + 1);
      }
      let best = label.get(id), bestC = -1;
      for (const [l, c] of cnt) if (c > bestC || (c === bestC && l < best)) { best = l; bestC = c; }
      if (best !== label.get(id)) { label.set(id, best); changed++; }
    }
    if (changed === 0) break;
  }
  const groups = new Map();
  for (const n of S.nodes) {
    const l = label.get(n.id);
    if (!groups.has(l)) groups.set(l, []);
    groups.get(l).push(n);
  }
  S.comms = [...groups.values()]
    .map(members => ({ members, size: members.length }))
    .sort((a, b) => b.size - a.size);
  S.commOfNode = new Map();
  S.comms.forEach((c, i) => {
    c.id = i;
    c.color = i < PALETTE.length ? PALETTE[i] : OTHER_COLOR;
    const top = [...c.members].sort((a, b) => b.deg - a.deg).slice(0, 2).map(n => n.name);
    c.label = top.join(" / ") || "(空)";
    for (const n of c.members) S.commOfNode.set(n.id, i);
  });
}

function nodeColor(n) {
  const c = S.comms[S.commOfNode.get(n.id)];
  return c ? c.color : OTHER_COLOR;
}

/* ========================= 可见性过滤 ========================= */
function commIsoHides(n) {
  if (S.commIso == null) return false;
  const c = S.commOfNode.get(n.id);
  if (S.commIso === -1) return c < PALETTE.length;   // "其他社区"合集
  return c !== S.commIso;
}

function nodeVisible(n) {
  if (!S.kindOn.has(n.kind)) return false;
  if (commIsoHides(n)) return false;
  if (S.focusSet && !S.focusSet.has(n.id)) return false;
  return true;
}

/* ========================= 图谱视图 ========================= */
function resetGraphState() {
  S.hoverNode = S.selNode = S.neighborIds = null;
  S.commIso = null; S.focusSet = null;
  S.kindOn = new Set([...Object.keys(KIND_CN), ...S.nodes.map(n => n.kind)]);
  if (S.sim) { S.sim.stop(); S.sim = null; }
  $("node-info").innerHTML = '<div class="placeholder">点击图中节点查看详情</div>';
  $("graph-badge").style.display = "none";
}

function initGraph() {
  const canvas = $("graph-canvas");
  S.canvas = canvas;
  S.ctx = canvas.getContext("2d");

  S.links = S.edges.filter(e => !e._dangling)
    .map(e => ({ e, source: e.src_id, target: e.dst_id }));

  S.sim = d3.forceSimulation(S.nodes)
    .force("link", d3.forceLink(S.links).id(d => d.id).distance(36)
      .strength(l => 1 / Math.min(l.source.deg || 1, l.target.deg || 1)))
    .force("charge", d3.forceManyBody().strength(-120).theta(0.9).distanceMax(500))
    .force("x", d3.forceX(0).strength(0.03))
    .force("y", d3.forceY(0).strength(0.03));
  if (S.nodes.length <= 5000) S.sim.force("collide", d3.forceCollide(d => d.r + 1.5));
  else S.sim.alphaDecay(0.05);   // 大图:省掉碰撞力,更快收敛
  S.sim.on("tick", draw);

  if (!S.graphBound) {
    S.graphBound = true;
    S.zoom = d3.zoom().scaleExtent([0.05, 10])
      .on("zoom", (ev) => { S.transform = ev.transform; draw(); });
    d3.select(canvas)
      .call(d3.drag().container(canvas)
        .subject(dragSubject)
        .on("start", dragStart).on("drag", dragMove).on("end", dragEnd))
      .call(S.zoom)
      .on("dblclick.zoom", null);
    canvas.addEventListener("mousemove", onHover);
    canvas.addEventListener("mouseleave", () => { S.hoverNode = null; hideTip(); updateHighlight(); });
    canvas.addEventListener("click", onCanvasClick);
    canvas.addEventListener("dblclick", onCanvasDblClick);
    window.addEventListener("resize", resizeCanvas);
  }
  resizeCanvas();
  const wrap = $("graph-wrap");
  const k = S.nodes.length > 5000 ? 0.35 : 0.7;
  d3.select(canvas).call(S.zoom.transform,
    d3.zoomIdentity.translate(wrap.clientWidth / 2, wrap.clientHeight / 2).scale(k));
}

function resizeCanvas() {
  const wrap = $("graph-wrap");
  const dpr = window.devicePixelRatio || 1;
  const w = wrap.clientWidth, h = wrap.clientHeight;
  if (!w || !h) return;
  S.canvas.width = w * dpr; S.canvas.height = h * dpr;
  S.canvas.style.width = w + "px"; S.canvas.style.height = h + "px";
  draw();
}

function screenToSim(px, py) {
  return S.transform ? S.transform.invert([px, py]) : [px, py];
}

function findNode(px, py) {
  const [x, y] = screenToSim(px, py);
  const rr = 14 / (S.transform ? S.transform.k : 1);
  let best = null, bd = Infinity;
  for (const n of S.shownNodes) {   // 只在实际画出来的节点里命中
    const dx = n.x - x, dy = n.y - y, d = Math.sqrt(dx * dx + dy * dy);
    if (d < Math.max(n.r + 2, rr) && d < bd) { best = n; bd = d; }
  }
  return best;
}

/* d3.drag 的 container 坐标 = 画布屏幕像素;移动时用 clientX 换算,避免依赖 offsetX 的目标元素 */
function dragSubject(ev) {
  return findNode(ev.x, ev.y) || undefined;
}
function dragStart(ev) {
  if (!ev.active) S.sim.alphaTarget(0.25).restart();
  ev.subject.fx = ev.subject.x; ev.subject.fy = ev.subject.y;
  S.canvas.classList.add("dragging");
}
function dragMove(ev) {
  const rect = S.canvas.getBoundingClientRect();
  const [x, y] = screenToSim(ev.sourceEvent.clientX - rect.left, ev.sourceEvent.clientY - rect.top);
  ev.subject.fx = x; ev.subject.fy = y;
}
function dragEnd(ev) {
  if (!ev.active) S.sim.alphaTarget(0);
  ev.subject.fx = null; ev.subject.fy = null;
  S.canvas.classList.remove("dragging");
}

function onHover(ev) {
  if (ev.buttons) return;
  const n = findNode(ev.offsetX, ev.offsetY);
  if (n !== S.hoverNode) { S.hoverNode = n; updateHighlight(); }
  if (n) showTip(ev.clientX, ev.clientY, n); else hideTip();
}
function onCanvasClick(ev) {
  selectNode(findNode(ev.offsetX, ev.offsetY), false);
}
function onCanvasDblClick(ev) {
  const n = findNode(ev.offsetX, ev.offsetY);
  if (!n) { clearFocus(); return; }
  const set = new Set([n.id]);
  for (const { otherId } of S.adj.get(n.id) || []) set.add(otherId);
  setFocus(set, "邻域:" + n.name + "(" + (set.size - 1) + " 个相邻节点)");
  selectNode(n, false);
}

function updateHighlight() {
  const a = S.hoverNode || S.selNode;
  if (a) {
    const ids = new Set([a.id]);
    for (const { otherId } of S.adj.get(a.id) || []) ids.add(otherId);
    S.neighborIds = ids;
  } else S.neighborIds = null;
  draw();
}

function setFocus(set, label) {
  S.focusSet = set;
  setBadge(label, true);
  S.sim.alpha(0.3).restart();
}
function clearFocus() {
  S.focusSet = null;
  $("graph-badge").style.display = "none";
  draw();
}
function setBadge(text, clearable) {
  $("graph-badge-text").textContent = text;
  $("graph-badge-clear").style.display = clearable ? "" : "none";
  $("graph-badge").style.display = "block";
}

function draw() {
  const ctx = S.ctx;
  if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  const w = S.canvas.width / dpr, h = S.canvas.height / dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  const t = S.transform || d3.zoomIdentity;
  ctx.translate(t.x, t.y);
  ctx.scale(t.k, t.k);

  const act = S.hoverNode || S.selNode;
  const nb = S.neighborIds;

  // ---- 视野裁剪 + 绘制预算 ----
  // 每帧只画视野内的节点,超过 DRAW_MAX 时按连接数取前 N 个;
  // 选中/悬停节点及其邻居永远保留。平移/缩放时动态重算,所以
  // 放大到某个区域,该区域的低连接数节点会自动补进来。
  const pad = 30 / t.k;
  const x0 = -t.x / t.k - pad, y0 = -t.y / t.k - pad;
  const x1 = (w - t.x) / t.k + pad, y1 = (h - t.y) / t.k + pad;
  const inView = n => n.x >= x0 && n.x <= x1 && n.y >= y0 && n.y <= y1;
  const frame = ++S.frame;
  const shown = S.shownNodes = [];
  if (act && nb) {
    for (const id of nb) {
      const n = S.nodeById.get(id);
      if (n && nodeVisible(n) && inView(n)) { n._f = frame; shown.push(n); }
    }
  }
  let visTotal = shown.length;
  for (const n of S.byDeg) {
    if (n._f === frame || !nodeVisible(n) || !inView(n)) continue;
    visTotal++;
    if (shown.length < DRAW_MAX) { n._f = frame; shown.push(n); }
  }
  updateLodInfo(shown.length, visTotal);

  // ---- 边(按样式分三批,一次 stroke) ----
  ctx.lineWidth = 1 / t.k;
  const pNormal = new Path2D(), pHot = new Path2D(), pFaint = new Path2D();
  for (const l of S.links) {
    const s = l.source, d = l.target;
    if (s._f !== frame || d._f !== frame) continue;
    let p = pNormal;
    if (act) p = (s.id === act.id || d.id === act.id) ? pHot : pFaint;
    p.moveTo(s.x, s.y);
    p.lineTo(d.x, d.y);
  }
  ctx.strokeStyle = "rgba(255,255,255,0.09)"; ctx.stroke(pNormal);
  ctx.strokeStyle = "rgba(255,255,255,0.03)"; ctx.stroke(pFaint);
  ctx.strokeStyle = "rgba(255,255,255,0.45)"; ctx.stroke(pHot);

  // ---- 节点(按 颜色×是否淡化 分组批量填充) ----
  const groups = new Map();
  for (const n of shown) {
    const dimmed = act && nb && !nb.has(n.id);
    const key = nodeColor(n) + (dimmed ? "|d" : "|n");
    let p = groups.get(key);
    if (!p) groups.set(key, p = new Path2D());
    p.moveTo(n.x + n.r, n.y);
    p.arc(n.x, n.y, n.r, 0, 2 * Math.PI);
  }
  for (const [key, p] of groups) {
    const [color, mode] = key.split("|");
    ctx.globalAlpha = mode === "d" ? 0.15 : 1;
    ctx.fillStyle = color;
    ctx.fill(p);
  }
  ctx.globalAlpha = 1;
  if (S.selNode && S.selNode._f === frame) {
    ctx.lineWidth = 2 / t.k;
    ctx.strokeStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(S.selNode.x, S.selNode.y, S.selNode.r, 0, 2 * Math.PI);
    ctx.stroke();
  }

  // ---- 标签:屏幕半径够大、或属于高亮邻域时显示(最多 80 个) ----
  ctx.font = (11 / t.k) + "px system-ui, sans-serif";
  ctx.textBaseline = "middle";
  let nLabels = 0;
  for (const n of shown) {
    const inNb = nb && nb.has(n.id);
    if (!(n.r * t.k >= 8 || inNb)) continue;
    if (act && nb && !inNb) continue;
    ctx.fillStyle = inNb ? "rgba(255,255,255,0.95)" : "rgba(195,194,183,0.75)";
    ctx.fillText(n.name, n.x + n.r + 3 / t.k, n.y);
    if (++nLabels >= 80) break;
  }
}

function updateLodInfo(shownCount, visTotal) {
  const el = $("lod-info");
  if (visTotal > shownCount) {
    const txt = "视野内 " + visTotal + " 个节点,按连接数显示前 " + shownCount + " 个 · 放大可看到更多";
    if (el.textContent !== txt) el.textContent = txt;
    el.style.display = "block";
  } else {
    el.style.display = "none";
  }
}

function showTip(cx, cy, n) {
  const f = S.fileById.get(n.file_id);
  const tip = $("tooltip");
  tip.innerHTML =
    '<div class="t-name">' + esc(n.name) + ' <span class="kbadge">' + esc(KIND_CN[n.kind] || n.kind) + "</span></div>"
    + '<div class="t-sub">' + esc(n.fqn || "") + "</div>"
    + (f ? '<div class="t-sub">' + esc(f.rel_path) + (n.line ? ":" + n.line : "") + "</div>" : "")
    + '<div class="t-sub">连接数 ' + n.deg + " · " + esc(commName(n)) + "</div>";
  tip.style.display = "block";
  tip.style.left = Math.min(cx + 14, window.innerWidth - 360) + "px";
  tip.style.top = Math.min(cy + 14, window.innerHeight - 130) + "px";
}
function hideTip() { $("tooltip").style.display = "none"; }
function commName(n) {
  const c = S.comms[S.commOfNode.get(n.id)];
  if (!c) return "";
  return c.id < PALETTE.length ? "社区 " + (c.id + 1) + ":" + c.label : "其他社区";
}

function zoomToNode(n, k) {
  const wrap = $("graph-wrap");
  const kk = k || Math.max(S.transform ? S.transform.k : 1, 1.4);
  d3.select(S.canvas).transition().duration(600).call(
    S.zoom.transform,
    d3.zoomIdentity.translate(wrap.clientWidth / 2, wrap.clientHeight / 2).scale(kk).translate(-n.x, -n.y)
  );
}

/* 从其他视图跳转到图谱中的某个节点;必要时解除会遮挡它的过滤 */
function gotoNode(id) {
  const n = S.nodeById.get(id);
  if (!n) return;
  if (S.focusSet && !S.focusSet.has(id)) clearFocus();
  if (commIsoHides(n)) { S.commIso = null; renderCommList(); }
  if (!S.kindOn.has(n.kind)) { S.kindOn.add(n.kind); renderKindChips(); }
  switchView("graph");
  selectNode(n, true);
}
window.__goto = gotoNode;  // 供内嵌 HTML onclick 使用

/* ========================= 节点选择与信息面板 ========================= */
function selectNode(n, andZoom) {
  S.selNode = n || null;
  updateHighlight();
  renderNodeInfo();
  if (n && andZoom) zoomToNode(n);
}

function renderNodeInfo() {
  const el = $("node-info");
  const n = S.selNode;
  if (!n) { el.innerHTML = '<div class="placeholder">点击图中节点查看详情</div>'; return; }
  const f = S.fileById.get(n.file_id);
  const rel = S.adj.get(n.id) || [];
  const outs = rel.filter(r => r.dir === "out");
  const ins = rel.filter(r => r.dir === "in");
  const edgeHtml = (r) => {
    const o = S.nodeById.get(r.otherId);
    const arrow = r.dir === "out" ? "→" : "←";
    return '<div class="ni-edge" data-nid="' + o.id + '">'
      + '<span class="ek">' + arrow + " " + esc(EDGE_CN[r.e.kind] || r.e.kind) + "</span> "
      + '<span class="en">' + esc(o.name) + "</span>"
      + '<span class="ek"> (' + esc(KIND_CN[o.kind] || o.kind) + ")</span>"
      + (r.e.evidence ? '<div class="ev">' + esc(r.e.evidence) + "</div>" : "")
      + "</div>";
  };
  el.innerHTML =
    '<div class="ni-name">' + esc(n.name) + "</div>"
    + '<div class="ni-fqn">' + esc(n.fqn || "") + "</div>"
    + '<div class="ni-row"><b>类型</b> <span class="kbadge">' + esc(KIND_CN[n.kind] || n.kind) + "</span></div>"
    + (f ? '<div class="ni-row"><b>文件</b> ' + esc(f.rel_path) + (n.line ? ":" + n.line : "") + "</div>" : "")
    + '<div class="ni-row"><b>社区</b> ' + esc(commName(n)) + "</div>"
    + '<div class="ni-row"><b>连接数</b> ' + n.deg + "</div>"
    + '<div class="ni-edges">'
    + (outs.length ? "<h3>出边 " + outs.length + "(先点展开证据,再点跳转)</h3>" + outs.map(edgeHtml).join("") : "")
    + (ins.length ? "<h3>入边 " + ins.length + "</h3>" + ins.map(edgeHtml).join("") : "")
    + "</div>"
    + '<button class="ni-impact">以此节点做影响分析 →</button>';
  el.querySelectorAll(".ni-edge").forEach(div => {
    div.addEventListener("click", (ev) => {
      ev.stopPropagation();
      if (div.classList.contains("open") || !div.querySelector(".ev")) {
        gotoNode(+div.dataset.nid);
      } else {
        div.classList.add("open");
      }
    });
  });
  el.querySelector(".ni-impact").addEventListener("click", () => {
    S.impactRoot = n;
    $("impact-search").value = n.name;
    switchView("impact");
    runImpact();
  });
}

/* ========================= 侧栏静态部分 ========================= */
function renderSidebarStatics() {
  renderKindChips();
  renderCommList();
  bindSearch($("graph-search"), $("graph-search-results"), (n) => {
    $("graph-search").value = n.name;
    gotoNode(n.id);
  });
}

function renderKindChips() {
  const kinds = [...new Set(S.nodes.map(n => n.kind))];
  const el = $("kind-filter");
  el.innerHTML = kinds.map(k =>
    '<span class="chip' + (S.kindOn.has(k) ? "" : " off") + '" data-k="' + esc(k) + '">'
    + esc(KIND_CN[k] || k) + "</span>").join("");
  el.querySelectorAll(".chip").forEach(ch => {
    ch.addEventListener("click", () => {
      const k = ch.dataset.k;
      if (S.kindOn.has(k)) S.kindOn.delete(k); else S.kindOn.add(k);
      ch.classList.toggle("off");
      draw();
    });
  });
}

function renderCommList() {
  const el = $("communities");
  const top = S.comms.slice(0, PALETTE.length);
  const restCount = S.comms.length - top.length;
  const restSize = S.comms.slice(PALETTE.length).reduce((a, c) => a + c.size, 0);
  let html = top.map(c =>
    '<div class="comm' + (S.commIso != null && S.commIso !== c.id ? " dim" : "") + '" data-c="' + c.id + '">'
    + '<span class="dot" style="background:' + c.color + '"></span>'
    + '<span class="cname" title="' + esc(c.label) + '">' + esc(c.label) + "</span>"
    + '<span class="csize">' + c.size + "</span></div>").join("");
  if (restCount > 0) {
    html += '<div class="comm' + (S.commIso != null && S.commIso !== -1 ? " dim" : "") + '" data-c="-1">'
      + '<span class="dot" style="background:' + OTHER_COLOR + '"></span>'
      + '<span class="cname">其他 ' + restCount + " 个社区</span>"
      + '<span class="csize">' + restSize + "</span></div>";
  }
  el.innerHTML = html;
  el.querySelectorAll(".comm").forEach(div => {
    div.addEventListener("click", () => {
      const c = +div.dataset.c;
      S.commIso = (S.commIso === c) ? null : c;
      renderCommList();
      draw();
    });
  });
}

/* ========================= 搜索(共用) ========================= */
function searchNodes(query) {
  const ql = query.trim().toLowerCase();
  if (!ql) return [];
  const out = [];
  const seen = new Set();
  const push = (n, via) => {
    if (seen.has(n.id) || out.length >= 20) return;
    seen.add(n.id); out.push({ n, via });
  };
  for (const n of S.nodes) {
    if (out.length >= 20) break;
    if (n.name.toLowerCase().includes(ql) || (n.fqn || "").toLowerCase().includes(ql)) push(n, null);
  }
  // 业务术语 → keyword_code → 节点
  // 双向包含:输入含术语(如输"案件检索画面"匹配术语"案件检索")或术语含输入
  for (const g of S.glossary) {
    if (out.length >= 20) break;
    const term = String(g.term_cn).toLowerCase();
    if (!(term.includes(ql) || (term.length >= 2 && ql.includes(term)))) continue;
    const kw = String(g.keyword_code).toLowerCase();
    for (const n of S.nodes) {
      if (out.length >= 20) break;
      if (n.name.toLowerCase().includes(kw) || (n.fqn || "").toLowerCase().includes(kw)) push(n, g.term_cn);
    }
  }
  return out;
}

function bindSearch(input, resultBox, onPick) {
  const render = () => {
    const rs = searchNodes(input.value);
    if (!rs.length) {
      if (input.value.trim()) {   // 有输入但没结果:明确提示,不再静默
        resultBox.innerHTML = '<div class="sr-empty">没有匹配的节点 — 试试代码关键字'
          + '(类名/表名/URL 片段),或先在 glossary 里登记「'
          + esc(input.value.trim()) + '」对应的代码关键字</div>';
        resultBox.style.display = "block";
      } else resultBox.style.display = "none";
      return;
    }
    resultBox.innerHTML = rs.map((r, i) =>
      '<div data-i="' + i + '"><span class="sr-name">' + esc(r.n.name) + "</span>"
      + '<span class="sr-kind">' + esc(KIND_CN[r.n.kind] || r.n.kind) + "</span>"
      + (r.via ? '<span class="sr-gloss">« ' + esc(r.via) + "</span>" : "") + "</div>").join("");
    resultBox.style.display = "block";
    resultBox.querySelectorAll("div[data-i]").forEach(div => {
      div.addEventListener("mousedown", (ev) => {
        ev.preventDefault();
        resultBox.style.display = "none";
        onPick(rs[+div.dataset.i].n);
      });
    });
  };
  input.addEventListener("input", render);
  input.addEventListener("focus", render);
  input.addEventListener("blur", () => setTimeout(() => { resultBox.style.display = "none"; }, 150));
}

/* ========================= 概览视图 ========================= */
function renderOverview() {
  const el = $("view-overview");
  const orphans = S.nodes.filter(n => n.deg === 0);
  const noFile = S.nodes.filter(n => KINDS_NEED_FILE.has(n.kind) && n.file_id == null);
  const usedFiles = new Set(S.nodes.map(n => n.file_id));
  const emptyFiles = S.files.filter(f => !usedFiles.has(f.id));
  const dangling = S.edges.filter(e => e._dangling);
  const kwMiss = S.glossary.filter(g => {
    const kw = String(g.keyword_code).toLowerCase();
    return !S.nodes.some(n => n.name.toLowerCase().includes(kw) || (n.fqn || "").toLowerCase().includes(kw));
  });

  const count = (arr, key) => {
    const m = new Map();
    for (const x of arr) { const k = key(x); m.set(k, (m.get(k) || 0) + 1); }
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  };
  const bars = (pairs, labelFn) => {
    const max = Math.max(...pairs.map(p => p[1]), 1);
    return pairs.map(([k, v]) =>
      '<div class="hbar"><span class="hl" title="' + esc(k) + '">' + esc(labelFn ? labelFn(k) : k) + "</span>"
      + '<span class="ht"><span class="hf" style="width:' + (v / max * 100).toFixed(1) + '%"></span></span>'
      + '<span class="hv">' + v + "</span></div>").join("");
  };
  const tile = (v, l, warn) =>
    '<div class="tile' + (warn && v > 0 ? " warn" : "") + '"><div class="tv">' + v + '</div><div class="tl">' + l + "</div></div>";

  const qitem = (title, items, bodyFn) => {
    const ok = items.length === 0;
    return '<li class="' + (ok ? "ok" : "ng") + '"><div class="q-head">'
      + '<span class="q-badge">' + (ok ? "OK" : items.length) + "</span>"
      + '<span class="q-title">' + title + "</span>"
      + '<span class="q-count">' + (ok ? "" : "点击展开") + "</span></div>"
      + (ok ? "" : '<div class="q-body">' + items.slice(0, 200).map(bodyFn).join("<br>")
        + (items.length > 200 ? "<br>…共 " + items.length + " 条" : "") + "</div>")
      + "</li>";
  };

  el.innerHTML =
    "<h2>总览</h2><div class='tiles'>"
    + tile(S.files.length, "源文件") + tile(S.nodes.length, "节点") + tile(S.edges.length, "边")
    + tile(S.glossary.length, "业务术语") + tile(S.comms.length, "社区")
    + tile(orphans.length, "孤立节点", true)
    + "</div>"
    + "<h2>分布</h2><div class='cards'>"
    + "<div class='card'><h4>节点类型分布</h4>" + bars(count(S.nodes, n => n.kind), k => KIND_CN[k] || k) + "</div>"
    + "<div class='card'><h4>边类型分布</h4>" + bars(count(S.edges.filter(e => !e._dangling), e => e.kind), k => EDGE_CN[k] || k) + "</div>"
    + "<div class='card'><h4>文件类型分布</h4>" + bars(count(S.files, f => f.type)) + "</div>"
    + "<div class='card'><h4>连接数 Top 10</h4>"
    + bars([...S.nodes].sort((a, b) => b.deg - a.deg).slice(0, 10).map(n => [n.name, n.deg])) + "</div>"
    + "</div>"
    + "<h2>数据质量检查</h2><ul class='qlist'>"
    + qitem("孤立节点(没有任何边,可能是废弃代码或扫描遗漏)", orphans,
        n => '<a onclick="__goto(' + n.id + ')">' + esc(n.name) + "</a> <span class='kbadge'>" + esc(KIND_CN[n.kind] || n.kind) + "</span> " + esc(n.fqn || ""))
    + qitem("应有源文件但 file_id 为空的节点", noFile,
        n => '<a onclick="__goto(' + n.id + ')">' + esc(n.name) + "</a> (" + esc(n.kind) + ")")
    + qitem("已登记但没有解析出任何节点的文件", emptyFiles,
        f => esc(f.rel_path) + " <span class='kbadge'>" + esc(f.type) + "</span>")
    + qitem("悬空边(指向不存在的节点,数据完整性问题)", dangling,
        e => "edge#" + e.id + " " + e.src_id + " → " + e.dst_id + " (" + esc(e.kind) + ")")
    + qitem("匹配不到任何节点的业务术语", kwMiss,
        g => esc(g.term_cn) + " → " + esc(g.keyword_code))
    + "</ul><div style='height:24px'></div>";

  el.querySelectorAll(".qlist li.ng .q-head").forEach(h => {
    h.addEventListener("click", () => h.parentElement.classList.toggle("open"));
  });
}

/* ========================= 表格视图 ========================= */
const PAGE = 100;
function tblRows() {
  const t = S.tbl.t, ql = S.tbl.q.toLowerCase(), kf = S.tbl.kind;
  let rows;
  if (t === "nodes") rows = S.nodes;
  else if (t === "edges") rows = S.edges.filter(e => !e._dangling);
  else if (t === "files") rows = S.files;
  else rows = S.glossary;
  if (kf) {
    if (t === "files") rows = rows.filter(r => r.type === kf);
    else if (t !== "glossary") rows = rows.filter(r => r.kind === kf);
  }
  if (ql) {
    rows = rows.filter(r => {
      if (t === "nodes") return (r.name + " " + (r.fqn || "")).toLowerCase().includes(ql);
      if (t === "edges") {
        const s = S.nodeById.get(r.src_id), d = S.nodeById.get(r.dst_id);
        return (s.name + " " + d.name + " " + (r.evidence || "")).toLowerCase().includes(ql);
      }
      if (t === "files") return r.rel_path.toLowerCase().includes(ql);
      return (r.term_cn + " " + r.keyword_code).toLowerCase().includes(ql);
    });
  }
  return rows;
}

function renderTables() {
  const t = S.tbl.t;
  let kinds = [];
  if (t === "nodes") kinds = [...new Set(S.nodes.map(n => n.kind))];
  else if (t === "edges") kinds = [...new Set(S.edges.map(e => e.kind))];
  else if (t === "files") kinds = [...new Set(S.files.map(f => f.type))];
  $("tbl-kind").style.display = kinds.length ? "" : "none";
  $("tbl-kind").innerHTML = '<option value="">全部类型</option>'
    + kinds.map(k => '<option value="' + esc(k) + '"' + (S.tbl.kind === k ? " selected" : "") + ">"
      + esc(KIND_CN[k] || EDGE_CN[k] || k) + "</option>").join("");

  const rows = tblRows();
  const pages = Math.max(1, Math.ceil(rows.length / PAGE));
  if (S.tbl.page >= pages) S.tbl.page = pages - 1;
  const slice = rows.slice(S.tbl.page * PAGE, (S.tbl.page + 1) * PAGE);
  $("tbl-count").textContent = rows.length + " 行";

  let head = "", body = "";
  if (t === "nodes") {
    head = "<th>ID</th><th>类型</th><th>名称</th><th>FQN</th><th>文件</th><th>行</th>";
    body = slice.map(n => {
      const f = S.fileById.get(n.file_id);
      return "<tr><td>" + n.id + '</td><td><span class="kbadge">' + esc(KIND_CN[n.kind] || n.kind) + "</span></td>"
        + '<td><a onclick="__goto(' + n.id + ')">' + esc(n.name) + "</a></td>"
        + '<td class="mono">' + esc(n.fqn || "") + "</td>"
        + '<td class="mono">' + esc(f ? f.rel_path : "") + "</td><td>" + (n.line || "") + "</td></tr>";
    }).join("");
  } else if (t === "edges") {
    head = "<th>ID</th><th>类型</th><th>起点</th><th>终点</th><th>证据片段</th><th>行</th>";
    body = slice.map(e => {
      const s = S.nodeById.get(e.src_id), d = S.nodeById.get(e.dst_id);
      return "<tr><td>" + e.id + '</td><td><span class="kbadge">' + esc(EDGE_CN[e.kind] || e.kind) + "</span></td>"
        + '<td><a onclick="__goto(' + s.id + ')">' + esc(s.name) + "</a></td>"
        + '<td><a onclick="__goto(' + d.id + ')">' + esc(d.name) + "</a></td>"
        + '<td class="mono">' + esc((e.evidence || "").slice(0, 120)) + "</td><td>" + (e.line || "") + "</td></tr>";
    }).join("");
  } else if (t === "files") {
    const cnt = new Map();
    for (const n of S.nodes) cnt.set(n.file_id, (cnt.get(n.file_id) || 0) + 1);
    head = "<th>ID</th><th>相对路径</th><th>类型</th><th>节点数</th>";
    body = slice.map(f =>
      "<tr><td>" + f.id + '</td><td class="mono">' + esc(f.rel_path) + "</td>"
      + '<td><span class="kbadge">' + esc(f.type) + "</span></td><td>" + (cnt.get(f.id) || 0) + "</td></tr>").join("");
  } else {
    head = "<th>业务术语</th><th>代码关键字</th>";
    body = slice.map(g =>
      "<tr><td>" + esc(g.term_cn) + '</td><td class="mono">' + esc(g.keyword_code) + "</td></tr>").join("");
  }
  $("tbl-body").innerHTML = '<table class="datatable"><thead><tr>' + head + "</tr></thead><tbody>" + body + "</tbody></table>";
  $("tbl-pager").innerHTML = pages > 1
    ? '<button id="pg-prev"' + (S.tbl.page === 0 ? " disabled" : "") + ">上一页</button>"
      + "<span>" + (S.tbl.page + 1) + " / " + pages + "</span>"
      + '<button id="pg-next"' + (S.tbl.page >= pages - 1 ? " disabled" : "") + ">下一页</button>"
    : "";
  const pv = $("pg-prev"), nx = $("pg-next");
  if (pv) pv.addEventListener("click", () => { S.tbl.page--; renderTables(); });
  if (nx) nx.addEventListener("click", () => { S.tbl.page++; renderTables(); });
}

/* ========================= 影响分析视图 ========================= */
function resetImpact() {
  S.impactRoot = null;
  $("impact-search").value = "";
  $("impact-result").innerHTML = "";
  $("impact-empty").style.display = "";
  $("impact-show-graph").style.display = "none";
}

function bfs(rootId, dir, maxDepth) {
  const visited = new Map([[rootId, 0]]);
  const tree = new Map();     // id -> {via, parent}
  let frontier = [rootId];
  let depth = 0;
  while (frontier.length && depth < maxDepth) {
    depth++;
    const next = [];
    for (const id of frontier) {
      for (const rec of S.adj.get(id) || []) {
        const ok = dir === "both"
          || (dir === "down" && rec.dir === "out")
          || (dir === "up" && rec.dir === "in");
        if (!ok || visited.has(rec.otherId)) continue;
        visited.set(rec.otherId, depth);
        tree.set(rec.otherId, { via: rec, parent: id });
        next.push(rec.otherId);
      }
    }
    frontier = next;
  }
  return { visited, tree };
}

function runImpact() {
  const root = S.impactRoot;
  if (!root) return;
  const dir = $("impact-dir").value;
  const depth = +$("impact-depth").value;
  const { visited, tree } = bfs(root.id, dir, depth);

  const kids = new Map();
  for (const [id, info] of tree) {
    if (!kids.has(info.parent)) kids.set(info.parent, []);
    kids.get(info.parent).push(id);
  }
  const renderNode = (id, viaRec) => {
    const n = S.nodeById.get(id);
    const via = viaRec
      ? '<span class="tk">' + (viaRec.dir === "out" ? "→" : "←") + " " + esc(EDGE_CN[viaRec.e.kind] || viaRec.e.kind) + "</span>"
      : "";
    const children = (kids.get(id) || [])
      .sort((a, b) => S.nodeById.get(b).deg - S.nodeById.get(a).deg);
    return '<div class="tnode">'
      + '<span class="trow" onclick="__goto(' + id + ')" title="' + esc((viaRec && viaRec.e.evidence) || n.fqn || "") + '">'
      + via + '<span class="tn">' + esc(n.name) + "</span>"
      + '<span class="tk">(' + esc(KIND_CN[n.kind] || n.kind) + ")</span></span>"
      + (children.length ? '<div class="tkids">' + children.map(c => renderNode(c, tree.get(c).via)).join("") + "</div>" : "")
      + "</div>";
  };

  const byFile = new Map();
  for (const id of visited.keys()) {
    const n = S.nodeById.get(id);
    if (n.file_id == null) continue;
    if (!byFile.has(n.file_id)) byFile.set(n.file_id, []);
    byFile.get(n.file_id).push(n);
  }
  const fileItems = [...byFile.entries()]
    .map(([fid, ns]) => ({ f: S.fileById.get(fid), ns }))
    .filter(x => x.f)
    .sort((a, b) => b.ns.length - a.ns.length);

  $("impact-empty").style.display = "none";
  $("impact-result").innerHTML =
    "<h2>「" + esc(root.name) + "」— 关联 " + (visited.size - 1) + " 个节点,涉及 "
    + fileItems.length + " 个文件</h2>"
    + '<div class="imp-grid">'
    + '<div class="card"><h4>关联链路(悬停看证据,点击在图谱中定位)</h4><div class="tree">'
    + renderNode(root.id, null) + "</div></div>"
    + '<div class="card"><h4>受影响的文件</h4><ul class="filelist">'
    + fileItems.map(({ f, ns }) =>
      '<li><div class="fp">' + esc(f.rel_path) + "</div>"
      + '<div class="fn">' + ns.map(n => '<a onclick="__goto(' + n.id + ')">' + esc(n.name) + "</a>").join(" · ") + "</div></li>").join("")
    + "</ul></div></div><div style='height:24px'></div>";

  const btn = $("impact-show-graph");
  btn.style.display = "";
  btn.onclick = () => {
    const set = new Set(visited.keys());
    switchView("graph");
    setFocus(set, "影响子图:" + root.name + "(" + set.size + " 个节点)");
    selectNode(root, true);
  };
}

/* ========================= 视图切换与初始化 ========================= */
function switchView(name) {
  document.querySelectorAll("#tabs button").forEach(b =>
    b.classList.toggle("active", b.dataset.view === name));
  document.querySelectorAll(".view").forEach(v =>
    v.classList.toggle("active", v.id === "view-" + name));
  if (name === "graph" && S.ctx) resizeCanvas();  // 从隐藏切回时画布尺寸可能是 0
}

function bindUi() {
  document.querySelectorAll("#tabs button").forEach(b =>
    b.addEventListener("click", () => switchView(b.dataset.view)));

  const pick = () => $("file-input").click();
  $("btn-open").addEventListener("click", pick);
  $("btn-pick").addEventListener("click", pick);
  $("file-input").addEventListener("change", async (ev) => {
    const f = ev.target.files[0];
    if (!f) return;
    try {
      await loadDb(new Uint8Array(await f.arrayBuffer()), f.name);
    } catch (e) {
      $("landing").style.display = "flex";
      $("landing-err").textContent = "加载失败:" + e.message;
    }
    ev.target.value = "";
  });

  $("btn-sample").addEventListener("click", async () => {
    if (!window.__SAMPLE_B64) { $("landing-err").textContent = "此构建未内嵌示例数据"; return; }
    try {
      await loadDb(b64ToU8(window.__SAMPLE_B64), "sample.db(内嵌示例)");
    } catch (e) { $("landing-err").textContent = "加载失败:" + e.message; }
  });

  const dz = $("dropzone");
  const stop = (e) => { e.preventDefault(); e.stopPropagation(); };
  ["dragenter", "dragover"].forEach(t => document.body.addEventListener(t, (e) => { stop(e); dz.classList.add("drag"); }));
  document.body.addEventListener("dragleave", (e) => { stop(e); dz.classList.remove("drag"); });
  document.body.addEventListener("drop", async (e) => {
    stop(e); dz.classList.remove("drag");
    const f = e.dataTransfer.files[0];
    if (!f) return;
    try {
      await loadDb(new Uint8Array(await f.arrayBuffer()), f.name);
    } catch (err) {
      $("landing").style.display = "flex";
      $("landing-err").textContent = "加载失败:" + err.message;
    }
  });

  $("graph-badge-clear").addEventListener("click", clearFocus);

  $("tbl-pills").querySelectorAll("button").forEach(b =>
    b.addEventListener("click", () => {
      S.tbl = { t: b.dataset.t, q: "", kind: "", page: 0 };
      $("tbl-search").value = "";
      $("tbl-pills").querySelectorAll("button").forEach(x => x.classList.toggle("active", x === b));
      renderTables();
    }));
  $("tbl-search").addEventListener("input", () => { S.tbl.q = $("tbl-search").value; S.tbl.page = 0; renderTables(); });
  $("tbl-kind").addEventListener("change", () => { S.tbl.kind = $("tbl-kind").value; S.tbl.page = 0; renderTables(); });

  bindSearch($("impact-search"), $("impact-search-results"), (n) => {
    S.impactRoot = n;
    $("impact-search").value = n.name;
    runImpact();
  });
  $("impact-dir").addEventListener("change", runImpact);
  $("impact-depth").addEventListener("change", runImpact);
}

bindUi();

// 打开时带 #sample 直接载入内嵌示例(演示/测试用)
if (location.hash === "#sample" && window.__SAMPLE_B64) {
  loadDb(b64ToU8(window.__SAMPLE_B64), "sample.db(内嵌示例)")
    .catch(e => { $("landing-err").textContent = "加载失败:" + e.message; });
}
