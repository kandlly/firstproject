# 真实项目结构笔记（据 picture/ 目录截图整理，2026-07-08）

> 用于校准扫描器解析规则。信息来自 6 张 Eclipse 工程结构截图，**均为目录树，暂无文件内容**。

## 平台与技术栈（已确认）

- **intra-mart Accel Platform**（截图有 "Accel Platform Library"），应用服务器 **Resin v4.0**。
- Spring MVC 风格分层 + MyBatis。存在 intra-mart 自有的 **JSSP**（`WEB-INF/jssp`）作为另一套表现层。
- 源根：`src/main/java`；框架包 `jp.co.nttdata.inet.fw`；业务包 `jp.co.(wiseoffice…)`。

## 业务模块（`…/wiseoffice/` 下）

`a01kokyaku`(顾客) `b01anken`(案件) `c01keiyaku`(契约) `c02tesuuryou`
`c03manki` `c04jigyouhoukokusho` `c05kaiyaku` `c06zandaka` `i01lifeEvent`
`navi`(相談ナビ，含 navi01~06) `s02smtKokyaku` `bean` `bean.entity` `fw`

## 每个业务模块内部分层（关键！与现有 MVP 假设不同）

以 `a01kokyaku` 为例，子包：
```
controller / service / manager / repository(.tenant) / bean / form / constants / util
```
调用链推测为：**Controller → Service(接口+Impl) → Manager → Repository → MyBatis → SQL → 表**
（比现有 MVP 的 Controller→Service→Mapper 多了 **Manager** 和 **Repository** 两层命名）

## 命名约定（据类名截图）

| 层 | 命名 | 例 |
|---|---|---|
| Controller | `A01XxxController` | `A01SearchKokyakuTougouController` |
| Service | 接口 `XxxService` + 实现 `XxxServiceImpl`（含 `Abstract*`） | `AbstractKokyakuService` / `…Impl` |
| Repository（数据层） | `XxxRepository` 接口 **+ 同名 `XxxRepository.xml`** | `fw/repository/tenant/UserRepository.java` + `UserRepository.xml` |

- **数据层叫 Repository，不叫 Mapper/Dao** → 现有 java 解析里"依赖类型以 Mapper/Dao 结尾"的规则要加上 **Repository**。
- **MyBatis XML 与 Repository 接口同包同名并排**，`namespace` 应为该 Repository 接口全限定名。
- 服务是**接口+Impl**：调用链要能把 `XxxService`（接口）解析到 `XxxServiceImpl`（实现）。这是正则难点，正是 ast-grep（需求#1）的价值所在。

## JSP 视图

- 位置：`webapp/WEB-INF/views/<模块>/*.jsp`，另有 `inc/` 子目录放被 include 的片段。
- 命名：`SC_NAVI03_001_SearchDisplayListOkyakusama.jsp`、`B01_SearchAnken.jsp`、`A01…` 等（模块前缀 + 功能名）。
- 视图解析器推测：prefix=`WEB-INF/views/`，suffix=`.jsp` → Controller 返回 `"a01kokyaku/SC_…"` 之类。**待看真实 controller 的 return 确认。**
- 另有 intra-mart **JSSP**（`WEB-INF/jssp`）——是否需纳入分析待定。

## 请求流全貌（据第二批 15 张代码截图，2026-07-11 确认）

完整链路（以 b01anken 案件检索为例）：
```
JSP  B01_SearchAnken.jsp
  <wo:form action="${pageContext.request.contextPath}/b01anken/searchAnkenDSP">
  <button onclick="executeXxxForward('forward_xxx')">   → 调 JS
JS   B01_anken.js
  form.event.value = 'forward_xxx'; form.submit();       → POST /b01anken/searchAnkenDSP?event=forward_xxx
Controller（extends AbstractController）三类方法：
  ① DSP  @RequestMapping(value=".../searchAnkenDSP", params="event=forward_xxx")
          return "forward:/b01anken/XxxBL";              → 内部转发到 BL
  ② BL   @RequestMapping(".../XxxBL")
          input = beanMapper.map(form, XxxBvo.class);
          BLogicResult r = xxxService.executeService(input);   ← Controller→Service
          return "forward:/b01anken/XxxSCR";（按 r.getResultString() switch）
  ③ SCR  @RequestMapping(".../XxxSCR")
          return "/b01anken/Xxx.jsp";                    → 渲染 JSP（返回串带 .jsp）
Service  XxxServiceImpl
  @Service @Transactional，implements XxxService（接口只有 executeService(bvo)）
  两种写法：直接实现 executeService()  或  extends AbstractNaviServiceImpl<Bvo> 重写 executeLogic()
  依赖获取：@Inject Manager / @Inject Repository / 也有 new XxxImpl()
Manager → Repository → MyBatis(XxxRepository.xml, namespace=Repository接口) → SQL → 表   ← 【尚未拿到样例】
```

### 校准要点（务必写进解析规则）

- **注入注解是 `@Inject`（JSR-330），不是 @Autowired**；字段名≠类型名（如 `DisplayAnkenIchiranService displayAnkenIchiranBLogic`），按变量→类型映射即可。
- **依赖类型后缀**：数据/业务层是 `Service` / `Manager` / `Repository`（**不是 Mapper/Dao**）。
- **要排除 `Mapper` 这个类型**：`@Inject private Mapper beanMapper;` 是 Dozer 式 Bean 拷贝器（`beanMapper.map(form, Xxx.class)`），**不是** MyBatis，别当数据访问。
- **泛型**：`DepartmentManager<UserValueObject> departmentManager` —— 字段正则要能跳过 `<...>`。
- **`new XxxImpl()` 直接实例化**也算依赖边（如 `ExcelOperationManagerImpl x = new ExcelOperationManagerImpl();`），只扫 @Inject 会漏。
- **Service 入口有两种**：`executeService()`（直接实现）或 `executeLogic()`（继承 `AbstractNaviServiceImpl` 的模板方法）——两者都要当作该 Service 的业务入口。
- **Controller 的 `return` 三种语义**：
  - `".../Xxx.jsp"` → renders JSP（带 .jsp 后缀，是相对 `WEB-INF/views` 的完整路径，比按文件名匹配可靠）。
  - `"forward:/模块/XxxBL"` / `"forward:/模块/XxxSCR"` → 转发到另一 URL 端点（建 routes 边）。
  - `getNaviErrorPage(...)` 等 → 错误页。
- **DSP 分发靠 `params="event=forward_xxx"`**；JSP 按钮 `onclick`/`name="forward_xxx"` + JS `form.event.value=...` 触发。JSP→Controller 的边要认 `<wo:form action="...">` 和这些 event 值。
- **JSP 标签**：intra-mart `<wo:form>` `<im:imAuthz uri="service://...">` `<imui:head>` + Spring `<form:hidden>` `<spring:message>` + JSTL `<c:if>`；include 用 `<jsp:include page="../commonGyomuHeader.jsp">`（相对）或 `/WEB-INF/views/common/message.jsp`（绝对）。
- **授权关联**（可选）：Controller `@Authz(uri="service://searchAnkenExe")` ↔ JSP `<im:imAuthz uri="service://...">`。
- 包结构：`jp.wiseoffice.<模块>.{controller,service,manager,bean,form,constants,util}`；框架 `jp.wiseoffice.fw.blogic.BLogicResult`。

## 数据半段（据第三批 14 张 SQL 截图，2026-07-11 确认）

链路续接：`Service → Manager → Repository → MyBatis XML → SQL → 表`

- **Manager Impl**（如 `YoukenHanteiManagerImpl`）：`@Inject private SharedFwRepository sharedFwRepository;`，方法内 `sharedFwRepository.selectYoukenHantei(searchMA270)` 调 Repository。Manager 也可能直接被 Service `@Inject`。
- **Repository 接口**：
  - 位置：`fw/repository/{shared,tenant}/*.java`（框架级）和 `<模块>/repository/{shared,tenant}/*.java`（业务级）。每个 `XxxRepository.java` **旁边就是同名 `XxxRepository.xml`**。
  - `@Mapper`：**业务级 Repository 带 `@Mapper`**（如 `AnkenRepository`）；**fw 级不带**（如 `SharedUserRepository`）。→ 判定 mapper 接口要用「`@Mapper` 注解 **或** 名字以 `Repository` 结尾 **或** 被某 XML namespace 引用」三者取并。
  - **方法名 == XML 的 statement id**（Javadoc 明写 `sqlID "xxx" を実行する`）。id 可能是**编码**（`r0001`/`r0002`=查询、`i0002`/`i0003`=更新），也可能是描述名（`selectUserSchemaName`）。→ 不能靠 id 猜业务，靠图遍历连过去即可。
  - **方法重载**：`r0001(Map)` 与 `r0001(Map, RowBounds)` 共用一个 sqlID → 按 `Repository.方法名` 去重成一个 mapper_method 节点即可。
- **MyBatis XML**：标准写法。`<mapper namespace="jp.wiseoffice.<...>.XxxRepository">`；`<select|insert|update|delete id="...">`；namespace 简名 == Repository 接口简名 → 与 java 侧 `Type.method` 自动对接（现有解析器键设计正确）。
- **SQL 复杂度（都能被 itertext + FROM/JOIN/INTO 正则覆盖）**：
  - 子查询 `SELECT * FROM (SELECT ...)`、`INNER/RIGHT OUTER/LEFT JOIN`、`EXISTS (...)`、`INSERT INTO ... SELECT`。
  - 动态标签 `<where> <if> <foreach> <trim>`；`<![CDATA[<=]]>` 包裹比较符；`${item.columnName}` 动态列。
  - **Oracle 方言**（`ROW_NUMBER() OVER`、`TO_MULTI_BYTE`、`UTL_I18N.TRANSLITERATE`、`TRANSLATE`）→ 数据库是 Oracle。
- **表名规律**：`TB###_*`(交易) `MA###_*`/`MB###_*`(主数据) `WA###_*`(工作/临时) **`IAC_*`(intra-mart 框架核心表)** 等。→ **抽表严禁用前缀白名单**，一律抽 `FROM|JOIN|INTO|UPDATE|DELETE FROM` 后的标识符。
- **实体类 ≈ 表名**：`jp.wiseoffice.bean.entity.TB520_Anken_Related_Info`、`MA270_YoukenHantei`、`TB450_Anken_Market` —— 实体类名直接是表名，可作为 Java↔表的辅助线索。

## 进度与待补

全链路已用真实代码验证（JSP→JS→Controller→Service→Manager→Repository→MyBatis→SQL→表），可以据此实现「校准版」扫描器。

尚缺（不阻塞主链路）：
- **batch（需求 #2，已暂缓）**：batch 目录 + 一个 `.java`，看靠什么认定为 batch。
