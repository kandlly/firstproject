# iMart オフライン影響分析（MVP）

> 🌐 言語 / 语言：**日本語**（本ページ） ・ [中文](README.md)

業務キーワード（日本語/英語）を与えると、修正が必要なファイルの影響チェーンを自動出力します。

```
JSP → JS → Controller(DSP/BL/SCR) → Service(interface+Impl) → Manager → Repository → MyBatis XML → SQL → DB テーブル
```

さらに逆方向で **どの他モジュールがそれらの DB テーブルを共用しているか** も分析します。

**役割分担**：ツールは決定的なインデックス化とグラフ検索のみ。リスク評価や修正順序などの推論は
Copilot（AI）に任せます。全処理は Python 標準ライブラリのみで **完全オフライン**、閉じた社内ネットワーク向けです。

> 解析ルールは実プロジェクト（wiseoffice / intra-mart Accel Platform）に合わせて校正済み。詳細は `PROJECT_NOTES_ja.md`。

---

## ディレクトリ構成

```
imart-impact/
  schema.sql                     # SQLite ナレッジベースのスキーマ（汎用 files/nodes/edges/glossary グラフモデル）
  scanner/
    scan.py                      # 走査エントリ
    db.py                        # DB 初期化 / 挿入ラッパー
    parsers/
      java_parser.py             # Controller/Service/Manager/Repository と呼び出し関係
      mybatis_parser.py          # namespace / statement id / SQL / テーブル名
      jsp_parser.py              # ページ / include / フォーム(wo:form)リンク
      common.py                  # 共通ユーティリティ
  query/
    impact.py                    # 要求キーワード → 影響チェーン（テキスト / --json）
  samples/                       # 実構成サンプル（wiseoffice：b01anken 案件 + a01kokyaku 顧客、TB070_CUSTOMER を共用）
    glossary.csv                 # 業務用語 ↔ コード識別子 の対訳表
  docs/                          # ドキュメント（日本語 / 中国語）
  PROJECT_NOTES_ja.md            # 実プロジェクト構成と校正ポイント
  requirements.txt               # 標準ライブラリのみ；Python 3.8+
```

---

## 使い方（2 ステップ）

### 1. プロジェクトを走査してナレッジベースを構築

```bash
python scanner/scan.py --root <プロジェクトのソースルート> --out project.db --reset
```

- `.java/.jsp/.xml/.js/.css` を走査。`target/node_modules/.git` などはスキップ。
- `--glossary <パス>` で用語表 CSV を指定可能（既定は `<root>/glossary.csv`）。
- 生成物 `project.db` は単一の SQLite ファイル。コピーで配布可能。

### 2. 影響チェーンを検索

```bash
python query/impact.py "案件検索" --db project.db          # 人が読むレポート
python query/impact.py "案件検索" --db project.db --json    # Copilot 用の構造化結果
python query/impact.py anken       --db project.db          # 英語/ローマ字識別子で直接
```

`--shared-depth N`（既定 6）：共用テーブルの逆方向拡散の深さ。人気テーブル（`IAC_*` 等）でノイズが多いときは小さくします。

---

## キーワードのマッチ（日本語要求 → コード）

コード識別子は英語/ローマ字、要求は日本語のことが多い。ブリッジ方法は 2 つ：

1. **用語表**：`glossary.csv`（`業務語,コード識別子`、例：`案件,anken`）を維持。「案件」を含む検索で自動的に `anken` を付与。随時追記可。
2. **Copilot が直接翻訳**：Copilot が「案件検索」を `anken` と解釈してから CLI を呼ぶ。

英語キーワードは `LIKE %kw%` で `ノード名 / 完全修飾名 / ファイルパス` にマッチし、そこからグラフを BFS で拡散します。

---

## Copilot との連携（AI 分析層）

固定運用：**まず CLI で決定的なグラフ結果を取得し、Copilot はその結果の上で推論するだけ**（全文再走査はしない）。

Copilot 向けプロンプトのテンプレート：

```
以下は「<要求>」の影響分析 JSON（オフライン索引ツールによる決定的なグラフ検索結果）です：
<python query/impact.py "<要求>" --json の出力を貼り付け>

これに基づいて出力してください：
1. 修正が必要なファイル一覧（ページ/Java/MyBatis/SQL に分類）。
2. 推奨修正順序（一般に：MyBatis SQL → Repository → Manager → Service → Controller → JSP）。
3. リスク：shared_tables に挙がる他モジュールが連動影響を受けるか。回帰テストすべき機能はどれか。
4. 影響チェーンに明らかな欠落（あるページがどの Controller にも繋がっていない等）があれば指摘。
```

---

## 社内ネットワークへのオフライン配置

1. インターネット接続のあるマシンで本ディレクトリを用意（**サードパーティ依存なし、`pip install` 不要**）。
2. 社内開発機へコピーし、`python --version` が 3.8 以上であることを確認。
3. 実プロジェクトのルートに対して `scan.py` を実行し `project.db` を得る。
4. Copilot が社内で `impact.py` を呼び、`--json` を読んで推論。

---

## 実プロジェクトに合わせた校正ポイント（詳細は PROJECT_NOTES_ja.md）

- インジェクションは `@Inject` を認識（`@Autowired/@Resource` も対応）。ジェネリクス `<...>` はスキップ。フィールド名≠型名なので変数→型でマッピング。
- データ/業務依存のサフィックス：`Service` / `Manager` / `Repository` / `Dao`。**裸の `Mapper` 型は除外**（Dozer の Bean コピーであり MyBatis ではない）。`new XxxImpl()` も依存として扱う。
- Service の業務入口は 2 通り：`executeService()`（直接実装）か `executeLogic()`（`AbstractNaviServiceImpl` を継承）。
- Controller の `return` 3 用法：`".../*.jsp"`(レンダー) / `"forward:/モジュール/XxxBL|SCR"`(エンドポイント転送) / ビュー名。
- JSP：`<wo:form action="${...}/モジュール/XxxDSP">`（`${...}` EL は自動除去）、`<jsp:include page="...">`。
- Repository 判定：`@Mapper` **または** 名前が `Repository`/`Dao` で終わる **または** XML namespace から参照される。メソッド名==sqlID（`r0001`/`i0002` のようなコードやオーバーロードあり）。
- MyBatis のテーブル抽出：`FROM|JOIN|INTO|UPDATE|DELETE FROM` の直後の識別子。**接頭辞のホワイトリストは使わない**（テーブルは `TB###`/`MA###`/`MB###`/`WA###`/`IAC_*` 等）。サブクエリ、`INNER/OUTER JOIN`、`EXISTS`、`INSERT…SELECT`、動的タグ `<where>/<if>/<foreach>/<trim>`、`<![CDATA[]]>`、Oracle 方言に対応。

## MVP の既知の限界 / 今後のフェーズ

- 解析は**正規表現＋軽量構造解析**（完全な AST ではない）。目標は高再現率：漏れよりも過剰列挙を優先し、Copilot に確認させる。
- `jsp/js → url → controller` は URL 正規化に依存する弱いリンク。強いリンクは `controller → service → manager → repository → sql → table` と `controller → jsp`(render)、`jsp → url → controller`(フォーム)。
- 今後：**ast-grep** で主要正規表現を置換し精度向上（TODO #1）；**batch** の識別（TODO #2）；任意で **ローカル LLM** により AI 層も完全社内化。

---

## セルフチェック（同梱サンプル）

```bash
python scanner/scan.py --root samples --out project.db --reset
python query/impact.py "案件検索" --db project.db
```

期待結果：
- 影響ページに `B01_SearchAnken.jsp`（および include される `commonGyomuHeader.jsp`）
- Java に `B01SearchAnkenController` / `SearchAnkenInitService` / `KokyakuManager`
- MyBatis に `AnkenRepository.xml` / `SharedAnkenRepository.xml`；SQL に `AnkenRepository.r0001` 等
- テーブルに `TB360_ANKEN_KANRI` / `TB070_CUSTOMER` / `TB400_ANKEN_FREE` / `WA110_ANKEN_TAIOU_RIREKI`
- **共用テーブル**：`TB070_CUSTOMER` の下に **a01kokyaku モジュール**（`A01SearchKokyakuController`/`SearchKokyakuService`/`KokyakuRepository`）が列挙され、逆方向の共用テーブル分析が機能していることを示す
```
