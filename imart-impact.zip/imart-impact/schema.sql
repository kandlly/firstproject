-- オフライン影響分析ナレッジベース schema（SQLite）
-- 汎用「グラフ」モデル：files / nodes / edges / glossary
-- 標準ライブラリ sqlite3 だけで読み書き可能。DB サーバー不要。

PRAGMA foreign_keys = ON;

-- ソースファイル登録テーブル
CREATE TABLE IF NOT EXISTS files (
    id        INTEGER PRIMARY KEY,
    path      TEXT NOT NULL,          -- 絶対パス（または元のパス）
    rel_path  TEXT NOT NULL UNIQUE,   -- プロジェクトルートからの相対パス（安定した識別子）
    type      TEXT NOT NULL           -- java|jsp|mybatis_xml|spring_xml|js|css
);

-- コード/リソースのノード
--   kind ∈ controller|service|mapper_interface|method|mapper_method
--          |sql|jsp_page|url|table|js_func
CREATE TABLE IF NOT EXISTS nodes (
    id       INTEGER PRIMARY KEY,
    file_id  INTEGER REFERENCES files(id),
    kind     TEXT NOT NULL,
    name     TEXT NOT NULL,          -- 短縮名（メソッド名/テーブル名/JSP ファイル名など）
    fqn      TEXT,                   -- 完全修飾名/一意キー（クラス完全名、namespace.method、URL など）
    line     INTEGER,                -- 定義行（ベストエフォート）
    UNIQUE(kind, fqn)
);

-- ノード間の関係
--   kind ∈ routes|renders|calls|maps_to|queries|includes|ajax|forward
CREATE TABLE IF NOT EXISTS edges (
    id        INTEGER PRIMARY KEY,
    src_id    INTEGER NOT NULL REFERENCES nodes(id),
    dst_id    INTEGER NOT NULL REFERENCES nodes(id),
    kind      TEXT NOT NULL,
    evidence  TEXT,                  -- そのエッジを生成した元コード断片（目視確認用）
    line      INTEGER,
    UNIQUE(src_id, dst_id, kind)
);

-- 業務用語（日本語/中国語）↔ コード識別子 の対訳表（任意・随時追記可）
CREATE TABLE IF NOT EXISTS glossary (
    term_cn      TEXT NOT NULL,
    keyword_code TEXT NOT NULL,
    UNIQUE(term_cn, keyword_code)
);

CREATE INDEX IF NOT EXISTS idx_nodes_name  ON nodes(name);
CREATE INDEX IF NOT EXISTS idx_nodes_kind  ON nodes(kind);
CREATE INDEX IF NOT EXISTS idx_edges_src   ON edges(src_id);
CREATE INDEX IF NOT EXISTS idx_edges_dst   ON edges(dst_id);
CREATE INDEX IF NOT EXISTS idx_files_rel   ON files(rel_path);
