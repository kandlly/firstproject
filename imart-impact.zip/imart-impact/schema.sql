-- 离线影响分析知识库 schema（SQLite）
-- 通用"图"模型：files / nodes / edges / glossary
-- 纯标准库 sqlite3 即可读写，无需数据库服务器。

PRAGMA foreign_keys = ON;

-- 源文件登记表
CREATE TABLE IF NOT EXISTS files (
    id        INTEGER PRIMARY KEY,
    path      TEXT NOT NULL,          -- 绝对或原始路径
    rel_path  TEXT NOT NULL UNIQUE,   -- 相对项目根路径（稳定标识）
    type      TEXT NOT NULL           -- java|jsp|mybatis_xml|spring_xml|js|css
);

-- 代码/资源节点
--   kind ∈ controller|service|mapper_interface|method|mapper_method
--          |sql|jsp_page|url|table|js_func
CREATE TABLE IF NOT EXISTS nodes (
    id       INTEGER PRIMARY KEY,
    file_id  INTEGER REFERENCES files(id),
    kind     TEXT NOT NULL,
    name     TEXT NOT NULL,          -- 简短名（方法名/表名/JSP 文件名等）
    fqn      TEXT,                   -- 全限定名/唯一键（类全名、namespace.method、URL 等）
    line     INTEGER,                -- 定义所在行（尽力而为）
    UNIQUE(kind, fqn)
);

-- 节点间关系
--   kind ∈ routes|renders|calls|maps_to|queries|includes|ajax
CREATE TABLE IF NOT EXISTS edges (
    id        INTEGER PRIMARY KEY,
    src_id    INTEGER NOT NULL REFERENCES nodes(id),
    dst_id    INTEGER NOT NULL REFERENCES nodes(id),
    kind      TEXT NOT NULL,
    evidence  TEXT,                  -- 触发该边的原始片段，便于人工复核
    line      INTEGER,
    UNIQUE(src_id, dst_id, kind)
);

-- 业务中文词 ↔ 代码标识 词表（可选、可增量维护）
CREATE TABLE IF NOT EXISTS glossary (
    term_cn      TEXT NOT NULL,
    keyword_code TEXT NOT NULL,
    UNIQUE(term_cn, keyword_code)
);

CREATE INDEX IF NOT EXISTS idx_nodes_name  ON nodes(name);
CREATE INDEX IF NOT EXISTS idx_nodes_kind  ON nodes(kind);
CREATE INDEX IF NOT EXISTS idx_edges_src   ON edges(src_id);
CREATE INDEX IF NOT EXISTS idx_edges_dst   ON edges(dst_id);
CREATE INDEX IF NOT EXISTS idx_files_rel   ON files(rel_path);
