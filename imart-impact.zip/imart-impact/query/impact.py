#!/usr/bin/env python3
"""影响分析查询 CLI。

给一个业务关键词（中文或英文），输出完整影响链：
    页面 / Java / MyBatis / SQL / 数据库表，以及共用这些表的其它模块。

用法：
    python query/impact.py "客户查询" --db project.db [--json]

工具只做确定性的图查询；风险与修改顺序的推理交由 Copilot 基于 --json 完成。
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from collections import defaultdict, deque

# 下游遍历所走的边（沿 src -> dst 方向即需求向下扩散）
FORWARD_KINDS = {"routes", "renders", "calls", "maps_to", "queries",
                 "includes", "ajax", "forward"}

# 在"影响 Java"里列出的类级节点（方法/mapper_method 只参与遍历，不单独列）
JAVA_CLASS_KINDS = {"controller", "service", "manager", "mapper_interface", "class"}


def connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def resolve_keywords(conn, query: str) -> list[str]:
    """把输入拆成 LIKE 关键词：ASCII 词 + 词表命中的中文桥接词。"""
    kws: set[str] = set()
    # 直接的英文/数字片段
    for tok in query.replace("/", " ").replace(".", " ").split():
        if tok.isascii() and len(tok) >= 2 and any(c.isalnum() for c in tok):
            kws.add(tok.lower())
    # 中文/业务词 -> 词表桥接（term_cn 作为输入子串命中）
    for row in conn.execute("SELECT term_cn, keyword_code FROM glossary"):
        if row["term_cn"] and row["term_cn"] in query:
            kws.add(row["keyword_code"].lower())
    return sorted(kws)


def entry_nodes(conn, keywords: list[str]) -> set[int]:
    ids: set[int] = set()
    for kw in keywords:
        like = f"%{kw}%"
        for row in conn.execute(
            "SELECT id FROM nodes WHERE lower(name) LIKE ? OR lower(fqn) LIKE ?",
            (like, like),
        ):
            ids.add(row["id"])
        # 文件名命中 -> 该文件对应的节点
        for row in conn.execute(
            "SELECT n.id FROM nodes n JOIN files f ON n.file_id=f.id "
            "WHERE lower(f.rel_path) LIKE ?",
            (like,),
        ):
            ids.add(row["id"])
    return ids


def load_edges(conn):
    fwd = defaultdict(list)   # src -> [(dst, kind)]
    rev = defaultdict(list)   # dst -> [(src, kind)]
    und = defaultdict(list)   # 无向邻接
    for e in conn.execute("SELECT src_id, dst_id, kind FROM edges"):
        s, d, k = e["src_id"], e["dst_id"], e["kind"]
        fwd[s].append((d, k))
        rev[d].append((s, k))
        und[s].append(d)
        und[d].append(s)
    return fwd, rev, und


def bfs_forward(start: set[int], fwd) -> set[int]:
    seen = set(start)
    q = deque(start)
    while q:
        cur = q.popleft()
        for dst, kind in fwd.get(cur, ()):
            if kind in FORWARD_KINDS and dst not in seen:
                seen.add(dst)
                q.append(dst)
    return seen


def bfs_undirected(start, und, exclude, kind_of, max_depth=6, block_kind=None):
    """从 start 无向扩散收集节点。

    block_kind 的节点（除起点外）只登记、不再向外扩展，避免经由公共表
    "桥接"到无关模块（例如经 CUSTOMER 表串到只共用 CUSTOMER 的模块）。
    """
    seen = set(start)
    result = set()
    q = deque((s, 0) for s in start)
    while q:
        cur, depth = q.popleft()
        if depth >= max_depth:
            continue
        if block_kind and cur not in start and kind_of.get(cur) == block_kind:
            continue
        for nb in und.get(cur, ()):
            if nb not in seen:
                seen.add(nb)
                if nb not in exclude:
                    result.add(nb)
                q.append((nb, depth + 1))
    return result


def node_row(conn, nid: int):
    return conn.execute(
        "SELECT n.id, n.kind, n.name, n.fqn, f.rel_path, f.type AS ftype "
        "FROM nodes n LEFT JOIN files f ON n.file_id=f.id WHERE n.id=?",
        (nid,),
    ).fetchone()


def build_report(conn, query: str, shared_depth: int = 6) -> dict:
    keywords = resolve_keywords(conn, query)
    starts = entry_nodes(conn, keywords)
    fwd, rev, und = load_edges(conn)
    kind_of = {r["id"]: r["kind"] for r in conn.execute("SELECT id, kind FROM nodes")}
    reached = bfs_forward(starts, fwd)

    rows = [node_row(conn, n) for n in reached]
    rows = [r for r in rows if r]

    pages, java, sql, tables, mybatis = [], [], [], set(), set()
    table_ids = set()
    for r in rows:
        if r["kind"] == "jsp_page":
            pages.append({"name": r["name"], "file": r["rel_path"]})
        elif r["kind"] in JAVA_CLASS_KINDS:
            if r["rel_path"] and r["rel_path"].endswith(".java"):
                java.append({"name": r["name"], "kind": r["kind"],
                             "file": r["rel_path"]})
        elif r["kind"] == "sql":
            sql.append({"name": r["name"], "fqn": r["fqn"], "file": r["rel_path"]})
            if r["rel_path"]:
                mybatis.add(r["rel_path"])
        elif r["kind"] == "table":
            tables.add(r["name"])
            table_ids.add(r["id"])

    # 去重 java（按 file+name）
    seen_j = set()
    java_u = []
    for j in java:
        key = (j["file"], j["name"], j["kind"])
        if key not in seen_j:
            seen_j.add(key)
            java_u.append(j)

    # 共用同表的其它模块：从表出发无向扩散，排除正向命中集
    shared = []
    for tid in table_ids:
        tname = node_row(conn, tid)["name"]
        others = bfs_undirected({tid}, und, exclude=reached, kind_of=kind_of,
                                max_depth=shared_depth, block_kind="table")
        mods = []
        for oid in others:
            orow = node_row(conn, oid)
            if orow and orow["kind"] in ("controller", "jsp_page",
                                         "mapper_interface", "service", "manager"):
                mods.append({"name": orow["name"], "kind": orow["kind"],
                             "file": orow["rel_path"]})
        # 去重
        uniq, seen_m = [], set()
        for m in mods:
            k = (m["kind"], m["name"])
            if k not in seen_m:
                seen_m.add(k)
                uniq.append(m)
        if uniq:
            shared.append({"table": tname, "modules": uniq})

    return {
        "query": query,
        "keywords": keywords,
        "matched_nodes": len(starts),
        "impact": {
            "pages": pages,
            "java": java_u,
            "mybatis": sorted(mybatis),
            "sql": sql,
            "tables": sorted(tables),
        },
        "shared_tables": shared,
    }


def print_report(rep: dict) -> None:
    q = rep["query"]
    print(f"\n=== 影响分析：{q} ===")
    print(f"关键词: {', '.join(rep['keywords']) or '(无)'}  "
          f"入口命中节点: {rep['matched_nodes']}")
    imp = rep["impact"]

    def section(title, items, fmt):
        print(f"\n【{title}】")
        if not items:
            print("  (无)")
            return
        for it in items:
            print("  - " + fmt(it))

    section("影响页面", imp["pages"], lambda x: f"{x['name']}  <{x['file']}>")
    section("影响 Java", imp["java"],
            lambda x: f"{x['name']}  [{x['kind']}]  <{x['file']}>")
    section("影响 MyBatis", imp["mybatis"], lambda x: x)
    section("影响 SQL", imp["sql"], lambda x: f"{x['fqn']}  <{x['file']}>")
    section("影响数据库表", imp["tables"], lambda x: x)

    print("\n【共用这些表的其它模块】")
    if not rep["shared_tables"]:
        print("  (无)")
    for st in rep["shared_tables"]:
        print(f"  表 {st['table']}:")
        for m in st["modules"]:
            print(f"    - {m['name']}  [{m['kind']}]  <{m['file']}>")
    print()


def main() -> None:
    ap = argparse.ArgumentParser(description="需求关键词 -> 影响链查询")
    ap.add_argument("query", help="业务关键词，如 '客户查询' 或 customer")
    ap.add_argument("--db", default="project.db", help="SQLite 知识库路径")
    ap.add_argument("--json", action="store_true", help="输出 JSON（供 Copilot 消费）")
    ap.add_argument("--shared-depth", type=int, default=6,
                    help="共用表反向扩散深度（表越热门可调小以免噪声）")
    args = ap.parse_args()

    conn = connect(args.db)
    rep = build_report(conn, args.query, shared_depth=args.shared_depth)
    conn.close()

    if args.json:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
    else:
        print_report(rep)


if __name__ == "__main__":
    main()
