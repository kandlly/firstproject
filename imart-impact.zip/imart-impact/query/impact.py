#!/usr/bin/env python3
"""影響分析検索 CLI。

業務キーワード（日本語/英語）を与えると、影響チェーン全体を出力する：
    ページ / Java / MyBatis / SQL / テーブル、およびそれらのテーブルを共用する他モジュール。

使い方：
    python query/impact.py "案件検索" --db project.db [--json]

ツールは決定的なグラフ検索のみを行う。リスクや修正順序の推論は --json を基に Copilot が行う。
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from collections import defaultdict, deque

# 下流に辿るエッジ（src -> dst 方向 ＝ 要求が下流へ波及する方向）
FORWARD_KINDS = {"routes", "renders", "calls", "maps_to", "queries",
                 "includes", "ajax", "forward"}

# 「影響 Java」に列挙するクラスレベルのノード（method/mapper_method は探索のみ・単独では出さない）
JAVA_CLASS_KINDS = {"controller", "service", "manager", "mapper_interface", "class"}


def connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def resolve_keywords(conn, query: str) -> list[str]:
    """入力を LIKE 用キーワードに分解：ASCII 語 + 用語表でヒットした語のコード識別子。"""
    kws: set[str] = set()
    # 直接の英数字トークン
    for tok in query.replace("/", " ").replace(".", " ").split():
        if tok.isascii() and len(tok) >= 2 and any(c.isalnum() for c in tok):
            kws.add(tok.lower())
    # 日本語/業務語 -> 用語表ブリッジ（term_cn が入力の部分文字列としてヒット）
    for row in conn.execute("SELECT term_cn, keyword_code FROM glossary"):
        if row["term_cn"] and row["term_cn"] in query:
            kws.add(row["keyword_code"].lower())
    return sorted(kws)


def entry_nodes(conn, keywords: list[str]) -> set[int]:
    ids: set[int] = set()
    for kw in keywords:
        like = f"%{kw}%"
        for row in conn.execute(
            "SELECT id FROM nodes WHERE lower(name) LIKE ? OR lower(fqn) LIKE ?",
            (like, like),
        ):
            ids.add(row["id"])
        # ファイル名ヒット -> そのファイルに属するノード
        for row in conn.execute(
            "SELECT n.id FROM nodes n JOIN files f ON n.file_id=f.id "
            "WHERE lower(f.rel_path) LIKE ?",
            (like,),
        ):
            ids.add(row["id"])
    return ids


def load_edges(conn):
    fwd = defaultdict(list)   # src -> [(dst, kind)]
    rev = defaultdict(list)   # dst -> [(src, kind)]
    und = defaultdict(list)   # 無向隣接
    for e in conn.execute("SELECT src_id, dst_id, kind FROM edges"):
        s, d, k = e["src_id"], e["dst_id"], e["kind"]
        fwd[s].append((d, k))
        rev[d].append((s, k))
        und[s].append(d)
        und[d].append(s)
    return fwd, rev, und


def bfs_forward(start: set[int], fwd) -> set[int]:
    seen = set(start)
    q = deque(start)
    while q:
        cur = q.popleft()
        for dst, kind in fwd.get(cur, ()):
            if kind in FORWARD_KINDS and dst not in seen:
                seen.add(dst)
                q.append(dst)
    return seen


def bfs_undirected(start, und, exclude, kind_of, max_depth=6, block_kind=None):
    """start から無向に拡散してノードを収集する。

    block_kind のノード（始点を除く）は登録のみで先へ拡張しない。共通テーブル経由で
    無関係なモジュールへ「橋渡し」してしまうのを防ぐ（例：CUSTOMER テーブルを介して
    CUSTOMER だけ共用する別モジュールまで繋がってしまう）。
    """
    seen = set(start)
    result = set()
    q = deque((s, 0) for s in start)
    while q:
        cur, depth = q.popleft()
        if depth >= max_depth:
            continue
        if block_kind and cur not in start and kind_of.get(cur) == block_kind:
            continue
        for nb in und.get(cur, ()):
            if nb not in seen:
                seen.add(nb)
                if nb not in exclude:
                    result.add(nb)
                q.append((nb, depth + 1))
    return result


def node_row(conn, nid: int):
    return conn.execute(
        "SELECT n.id, n.kind, n.name, n.fqn, f.rel_path, f.type AS ftype "
        "FROM nodes n LEFT JOIN files f ON n.file_id=f.id WHERE n.id=?",
        (nid,),
    ).fetchone()


def build_report(conn, query: str, shared_depth: int = 6) -> dict:
    keywords = resolve_keywords(conn, query)
    starts = entry_nodes(conn, keywords)
    fwd, rev, und = load_edges(conn)
    kind_of = {r["id"]: r["kind"] for r in conn.execute("SELECT id, kind FROM nodes")}
    reached = bfs_forward(starts, fwd)

    rows = [node_row(conn, n) for n in reached]
    rows = [r for r in rows if r]

    pages, java, sql, tables, mybatis = [], [], [], set(), set()
    table_ids = set()
    for r in rows:
        if r["kind"] == "jsp_page":
            pages.append({"name": r["name"], "file": r["rel_path"]})
        elif r["kind"] in JAVA_CLASS_KINDS:
            if r["rel_path"] and r["rel_path"].endswith(".java"):
                java.append({"name": r["name"], "kind": r["kind"],
                             "file": r["rel_path"]})
        elif r["kind"] == "sql":
            sql.append({"name": r["name"], "fqn": r["fqn"], "file": r["rel_path"]})
            if r["rel_path"]:
                mybatis.add(r["rel_path"])
        elif r["kind"] == "table":
            tables.add(r["name"])
            table_ids.add(r["id"])

    # java の重複排除（file+name+kind）
    seen_j = set()
    java_u = []
    for j in java:
        key = (j["file"], j["name"], j["kind"])
        if key not in seen_j:
            seen_j.add(key)
            java_u.append(j)

    # 同一テーブルを共用する他モジュール：テーブルから無向拡散し、正方向ヒット集合を除外
    shared = []
    for tid in table_ids:
        tname = node_row(conn, tid)["name"]
        others = bfs_undirected({tid}, und, exclude=reached, kind_of=kind_of,
                                max_depth=shared_depth, block_kind="table")
        mods = []
        for oid in others:
            orow = node_row(conn, oid)
            if orow and orow["kind"] in ("controller", "jsp_page",
                                         "mapper_interface", "service", "manager"):
                mods.append({"name": orow["name"], "kind": orow["kind"],
                             "file": orow["rel_path"]})
        # 重複排除
        uniq, seen_m = [], set()
        for m in mods:
            k = (m["kind"], m["name"])
            if k not in seen_m:
                seen_m.add(k)
                uniq.append(m)
        if uniq:
            shared.append({"table": tname, "modules": uniq})

    return {
        "query": query,
        "keywords": keywords,
        "matched_nodes": len(starts),
        "impact": {
            "pages": pages,
            "java": java_u,
            "mybatis": sorted(mybatis),
            "sql": sql,
            "tables": sorted(tables),
        },
        "shared_tables": shared,
    }


def print_report(rep: dict) -> None:
    q = rep["query"]
    print(f"\n=== 影響分析：{q} ===")
    print(f"キーワード: {', '.join(rep['keywords']) or '(なし)'}  "
          f"入口ヒットノード数: {rep['matched_nodes']}")
    imp = rep["impact"]

    def section(title, items, fmt):
        print(f"\n【{title}】")
        if not items:
            print("  (なし)")
            return
        for it in items:
            print("  - " + fmt(it))

    section("影響ページ", imp["pages"], lambda x: f"{x['name']}  <{x['file']}>")
    section("影響 Java", imp["java"],
            lambda x: f"{x['name']}  [{x['kind']}]  <{x['file']}>")
    section("影響 MyBatis", imp["mybatis"], lambda x: x)
    section("影響 SQL", imp["sql"], lambda x: f"{x['fqn']}  <{x['file']}>")
    section("影響テーブル", imp["tables"], lambda x: x)

    print("\n【これらのテーブルを共用する他モジュール】")
    if not rep["shared_tables"]:
        print("  (なし)")
    for st in rep["shared_tables"]:
        print(f"  テーブル {st['table']}:")
        for m in st["modules"]:
            print(f"    - {m['name']}  [{m['kind']}]  <{m['file']}>")
    print()


def main() -> None:
    ap = argparse.ArgumentParser(description="要求キーワード -> 影響チェーン検索")
    ap.add_argument("query", help="業務キーワード（例：'案件検索' または anken）")
    ap.add_argument("--db", default="project.db", help="SQLite ナレッジベースのパス")
    ap.add_argument("--json", action="store_true", help="JSON 出力（Copilot 用）")
    ap.add_argument("--shared-depth", type=int, default=6,
                    help="共用テーブルの逆探索の深さ（人気テーブルは小さくするとノイズ減）")
    args = ap.parse_args()

    conn = connect(args.db)
    rep = build_report(conn, args.query, shared_depth=args.shared_depth)
    conn.close()

    if args.json:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
    else:
        print_report(rep)


if __name__ == "__main__":
    main()
