"""SQLite 知识库封装：建库 + 节点/边 的幂等插入。

只用 Python 标准库 sqlite3，内网拷贝即用。
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.sql"


class KnowledgeDB:
    def __init__(self, db_path: str, reset: bool = False):
        self.db_path = Path(db_path)
        if reset and self.db_path.exists():
            self.db_path.unlink()
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._init_schema()

    def _init_schema(self) -> None:
        self.conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        self.conn.commit()

    # ---- 写入 -------------------------------------------------------------
    def add_file(self, path: str, rel_path: str, ftype: str) -> int:
        cur = self.conn.execute(
            "INSERT OR IGNORE INTO files(path, rel_path, type) VALUES (?,?,?)",
            (path, rel_path, ftype),
        )
        if cur.lastrowid and cur.rowcount:
            return cur.lastrowid
        row = self.conn.execute(
            "SELECT id FROM files WHERE rel_path=?", (rel_path,)
        ).fetchone()
        return row["id"]

    def add_node(
        self,
        kind: str,
        name: str,
        fqn: str,
        file_id: int | None = None,
        line: int | None = None,
    ) -> int:
        """按 (kind, fqn) 去重插入，返回节点 id。"""
        self.conn.execute(
            "INSERT OR IGNORE INTO nodes(file_id, kind, name, fqn, line) "
            "VALUES (?,?,?,?,?)",
            (file_id, kind, name, fqn, line),
        )
        row = self.conn.execute(
            "SELECT id FROM nodes WHERE kind=? AND fqn=?", (kind, fqn)
        ).fetchone()
        # 若首次插入时缺 file_id/line，后续补齐
        if file_id is not None:
            self.conn.execute(
                "UPDATE nodes SET file_id=COALESCE(file_id, ?), "
                "line=COALESCE(line, ?) WHERE id=?",
                (file_id, line, row["id"]),
            )
        return row["id"]

    def add_edge(
        self,
        src_id: int,
        dst_id: int,
        kind: str,
        evidence: str | None = None,
        line: int | None = None,
    ) -> None:
        if src_id is None or dst_id is None:
            return
        self.conn.execute(
            "INSERT OR IGNORE INTO edges(src_id, dst_id, kind, evidence, line) "
            "VALUES (?,?,?,?,?)",
            (src_id, dst_id, kind, evidence, line),
        )

    def add_glossary(self, term_cn: str, keyword_code: str) -> None:
        self.conn.execute(
            "INSERT OR IGNORE INTO glossary(term_cn, keyword_code) VALUES (?,?)",
            (term_cn, keyword_code),
        )

    def commit(self) -> None:
        self.conn.commit()

    def close(self) -> None:
        self.conn.commit()
        self.conn.close()
