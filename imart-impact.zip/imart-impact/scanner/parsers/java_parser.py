"""Java 解析器（校准版，针对 wiseoffice / intra-mart Accel Platform）。

分层：Controller → Service(接口+Impl) → Manager → Repository → MyBatis。
规则依据 PROJECT_NOTES.md（据真实代码截图整理）。MVP 用正则+方法体切片，
非完整 AST；ast-grep 升级见 TODO 需求 #1。
"""
from __future__ import annotations

import re

from .common import basename_no_ext, iter_methods, line_of, norm_url

_CLASS_RE = re.compile(r"\b(class|interface)\s+(\w+)")
_ANNO_CONTROLLER = re.compile(r"@(RestController|Controller)\b")
_ANNO_SERVICE = re.compile(r"@Service\b")
_ANNO_MAPPER = re.compile(r"@Mapper\b")

_CLASS_RM = re.compile(r'@RequestMapping\s*\(\s*(?:value\s*=\s*)?[\{"]([^"}\)]+)')
_MAPPING_RE = re.compile(
    r'@(?:RequestMapping|GetMapping|PostMapping|PutMapping|DeleteMapping)\s*'
    r'\(\s*(?:value\s*=\s*)?[\{"]?([^"}\),]+)'
)

# 依赖字段：@Inject/@Autowired/@Resource 可选；访问修饰符可选（真实代码里 @Inject
# 字段常无修饰符）；类型可带泛型 <...>；只认数据/业务层后缀（Service/Manager/
# Repository/Dao），排除裸 Mapper（Bean 拷贝器）。
_FIELD_RE = re.compile(
    r'(?:@(?:Inject|Autowired|Resource)\s+)?'
    r'(?:(?:private|protected|public)\s+)?(?:final\s+)?'
    r'([A-Z]\w+(?:Service|Manager|Repository|Dao))\s*(?:<[^>;]*>)?\s+(\w+)\s*[=;]'
)
# 直接实例化：new XxxServiceImpl() / new XxxManagerImpl()
_NEW_RE = re.compile(
    r'new\s+([A-Z]\w+(?:Service|Manager|Repository|Dao)(?:Impl)?)\s*\('
)

_RETURN_STR_RE = re.compile(r'return\s+"([^"]+)"')
_CALL_RE = re.compile(r'\b(\w+)\.(\w+)\s*\(')

_DATA_SUFFIX = re.compile(r"(Repository|Dao)$")
_INTERFACE_METHOD_RE = re.compile(r"[\w.<>\[\],\s]+?\s+(\w+)\s*\([^;{)]*\)\s*;")


def _classify(content: str, class_name: str, is_interface: bool) -> str:
    if _ANNO_CONTROLLER.search(content) or class_name.endswith("Controller"):
        return "controller"
    if re.search(r"(Repository|Dao)$", class_name) or (
        _ANNO_MAPPER.search(content) and is_interface
    ):
        return "mapper_interface"
    if class_name.endswith(("Manager", "ManagerImpl")):
        return "manager"
    if _ANNO_SERVICE.search(content) or class_name.endswith(("Service", "ServiceImpl")):
        return "service"
    return "class"


def _base_type(t: str) -> str:
    """去掉实现类的 Impl 后缀，让接口/实现归一到同一节点键。"""
    return t[:-4] if t.endswith("Impl") else t


def parse(db, file_id: int, rel_path: str, content: str) -> None:
    cls = _CLASS_RE.search(content)
    class_name = cls.group(2) if cls else basename_no_ext(rel_path)
    is_interface = bool(cls and cls.group(1) == "interface")
    class_line = line_of(content, cls.start()) if cls else 1
    kind = _classify(content, class_name, is_interface)

    node_key = _base_type(class_name)  # ServiceImpl/ManagerImpl 归一到接口名
    class_node = db.add_node(kind, node_key, node_key, file_id, class_line)

    # ---- Repository / Mapper 接口：方法即 mapper_method（=SQL statement id）----
    if kind == "mapper_interface":
        for am in _INTERFACE_METHOD_RE.finditer(content):
            mname = am.group(1)
            mline = line_of(content, am.start())
            mm = db.add_node("mapper_method", mname, f"{node_key}.{mname}",
                             file_id, mline)
            db.add_edge(class_node, mm, "calls", "repository method", mline)
        # 有方法体的实现类也扫一遍（RepositoryImpl，虽少见）
        for mname, mline, _b in iter_methods(content):
            mm = db.add_node("mapper_method", mname, f"{node_key}.{mname}",
                             file_id, mline)
            db.add_edge(class_node, mm, "calls", "repository method", mline)
        return

    # 依赖字段：变量名 -> 类型（去泛型、去 Impl）
    var_types: dict[str, str] = {}
    for fm in _FIELD_RE.finditer(content):
        var_types[fm.group(2)] = _base_type(fm.group(1))
    # new XxxImpl() 直接实例化，也当类级依赖
    for nm in _NEW_RE.finditer(content):
        tgt_type = _base_type(nm.group(1))
        _link_dep(db, class_node, tgt_type, tgt_type, f"new {nm.group(1)}()",
                  line_of(content, nm.start()))

    class_prefix = ""
    if kind == "controller":
        cp = _CLASS_RM.search(content)
        if cp:
            class_prefix = cp.group(1)

    for mname, mline, body in iter_methods(content):
        method_node = db.add_node("method", mname, f"{node_key}.{mname}",
                                  file_id, mline)
        db.add_edge(class_node, method_node, "calls", "declares", mline)

        if kind == "controller":
            _link_route(db, content, mname, method_node, class_prefix, mline)
            for rv in _RETURN_STR_RE.finditer(body):
                _link_return(db, method_node, rv.group(1), mline)

        # 调用点 var.method() -> service/manager/repository
        for cm in _CALL_RE.finditer(body):
            var, called = cm.group(1), cm.group(2)
            tgt_type = var_types.get(var)
            if tgt_type:
                _link_call(db, method_node, tgt_type, called, f"{var}.{called}()",
                           mline)


def _link_dep(db, src_node, tgt_type, called, evidence, line):
    """类级依赖（new 实例化）：连到目标类型的类节点。"""
    tkind = "mapper_interface" if _DATA_SUFFIX.search(tgt_type) else (
        "manager" if tgt_type.endswith("Manager") else "service")
    tgt = db.add_node(tkind, tgt_type, tgt_type)
    db.add_edge(src_node, tgt, "calls", evidence, line)


def _link_call(db, method_node, tgt_type, called, evidence, line):
    """方法调用点：数据层连 mapper_method，其余连 method。"""
    if _DATA_SUFFIX.search(tgt_type):
        tgt = db.add_node("mapper_method", called, f"{tgt_type}.{called}")
    else:
        tgt = db.add_node("method", called, f"{tgt_type}.{called}")
    db.add_edge(method_node, tgt, "calls", evidence, line)


def _link_return(db, method_node, ret, line):
    """Controller return 三义：.jsp 渲染 / forward:redirect: 转发 / 其它视图名。"""
    low = ret.lower()
    if low.startswith(("forward:", "redirect:")):
        path = norm_url(ret)
        if path:
            url_node = db.add_node("url", path, path)
            db.add_edge(method_node, url_node, "forward", f'return "{ret}"', line)
    elif low.endswith(".jsp"):
        base = basename_no_ext(ret)
        jsp = db.add_node("jsp_page", f"{base}.jsp", base)
        db.add_edge(method_node, jsp, "renders", f'return "{ret}"', line)
    elif "/" in ret and " " not in ret:  # 形如 "module/ViewName"
        base = basename_no_ext(ret)
        jsp = db.add_node("jsp_page", f"{base}.jsp", base)
        db.add_edge(method_node, jsp, "renders", f'return "{ret}"', line)


def _link_route(db, content, mname, method_node, class_prefix, mline):
    decl = re.search(rf"\b{re.escape(mname)}\s*\(", content)
    if not decl:
        return
    window = content[max(0, decl.start() - 300): decl.start()]
    mp = None
    for mp in _MAPPING_RE.finditer(window):
        pass  # 取最靠近方法的一个
    if not mp:
        return
    raw = (class_prefix + "/" + mp.group(1)) if class_prefix else mp.group(1)
    path = norm_url(raw)
    if not path:
        return
    url_node = db.add_node("url", path, path)
    db.add_edge(url_node, method_node, "routes", f"@Mapping {path}", mline)
