"""解析器公用小工具（纯标准库）。"""
from __future__ import annotations

import re


def line_of(text: str, idx: int) -> int:
    """返回字符偏移 idx 所在的 1-based 行号。"""
    return text.count("\n", 0, idx) + 1


def basename_no_ext(path: str) -> str:
    """取文件名去扩展名，用于 JSP 视图名/文件名的统一 key。"""
    name = path.replace("\\", "/").rsplit("/", 1)[-1]
    return name.rsplit(".", 1)[0]


_EL_RE = re.compile(r"\$\{[^}]*\}")


def norm_url(url: str) -> str:
    """URL 归一化：去 EL/前缀/查询串/末尾斜杠，统一小写。

    处理 JSP 里的 `${pageContext.request.contextPath}/b01anken/searchAnkenDSP`
    以及 Controller 里的 `forward:/b01anken/XxxBL`、`redirect:/...`。
    """
    url = url.strip().strip('"').strip("'")
    url = _EL_RE.sub("", url)                       # 去掉 ${...}
    url = re.sub(r"^(forward:|redirect:)", "", url)  # 去掉 forward:/redirect: 前缀
    url = url.split("?", 1)[0].split("#", 1)[0]
    url = url.lstrip("/").rstrip("/")
    return url.lower()


# 提取 Java 方法体：返回 [(method_name, start_line, body_text), ...]
_METHOD_RE = re.compile(
    r"(?:public|protected|private)\s+[\w<>\[\],\s]+?\s+(\w+)\s*\([^;{)]*\)\s*"
    r"(?:throws\s+[\w,\s]+)?\{",
)


def iter_methods(content: str):
    for m in _METHOD_RE.finditer(content):
        name = m.group(1)
        brace_start = content.index("{", m.start())
        depth = 0
        i = brace_start
        while i < len(content):
            c = content[i]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        body = content[brace_start + 1 : i]
        yield name, line_of(content, m.start()), body
