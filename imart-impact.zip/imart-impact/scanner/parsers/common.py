"""パーサー共通ユーティリティ（標準ライブラリのみ）。"""
from __future__ import annotations

import re


def line_of(text: str, idx: int) -> int:
    """文字オフセット idx が属する 1 始まりの行番号を返す。"""
    return text.count("\n", 0, idx) + 1


def basename_no_ext(path: str) -> str:
    """ファイル名から拡張子を除いた名前。JSP のビュー名/ファイル名の統一キーに使う。"""
    name = path.replace("\\", "/").rsplit("/", 1)[-1]
    return name.rsplit(".", 1)[0]


_EL_RE = re.compile(r"\$\{[^}]*\}")


def norm_url(url: str) -> str:
    """URL 正規化：EL/接頭辞/クエリ/末尾スラッシュを除去し小文字化。

    JSP の `${pageContext.request.contextPath}/b01anken/searchAnkenDSP` や
    Controller の `forward:/b01anken/XxxBL`、`redirect:/...` に対応する。
    """
    url = url.strip().strip('"').strip("'")
    url = _EL_RE.sub("", url)                        # ${...} を除去
    url = re.sub(r"^(forward:|redirect:)", "", url)  # forward:/redirect: 接頭辞を除去
    url = url.split("?", 1)[0].split("#", 1)[0]
    url = url.lstrip("/").rstrip("/")
    return url.lower()


# Java メソッド本体を抽出：[(method_name, start_line, body_text), ...] を返す
_METHOD_RE = re.compile(
    r"(?:public|protected|private)\s+[\w<>\[\],\s]+?\s+(\w+)\s*\([^;{)]*\)\s*"
    r"(?:throws\s+[\w,\s]+)?\{",
)


def iter_methods(content: str):
    for m in _METHOD_RE.finditer(content):
        name = m.group(1)
        brace_start = content.index("{", m.start())
        depth = 0
        i = brace_start
        while i < len(content):
            c = content[i]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        body = content[brace_start + 1 : i]
        yield name, line_of(content, m.start()), body
