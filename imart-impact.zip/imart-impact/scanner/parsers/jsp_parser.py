"""JSP パーサー：ページノード、include 関係、form/リンク/Ajax が指す URL。"""
from __future__ import annotations

import re

from .common import basename_no_ext, line_of, norm_url

_INCLUDE_RE = re.compile(
    r'(?:<%@\s*include\s+file\s*=|<jsp:include\s+page\s*=)\s*["\']([^"\']+)["\']'
)
# action=/href= —— <wo:form action="${...}/b01anken/searchAnkenDSP">、
# <form action=...>、<a href=...> をカバー。EL 接頭辞は norm_url が除去する。
_ACTION_RE = re.compile(r'\b(?:action|href)\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
# JS 内の ajax/url："xxx" 形式の url: / $.ajax({url:"..."}) / $.post("...")
_AJAX_RE = re.compile(
    r'(?:url\s*:\s*|\$\.(?:get|post|ajax)\s*\(\s*)["\']([^"\']+)["\']',
    re.IGNORECASE,
)


def parse(db, file_id: int, rel_path: str, content: str) -> None:
    base = basename_no_ext(rel_path)
    page = db.add_node("jsp_page", f"{base}.jsp", base, file_id, 1)

    for m in _INCLUDE_RE.finditer(content):
        inc_base = basename_no_ext(m.group(1))
        inc_node = db.add_node("jsp_page", f"{inc_base}.jsp", inc_base)
        db.add_edge(page, inc_node, "includes", m.group(1),
                    line_of(content, m.start()))

    for m in list(_ACTION_RE.finditer(content)) + list(_AJAX_RE.finditer(content)):
        raw = m.group(1)
        if raw.startswith(("http", "javascript:", "#", "mailto:")):
            continue
        path = norm_url(raw)
        if not path or path.endswith((".css", ".js", ".png", ".jpg", ".gif")):
            continue
        url_node = db.add_node("url", path, path)
        db.add_edge(page, url_node, "ajax", raw, line_of(content, m.start()))
