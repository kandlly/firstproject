"""MyBatis Mapper XML 解析器。

namespace -> mapper 接口；每个 <select|insert|update|delete id> -> 一条 sql；
sql 文本正则提取表名 -> queries 边。
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET

_STMT_TAGS = {"select", "insert", "update", "delete"}
_TABLE_RE = re.compile(
    r"\b(?:FROM|JOIN|UPDATE|INTO|DELETE\s+FROM)\s+([A-Za-z_][\w$.]*)",
    re.IGNORECASE,
)
# 避开 SQL 关键字被误当成表名
_STOP = {"SELECT", "WHERE", "SET", "VALUES", "DUAL", "ON", "AS"}


def is_mybatis(content: str) -> bool:
    return ("mybatis" in content.lower() and "mapper" in content.lower()) or (
        "<mapper" in content and "namespace" in content
    )


def _simple_ns(namespace: str) -> str:
    return namespace.rsplit(".", 1)[-1] if namespace else ""


def _collect_sql_fragments(root) -> dict[str, str]:
    frags = {}
    for el in root.iter("sql"):
        sid = el.get("id")
        if sid:
            frags[sid] = "".join(el.itertext())
    return frags


def _statement_text(el, frags: dict[str, str]) -> str:
    parts = ["".join(el.itertext())]
    for inc in el.iter("include"):
        ref = inc.get("refid")
        if ref and ref in frags:
            parts.append(frags[ref])
    return " ".join(parts)


def _extract_tables(sql: str) -> set[str]:
    tables = set()
    for m in _TABLE_RE.finditer(sql):
        name = m.group(1).strip().rstrip(",").split(".")[-1]
        up = name.upper()
        if up and up not in _STOP and not up.startswith("("):
            tables.add(up)
    return tables


_DOCTYPE_RE = re.compile(r"<!DOCTYPE[^>]*>", re.IGNORECASE)


def parse(db, file_id: int, rel_path: str, content: str) -> None:
    # 去掉 DOCTYPE，避免离线环境下解析器尝试拉取外部 mybatis DTD
    content = _DOCTYPE_RE.sub("", content, count=1)
    try:
        root = ET.fromstring(content)
    except ET.ParseError:
        return
    if root.tag != "mapper":
        return

    namespace = root.get("namespace", "")
    simple = _simple_ns(namespace) or rel_path.rsplit("/", 1)[-1].rsplit(".", 1)[0]
    mapper_node = db.add_node("mapper_interface", simple, simple, file_id, 1)

    frags = _collect_sql_fragments(root)

    for el in root.iter():
        if el.tag not in _STMT_TAGS:
            continue
        sid = el.get("id")
        if not sid:
            continue
        fqn = f"{simple}.{sid}"
        sql_node = db.add_node("sql", sid, fqn, file_id)
        # mapper 方法 <-> sql（与 java 侧 mapper_method 同 key，可自动对接）
        mm_node = db.add_node("mapper_method", sid, fqn, file_id)
        db.add_edge(mm_node, sql_node, "maps_to", f"{el.tag}#{sid}", None)
        db.add_edge(mapper_node, mm_node, "calls", "mapper method", None)

        sql_text = _statement_text(el, frags)
        for table in _extract_tables(sql_text):
            tbl_node = db.add_node("table", table, table)
            db.add_edge(sql_node, tbl_node, "queries", el.tag, None)
