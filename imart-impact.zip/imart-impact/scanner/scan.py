#!/usr/bin/env python3
"""プロジェクト走査エントリ：ソースルートを走査 -> 各種ファイルを解析 -> SQLite ナレッジベースへ書き込み。

使い方：
    python scanner/scan.py --root <プロジェクトルート> --out project.db [--reset]

Python 標準ライブラリのみに依存。閉じた社内ネットワークでオフライン実行可能。
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scanner.db import KnowledgeDB
from scanner.parsers import java_parser, jsp_parser, mybatis_parser

SKIP_DIRS = {".git", "node_modules", "target", "build", "dist", ".idea", ".svn"}


def classify(path: Path, content: str) -> str | None:
    suffix = path.suffix.lower()
    if suffix == ".java":
        return "java"
    if suffix in (".jsp", ".jspf", ".tag"):
        return "jsp"
    if suffix == ".xml":
        if mybatis_parser.is_mybatis(content):
            return "mybatis_xml"
        return "spring_xml"
    if suffix == ".js":
        return "js"
    if suffix == ".css":
        return "css"
    return None


def scan(root: str, out: str, reset: bool, glossary: str | None = None) -> dict:
    root_path = Path(root).resolve()
    db = KnowledgeDB(out, reset=reset)
    # 用語表：--glossary で指定があればそれを優先（ツール側に置けば被走査プロジェクトを汚さない）。
    # 無ければ被走査プロジェクトルート直下の glossary.csv を使う。
    gpath = Path(glossary).resolve() if glossary else (root_path / "glossary.csv")
    _load_glossary(db, gpath)

    stats = {"files": 0, "java": 0, "jsp": 0, "mybatis_xml": 0, "other": 0}

    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            fpath = Path(dirpath) / fn
            try:
                content = fpath.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            ftype = classify(fpath, content)
            if ftype is None:
                continue
            rel = str(fpath.relative_to(root_path))
            file_id = db.add_file(str(fpath), rel, ftype)
            stats["files"] += 1

            if ftype == "java":
                java_parser.parse(db, file_id, rel, content)
                stats["java"] += 1
            elif ftype == "jsp":
                jsp_parser.parse(db, file_id, rel, content)
                stats["jsp"] += 1
            elif ftype == "mybatis_xml":
                mybatis_parser.parse(db, file_id, rel, content)
                stats["mybatis_xml"] += 1
            else:
                stats["other"] += 1

    db.close()
    return stats


def _load_glossary(db: KnowledgeDB, gpath: Path) -> None:
    """任意：glossary.csv（列：term_cn,keyword_code）。日本語/中国語の要求語ブリッジ用。"""
    if not gpath.exists():
        return
    with gpath.open(encoding="utf-8") as f:
        for row in csv.reader(f):
            if len(row) >= 2 and row[0].strip() and not row[0].startswith("#"):
                db.add_glossary(row[0].strip(), row[1].strip())
    db.commit()


def main() -> None:
    ap = argparse.ArgumentParser(description="プロジェクトを走査し SQLite ナレッジベースを構築")
    ap.add_argument("--root", required=True, help="プロジェクトのソースルート")
    ap.add_argument("--out", default="project.db", help="出力先 SQLite ファイル")
    ap.add_argument("--reset", action="store_true", help="DB を作り直す")
    ap.add_argument("--glossary", default=None,
                    help="用語表 csv のパス（既定は <root>/glossary.csv）")
    args = ap.parse_args()

    stats = scan(args.root, args.out, args.reset, args.glossary)
    print(f"走査完了 -> {args.out}")
    print(
        f"  ファイル {stats['files']}  "
        f"(java {stats['java']}, jsp {stats['jsp']}, "
        f"mybatis_xml {stats['mybatis_xml']}, その他 {stats['other']})"
    )


if __name__ == "__main__":
    main()
