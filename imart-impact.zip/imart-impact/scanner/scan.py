#!/usr/bin/env python3
"""项目扫描入口：遍历源码根目录 -> 解析各类文件 -> 写入 SQLite 知识库。

用法：
    python scanner/scan.py --root <项目根> --out project.db [--reset]

只依赖 Python 标准库，可在封闭内网离线运行。
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scanner.db import KnowledgeDB
from scanner.parsers import java_parser, jsp_parser, mybatis_parser

SKIP_DIRS = {".git", "node_modules", "target", "build", "dist", ".idea", ".svn"}


def classify(path: Path, content: str) -> str | None:
    suffix = path.suffix.lower()
    if suffix == ".java":
        return "java"
    if suffix in (".jsp", ".jspf", ".tag"):
        return "jsp"
    if suffix == ".xml":
        if mybatis_parser.is_mybatis(content):
            return "mybatis_xml"
        return "spring_xml"
    if suffix == ".js":
        return "js"
    if suffix == ".css":
        return "css"
    return None


def scan(root: str, out: str, reset: bool, glossary: str | None = None) -> dict:
    root_path = Path(root).resolve()
    db = KnowledgeDB(out, reset=reset)
    # 词表：优先用 --glossary 指定的文件（可放工具目录，不污染被扫工程）；
    # 否则退回被扫项目根下的 glossary.csv。
    gpath = Path(glossary).resolve() if glossary else (root_path / "glossary.csv")
    _load_glossary(db, gpath)

    stats = {"files": 0, "java": 0, "jsp": 0, "mybatis_xml": 0, "other": 0}

    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            fpath = Path(dirpath) / fn
            try:
                content = fpath.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            ftype = classify(fpath, content)
            if ftype is None:
                continue
            rel = str(fpath.relative_to(root_path))
            file_id = db.add_file(str(fpath), rel, ftype)
            stats["files"] += 1

            if ftype == "java":
                java_parser.parse(db, file_id, rel, content)
                stats["java"] += 1
            elif ftype == "jsp":
                jsp_parser.parse(db, file_id, rel, content)
                stats["jsp"] += 1
            elif ftype == "mybatis_xml":
                mybatis_parser.parse(db, file_id, rel, content)
                stats["mybatis_xml"] += 1
            else:
                stats["other"] += 1

    db.close()
    return stats


def _load_glossary(db: KnowledgeDB, gpath: Path) -> None:
    """可选：glossary.csv（列：term_cn,keyword_code）用于中文需求词桥接。"""
    if not gpath.exists():
        return
    with gpath.open(encoding="utf-8") as f:
        for row in csv.reader(f):
            if len(row) >= 2 and row[0].strip() and not row[0].startswith("#"):
                db.add_glossary(row[0].strip(), row[1].strip())
    db.commit()


def main() -> None:
    ap = argparse.ArgumentParser(description="扫描项目源码，构建 SQLite 知识库")
    ap.add_argument("--root", required=True, help="项目源码根目录")
    ap.add_argument("--out", default="project.db", help="输出的 SQLite 文件")
    ap.add_argument("--reset", action="store_true", help="重建数据库")
    ap.add_argument("--glossary", default=None,
                    help="中文词表 csv 路径（默认取 <root>/glossary.csv）")
    args = ap.parse_args()

    stats = scan(args.root, args.out, args.reset, args.glossary)
    print(f"扫描完成 -> {args.out}")
    print(
        f"  文件 {stats['files']}  "
        f"(java {stats['java']}, jsp {stats['jsp']}, "
        f"mybatis_xml {stats['mybatis_xml']}, 其它 {stats['other']})"
    )


if __name__ == "__main__":
    main()
