# 需求清单（TODO）

> 记录本项目的需求与进展。新需求往下追加；状态：⬜ 待办 / 🔄 进行中 / ✅ 完成。

---

## 需求 #1：集成 ast-grep，提升 Java 解析精度

**状态**：⬜ 待办
**提出日期**：2026-07-07

**目标**：把 Java 层（Controller / Service / Mapper 调用链）的解析从"正则"升级为 **ast-grep**（AST 级），提升准确度；MyBatis XML 与 JSP 解析保持不变。

**要点 / 约束**：

- ast-grep 是单个预编译二进制，**不需要启动服务、不占端口、不常驻**（用法同 `grep`）。
- 内网离线：在能上网机器下载对应系统的预编译二进制 → 拷进内网 → 放进 PATH（或用绝对路径）。**不走 npm / cargo。**
- 集成方式：Python 用 `subprocess` 调 `ast-grep --json`，读结果写入 SQLite。**SQLite 表结构与 `impact.py` 查询逻辑不变。**
- 边界：ast-grep 只用于 **Java** 层；MyBatis XML 仍用 `xml.etree`，JSP 仍用正则。
- 需保留纯正则兜底：ast-grep 不在 PATH 时能自动回退到现有正则解析（内网可能一时装不上）。

**验收**：

- [ ] 在样例 `samples/` 上，ast-grep 版 Java 解析产出的节点/边 ≥ 现有正则版（不回退召回）。
- [ ] `ast-grep` 缺失时自动回退正则，脚本不报错。
- [ ] 更新 README，写明 ast-grep 的离线获取与部署方式。

---

## 需求 #2：支持 batch（批处理）程序的识别与影响分析

**状态**：⬜ 待办（**阻塞：需要真实 batch 文件样例**）
**提出日期**：2026-07-07

**背景**：项目里有 batch 程序，也是 Java 写的。目前扫描器会读 `.java`，但只认 `@Controller`/`@Service`/`@Mapper`，batch 类会被当成"未识别普通类"，且**其调用 Service/Mapper 的链路未被抓取** → batch 现在进不了影响分析，也不出现在"谁共用这张表"里。

**目标**：
- 新增 `batch` 节点类型，作为一种"入口"（与 controller 平级，但触发方式不同）。
- 抓取 batch → Service / Mapper → SQL → 表 的调用链，使 batch 能出现在影响分析和"共用表"反查里。

**待确认（阻塞项）——你项目里怎么认定一个类是 batch？**
- [ ] 继承某基类？（如 `extends AbstractBatch` / iMart 批处理基类，类名待告知）
- [ ] 实现某接口？
- [ ] 命名约定？（如 `*Batch` / `*Job`）
- [ ] 固定目录？
- [ ] batch 的触发/注册方式（调度配置、job 定义 XML 等）是否也要纳入分析？

**验收**：
- [ ] 给定一个已知 batch，能列出它触及的 Service/Mapper/SQL/表。
- [ ] 某张表被 batch 使用时，"共用这些表的其它模块"里能看到该 batch。

---

## 需求 #3：按真实项目校准解析器（wiseoffice / intra-mart Accel Platform）

**状态**：✅ 完成（2026-07-11）—— 三个解析器已重写校准，换真实结构样例端到端验证通过（案件↔顧客双向、共用 TB070_CUSTOMER 反查生效）。
**提出日期**：2026-07-11

**背景**：现有 MVP 的样例是"教科书 Spring/MyBatis"，与真实项目差异大。已用三批真实代码截图摸清全链路，规则细节见 `PROJECT_NOTES.md`。

**要做的校准点**：
- 注入认 `@Inject`（非 @Autowired）；跳过泛型 `<...>`；变量名≠类型名（按变量→类型映射）。
- 依赖层后缀：`Service` / `Manager` / `Repository`；**排除** `Mapper` 类型（那是 Dozer bean 拷贝器）；`new XxxImpl()` 也算依赖边。
- Service 入口两种：`executeService()` 或（继承 `AbstractNaviServiceImpl` 时）`executeLogic()`。
- Controller `return` 三义：`".../*.jsp"`(渲染) / `"forward:/模块/XxxBL|SCR"`(转发端点) / 错误页；DSP 靠 `params="event=..."` 分发。
- JSP：`<wo:form action="...">`、`onclick=executeXxxForward('forward_xxx')` + JS `form.event.value=` → 连 DSP 端点；`<jsp:include>` 相对/绝对路径。
- Repository：判 mapper 接口用「`@Mapper` 或 名字以 Repository 结尾 或 被 XML namespace 引用」；方法名==sqlID（可为 r0001/i0002 编码）；重载去重。
- MyBatis：现有 `xml.etree` + `FROM|JOIN|INTO|UPDATE|DELETE FROM` 正则可用；**抽表不用前缀白名单**（表有 TB/MA/MB/WA/IAC_ 等多种）；itertext 覆盖 `<where>/<if>/<foreach>/<trim>` 与 CDATA。

**验收**：拿真实项目一个已知功能（如 b01anken 案件检索）跑通，影响链能列到 `TB360_ANKEN_KANRI/TB070_CUSTOMER/...` 等表，并反查出共用表的其它模块。

---

## 待办（全局阻塞）

- [x] **拿到项目目录结构 + 全链路真实代码**：三批截图已整理 → 见 `PROJECT_NOTES.md`。intra-mart Accel Platform，链路 **JSP→JS→Controller(DSP/BL/SCR)→Service(接口+Impl)→Manager→Repository→MyBatis→SQL→表** 全部用真实代码验证。
- [ ] **需求 #3：按 PROJECT_NOTES 校准规则重写解析器**（见下方需求 #3）。
- [ ] **拿到真实 batch 文件**：定位 batch 目录 + 一个 `.java`，解锁需求 #2。
