<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<imui:head></imui:head>
<wo:form modelAttribute="searchAnkenForm"
    action="${pageContext.request.contextPath}/b01anken/searchAnkenDSP"
    id="searchAnkenForm" name="searchAnkenForm">

    <c:if test="${true}">
        <jsp:include page="../common/commonGyomuHeader.jsp" flush="true" />
    </c:if>

    <div class="subtitle">案件検索</div>

    <button type="button" name="forward_init"
        onclick="submitRuAnkenSommon('forward_init');">検索</button>

    <jsp:include page="/WEB-INF/views/common/message.jsp" flush="true" />
</wo:form>
