<%@ page contentType="text/html;charset=UTF-8" %>
<wo:form modelAttribute="searchKokyakuForm"
    action="${pageContext.request.contextPath}/a01kokyaku/searchKokyakuBL"
    id="searchKokyakuForm" name="searchKokyakuForm">

    <jsp:include page="../common/commonGyomuHeader.jsp" flush="true" />
    <div class="subtitle">顧客検索</div>
    <button type="submit">検索</button>
</wo:form>
