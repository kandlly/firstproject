package jp.wiseoffice.a01kokyaku.repository.tenant;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Mapper;
import jp.wiseoffice.fw.util.ExchangeMapEx;

@Mapper
public interface KokyakuRepository {

    /** sqlID "r0001" を実行する */
    List<ExchangeMapEx<String, String>> r0001(Map<String, Object> input);
}
