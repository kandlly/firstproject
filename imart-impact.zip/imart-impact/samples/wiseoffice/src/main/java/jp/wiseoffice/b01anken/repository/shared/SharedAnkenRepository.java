package jp.wiseoffice.b01anken.repository.shared;

/** SharedAnkenRepository のインタフェース（fw 級と同様、@Mapper 無し） */
public interface SharedAnkenRepository {

    /** sqlID "selectKokyakuName" を実行する */
    String selectKokyakuName(String kokyakuKanriNo);
}
