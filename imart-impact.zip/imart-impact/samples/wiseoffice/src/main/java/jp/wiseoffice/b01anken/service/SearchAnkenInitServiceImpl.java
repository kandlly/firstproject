package jp.wiseoffice.b01anken.service;

import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jp.wiseoffice.b01anken.repository.tenant.AnkenRepository;
import jp.wiseoffice.b01anken.manager.KokyakuManager;
import jp.wiseoffice.fw.blogic.BLogicResult;

@Service
@Transactional
public class SearchAnkenInitServiceImpl extends AbstractNaviServiceImpl<SearchAnkenBean>
        implements SearchAnkenInitService {

    /** 案件 Repository（直接注入） */
    @Inject
    private AnkenRepository ankenRepository;

    /** 顧客管理マネージャ */
    @Inject
    private KokyakuManager kokyakuManager;

    /** 基底クラスの executeService から呼ばれるテンプレートメソッド */
    @Override
    public BLogicResult executeLogic(SearchAnkenBean searchParam) {
        BLogicResult result = new BLogicResult();
        ankenRepository.r0001(searchParam.toMap());
        kokyakuManager.getKokyakuName(searchParam.getKokyakuKanriNo());
        return result;
    }
}
