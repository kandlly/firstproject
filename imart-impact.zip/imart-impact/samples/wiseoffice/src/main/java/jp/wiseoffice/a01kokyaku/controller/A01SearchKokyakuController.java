package jp.wiseoffice.a01kokyaku.controller;

import javax.inject.Inject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import jp.wiseoffice.a01kokyaku.service.SearchKokyakuService;
import jp.wiseoffice.fw.blogic.BLogicResult;

@Controller
public class A01SearchKokyakuController extends AbstractController {

    @Inject
    private SearchKokyakuService searchKokyakuService;

    @RequestMapping(value = "/a01kokyaku/searchKokyakuBL")
    public String executeA01kokyakuSearchKokyakuBL(SearchKokyakuForm form) {
        SearchKokyakuBean input = new SearchKokyakuBean();
        BLogicResult blogicResult = searchKokyakuService.executeService(input);
        return "forward:/a01kokyaku/searchKokyakuSCR";
    }

    @RequestMapping(value = "/a01kokyaku/searchKokyakuSCR")
    public String executeA01kokyakuSearchKokyakuSCR() {
        return "/a01kokyaku/A01_SearchKokyaku.jsp";
    }
}
