package jp.wiseoffice.b01anken.repository.tenant;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.RowBounds;
import jp.wiseoffice.fw.util.ExchangeMapEx;

/** AnkenRepository のインタフェース */
@Mapper
public interface AnkenRepository {

    /** sqlID "r0001" を実行する */
    List<ExchangeMapEx<String, String>> r0001(Map<String, Object> input);

    /** sqlID "r0001" を実行する（オーバーロード） */
    List<ExchangeMapEx<String, String>> r0001(Map<String, Object> input, RowBounds rowBounds);

    /** sqlID "i0002" を実行する */
    int i0002(Map input);
}
