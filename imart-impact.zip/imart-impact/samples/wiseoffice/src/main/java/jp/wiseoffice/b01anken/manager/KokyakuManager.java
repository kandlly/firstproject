package jp.wiseoffice.b01anken.manager;

/** 顧客情報管理マネージャ。 */
public interface KokyakuManager {
    String getKokyakuName(String kokyakuKanriNo);
}
