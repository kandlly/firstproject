package jp.wiseoffice.a01kokyaku.service;

import jp.wiseoffice.fw.blogic.BLogicResult;

public interface SearchKokyakuService {
    public BLogicResult executeService(SearchKokyakuBean searchParam);
}
