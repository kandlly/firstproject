package jp.wiseoffice.b01anken.service;

import jp.wiseoffice.fw.blogic.BLogicResult;

/** 案件検索画面初期表示。 */
public interface SearchAnkenInitService {
    public BLogicResult executeService(SearchAnkenBean searchParam);
}
