package jp.wiseoffice.b01anken.manager;

import javax.inject.Inject;
import jp.wiseoffice.b01anken.repository.shared.SharedAnkenRepository;

public class KokyakuManagerImpl implements KokyakuManager {

    @Inject
    private SharedAnkenRepository sharedAnkenRepository;

    @Override
    public String getKokyakuName(String kokyakuKanriNo) {
        return sharedAnkenRepository.selectKokyakuName(kokyakuKanriNo);
    }
}
