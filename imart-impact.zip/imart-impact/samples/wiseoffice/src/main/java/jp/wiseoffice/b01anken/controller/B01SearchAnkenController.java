package jp.wiseoffice.b01anken.controller;

import javax.inject.Inject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;
import jp.wiseoffice.b01anken.service.SearchAnkenInitService;
import jp.wiseoffice.fw.blogic.BLogicResult;

@Controller
public class B01SearchAnkenController extends AbstractController {

    /** Bean 拷贝器（Dozer 风格），非 MyBatis，应被扫描器忽略 */
    @Inject
    private Mapper beanMapper;

    @Inject
    private SearchAnkenInitService searchAnkenInitService;

    /** DispatchAction：按 event 分发，转发到 BL 端点 */
    @RequestMapping(value = "/b01anken/searchAnkenDSP", params = "event=forward_init")
    public String executeB01ankenSearchAnkenDSP_init() {
        return "forward:/b01anken/searchAnkenInitBL";
    }

    /** ServiceAction：调 Service，再转发到 SCR */
    @RequestMapping(value = "/b01anken/searchAnkenInitBL")
    public String executeB01ankenSearchAnkenInitBL(SearchAnkenForm form, Model model) {
        SearchAnkenBean input = beanMapper.map(form, SearchAnkenBean.class);
        BLogicResult blogicResult = searchAnkenInitService.executeService(input);
        return "forward:/b01anken/searchAnkenSCR";
    }

    /** ForwardAction：渲染 JSP */
    @RequestMapping(value = "/b01anken/searchAnkenSCR")
    public String executeB01ankenSearchAnkenSCR() {
        return "/b01anken/B01_SearchAnken.jsp";
    }
}
