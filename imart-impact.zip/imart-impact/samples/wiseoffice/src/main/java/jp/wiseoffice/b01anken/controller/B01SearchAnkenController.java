package jp.wiseoffice.b01anken.controller;

import javax.inject.Inject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;
import jp.wiseoffice.b01anken.service.SearchAnkenInitService;
import jp.wiseoffice.fw.blogic.BLogicResult;

@Controller
public class B01SearchAnkenController extends AbstractController {

    /** Bean コピー（Dozer 系）。MyBatis ではないためスキャナは無視すべき */
    @Inject
    private Mapper beanMapper;

    @Inject
    private SearchAnkenInitService searchAnkenInitService;

    /** DispatchAction：event で分岐し、BL エンドポイントへ forward する */
    @RequestMapping(value = "/b01anken/searchAnkenDSP", params = "event=forward_init")
    public String executeB01ankenSearchAnkenDSP_init() {
        return "forward:/b01anken/searchAnkenInitBL";
    }

    /** ServiceAction：Service を呼び、SCR へ forward する */
    @RequestMapping(value = "/b01anken/searchAnkenInitBL")
    public String executeB01ankenSearchAnkenInitBL(SearchAnkenForm form, Model model) {
        SearchAnkenBean input = beanMapper.map(form, SearchAnkenBean.class);
        BLogicResult blogicResult = searchAnkenInitService.executeService(input);
        return "forward:/b01anken/searchAnkenSCR";
    }

    /** ForwardAction：JSP をレンダリングする */
    @RequestMapping(value = "/b01anken/searchAnkenSCR")
    public String executeB01ankenSearchAnkenSCR() {
        return "/b01anken/B01_SearchAnken.jsp";
    }
}
