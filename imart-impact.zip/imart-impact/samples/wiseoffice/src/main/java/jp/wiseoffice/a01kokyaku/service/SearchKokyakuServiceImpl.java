package jp.wiseoffice.a01kokyaku.service;

import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jp.wiseoffice.a01kokyaku.repository.tenant.KokyakuRepository;
import jp.wiseoffice.fw.blogic.BLogicResult;

@Service
@Transactional
public class SearchKokyakuServiceImpl implements SearchKokyakuService {

    @Inject
    private KokyakuRepository kokyakuRepository;

    @Override
    public BLogicResult executeService(SearchKokyakuBean searchParam) {
        BLogicResult result = new BLogicResult();
        kokyakuRepository.r0001(searchParam.toMap());
        return result;
    }
}
