# iMart 离线影响分析（MVP）

> 🌐 语言 / 言語：**中文**（本页） ・ [日本語](README_ja.md)

给一个业务需求关键词（中文/日文/英文），自动输出需要修改的文件影响链：

```
JSP → JS → Controller(DSP/BL/SCR) → Service(接口+Impl) → Manager → Repository → MyBatis XML → SQL → 数据库表
```

并反向分析：**哪些其它模块共用了这些数据库表**。

**分工**：工具只做确定性的索引与图查询；风险评估、修改顺序等推理交给 Copilot（AI）。
全流程纯 Python 标准库，**完全离线**，适合封闭内网。

> 解析规则已按真实项目（wiseoffice / intra-mart Accel Platform）校准，细节见 `PROJECT_NOTES.md`。

---

## 目录结构

```
imart-impact/
  schema.sql                     # SQLite 知识库表结构（通用 files/nodes/edges/glossary 图模型）
  scanner/
    scan.py                      # 扫描入口
    db.py                        # 建库 / 插入封装
    parsers/
      java_parser.py             # Controller/Service/Manager/Repository 及调用关系
      mybatis_parser.py          # namespace / statement id / SQL / 表名
      jsp_parser.py              # 页面 / include / 表单(wo:form)链接
      common.py                  # 公用工具
  query/
    impact.py                    # 需求关键词 → 影响链（文本 / --json）
  samples/                       # 真实结构样例（wiseoffice：b01anken 案件 + a01kokyaku 顧客，共用 TB070_CUSTOMER）
    glossary.csv                 # 业务中文/日文词 ↔ 代码标识 词表
  PROJECT_NOTES.md               # 真实项目结构与解析校准要点
  TODO.md                        # 需求清单与进展
  requirements.txt               # 仅标准库；Python 3.8+
```

---

## 使用（两步）

### 1. 扫描项目，构建知识库

```bash
python scanner/scan.py --root <项目源码根目录> --out project.db --reset
```

- 遍历 `.java/.jsp/.xml/.js/.css`，跳过 `target/node_modules/.git` 等。
- 若项目根下存在 `glossary.csv`（列：`term_cn,keyword_code`），自动载入，用于中文需求词桥接。
- 产物 `project.db` 是单个 SQLite 文件，拷贝即可分发。

### 2. 查询影响链

```bash
python query/impact.py "案件検索" --db project.db          # 人读报告
python query/impact.py "案件検索" --db project.db --json    # 给 Copilot 的结构化结果
python query/impact.py anken       --db project.db          # 直接用英文/罗马字标识
```

`--shared-depth N`（默认 6）：共用表反向扩散深度；若某表非常"热门"（如 IAC_* 框架表）导致噪声，可调小。

---

## 关键词如何匹配（中文需求 → 代码）

代码标识是英文/罗马字，需求常是中文/日文。两种桥接方式：

1. **词表**：在项目根维护 `glossary.csv`（如 `案件,anken`、`顧客,kokyaku`）。查询含"案件"时自动带上 `anken` 关键词。词表可随项目增量补充。
2. **Copilot 直接翻译**：Copilot 先把"案件検索"理解为 `anken` 再调用 CLI。

英文关键词按 `LIKE %kw%` 匹配 `节点名 / 全限定名 / 文件路径`；再沿关系图 BFS 扩散出完整影响链。

---

## 与 Copilot 的协作（AI 分析层）

固定用法：**先跑 CLI 拿确定性图结果，Copilot 只在结果上推理**（不重复全文扫描）。

给 Copilot 的提示模板：

```
下面是「<需求>」的影响分析 JSON（来自离线索引工具，确定性图查询结果）：
<粘贴 python query/impact.py "<需求>" --json 的输出>

请基于它输出：
1. 需要修改的文件清单（按 页面/Java/MyBatis/SQL 分组）。
2. 建议修改顺序（一般：MyBatis SQL → Repository → Manager → Service → Controller → JSP）。
3. 风险点：shared_tables 中列出的其它模块是否会被联动影响，需要回归测试哪些功能。
4. 若发现影响链有明显缺口（如某页面未连上 Controller），指出可能是索引规则未覆盖的写法。
```

---

## 内网离线部署

1. 在能联网的机器上准备好本目录（**无第三方依赖，无需 `pip install`**）。
2. 拷贝到内网开发机，确认 `python --version` ≥ 3.8。
3. 对真实项目根跑 `scan.py`，得到 `project.db`。
4. Copilot 在内网调用 `impact.py` 并读取 `--json` 做推理。

---

## 已按真实项目校准的规则要点（详见 PROJECT_NOTES.md）

- 注入认 `@Inject`（也兼容 @Autowired/@Resource）；跳过泛型 `<...>`；按变量名→类型映射（字段名≠类型名）。
- 数据/业务依赖后缀：`Service` / `Manager` / `Repository` / `Dao`；**排除裸 `Mapper` 类型**（Dozer Bean 拷贝器，非 MyBatis）；`new XxxImpl()` 也算依赖。
- Service 业务入口两种：`executeService()`（直接实现）或 `executeLogic()`（继承 `AbstractNaviServiceImpl`）。
- Controller `return` 三义：`".../*.jsp"`(渲染) / `"forward:/模块/XxxBL|SCR"`(转发端点) / 视图名。
- JSP：`<wo:form action="${...}/模块/XxxDSP">`（自动去 `${...}` EL）、`<jsp:include page="...">`。
- Repository 判定：`@Mapper` **或** 名以 `Repository`/`Dao` 结尾 **或** 被某 XML namespace 引用；方法名==sqlID（可为 `r0001`/`i0002` 编码，含重载）。
- MyBatis 抽表：`FROM|JOIN|INTO|UPDATE|DELETE FROM` 后的标识符，**不用前缀白名单**（表有 `TB###`/`MA###`/`MB###`/`WA###`/`IAC_*` 等）；覆盖子查询、`INNER/OUTER JOIN`、`EXISTS`、`INSERT…SELECT`、动态 `<where>/<if>/<foreach>/<trim>`、`<![CDATA[]]>`、Oracle 方言。

## MVP 已知边界 / 后续阶段

- 解析基于**正则 + 轻量结构**（非完整 AST），目标高召回：宁可多列候选，交由 Copilot 复核。
- `jsp/js → url → controller` 依赖 URL 归一化，属弱链路；强链路是 `controller → service → manager → repository → sql → table` 与 `controller → jsp`(render)、`jsp → url → controller`(表单)。
- 后续：**ast-grep** 替换关键正则提升精度（TODO #1）；**batch** 识别（TODO #2）；可选 **本地 LLM** 使 AI 层也完全内网化。

---

## 自验（用内置样例）

```bash
python scanner/scan.py --root samples --out project.db --reset
python query/impact.py "案件検索" --db project.db
```

预期：
- 影响页面含 `B01_SearchAnken.jsp`（及被 include 的 `commonGyomuHeader.jsp`）
- Java 含 `B01SearchAnkenController` / `SearchAnkenInitService` / `KokyakuManager`
- MyBatis 含 `AnkenRepository.xml` / `SharedAnkenRepository.xml`；SQL 含 `AnkenRepository.r0001` 等
- 表含 `TB360_ANKEN_KANRI` / `TB070_CUSTOMER` / `TB400_ANKEN_FREE` / `WA110_ANKEN_TAIOU_RIREKI`
- **共用表模块**：`TB070_CUSTOMER` 下列出 **a01kokyaku 模块**（`A01SearchKokyakuController`/`SearchKokyakuService`/`KokyakuRepository`），证明反向共用表分析生效
```
