# インストールと実行ガイド（オフライン社内ネットワーク）

> 🌐 言語 / 语言：**日本語**（本ページ） ・ [中文](INSTALL_安装与运行.md)

**利用者向け**。3 ステップだけ：Python を入れる → 走査する → 検索する。オフラインで完結、サードパーティ不要。

---

## 0. 前提：必要なのは Python だけ

本ツールは **Python 標準ライブラリのみ**（`sqlite3`、`re`、`xml.etree`、`argparse`、`json`、`csv`、`os`、`pathlib`）を使うため、
社内マシンには：

| 必要 | 不要 |
|---|---|
| ✅ Python **3.8 以上** | ❌ pip / オンラインのパッケージ導入 |
| （任意）`sqlite3` コマンド（DB を手で見る場合のみ） | ❌ DB サーバー（SQLite は Python 同梱） |
| | ❌ Java / Node / Tomcat / OpenGrok / ast-grep |

> ⚠️ **3.11 または 3.12** が無難です。**Python 2 は不可**（古い社内機は `python` が 2.x を指すことがある）。

### 社内での Python 導入（オフライン）
1. インターネット接続機で対応 OS のオフラインインストーラを入手（Windows は `.exe`）。
2. 社内へコピーして導入。ターミナルで確認：
   ```bat
   python --version      :: または python3 --version
   ```
   `Python 3.8.x` 以上が出れば OK。以降はオフラインで動作します。

---

## 1. 本ツールの配置

**`imart-impact/` は対象プロジェクトの外に展開してください**（対象工程の中に置くと、ツール同梱の
`samples/` まで走査され、工程の git 作業ツリーも汚れます）。任意の場所で可、例：
```
C:\tools\imart-impact\        ← 推奨：ツール専用
または C:\Git\imart-impact\    ← wiseofficeplus と同階層（その外側）
```
**ビルド不要・インストール手順なし**、展開すればそのまま使えます。

### まずサンプルでツール自体の動作確認（最初に強く推奨）
`imart-impact/` ディレクトリで：
```bat
python scanner\scan.py --root samples --out project.db --reset
python query\impact.py "案件検索" --db project.db
```
「影響分析」レポート（ページ / Java / MyBatis / SQL / テーブル / 共用テーブル）が表示されれば、
**Python 環境もツールも正常**。次に実プロジェクトへ進みます。

---

## 2. 実プロジェクトへの実行

### ステップ 1：走査してナレッジベースを構築

**ツールのディレクトリ**（`imart-impact\`）で実行し、`--root` は**単一の業務工程フォルダ**を指す：
```bat
python scanner\scan.py --root C:\Git\wiseofficeplus\wiseoffice --out project.db --reset --glossary samples\glossary.csv
```
- `--root`：業務工程のルート（`src` / `src\main\java` が見える階層）。
  ⚠️ **`wiseofficeplus` を指さないこと**（配下に `wiseoffice_juggling_BASE/IT/local/PRD` 等の環境コピーがあり、重複走査で結果が混ざる）。分析対象の**単一** `wiseoffice`（または対象モジュール工程）を指す。
- `--out`：ナレッジベースのファイル名（既定 `project.db`。単なるファイルでコピー可）。
- `--reset`：作り直し（コードを大きく変えたら再実行）。
- `--glossary`：用語表のパス（下記）。`target` ビルド成果物・`.git` は自動スキップ。
- 実行後、走査したファイル数（java / jsp / mybatis_xml）を表示。

> **日本語要求語のブリッジ（`glossary.csv`）**：`業務語,コード識別子`（例：`案件,anken`）の 2 列。
> `--glossary` で指定します（**ツール側に置くのを推奨**、例：`imart-impact\samples\glossary.csv`。
> これで対象の git 工程にファイルを置かずに済む）。未指定時は `--root` 直下の `glossary.csv` を探す。
> 用語表は随時追記可。検索時に英語/ローマ字（`anken` 等）を直接使えば用語表を省略も可。

### ステップ 2：ある要求の影響チェーンを検索
```bat
:: 人が読むレポート
python query\impact.py "案件検索" --db project.db

:: Copilot 用の JSON
python query\impact.py "案件検索" --db project.db --json

:: 英語/ローマ字の識別子でも可
python query\impact.py anken --db project.db
```
- コード未変更なら、ステップ 2 を繰り返すだけ（高速）。
- コードを大きく変えたら、ステップ 1 で `project.db` を更新。
- `--shared-depth N`（既定 6）：あるテーブルが「人気」すぎて共用モジュールが多すぎる場合、小さく（例 `--shared-depth 3`）。

---

## 3. 結果を社内 Copilot に渡す

ツールは**決定的なグラフ検索**のみ。リスク/修正順序などの**推論**は Copilot に任せます。標準手順：

1. JSON を出力：
   ```bat
   python query\impact.py "案件検索" --db project.db --json > result.json
   ```
2. `result.json` の内容を Copilot に貼り、次のプロンプトを添える（固定で再利用可）：

```
以下は「案件検索」の影響分析 JSON（オフライン索引ツールによる決定的なグラフ検索結果です）：
<ここに result.json の内容を貼り付け>

これに基づいて出力してください：
1. 修正が必要なファイル一覧を ページ / Java / MyBatis / SQL に分類。
2. 推奨修正順序（一般に：MyBatis SQL → Repository → Manager → Service → Controller → JSP）。
3. リスク：shared_tables の他モジュールが連動影響を受けるか？回帰テストすべき機能は？
4. 影響チェーンに明らかな欠落（あるページがどの Controller にも繋がっていない等）があれば指摘。
```

> JSON 構造：`{ query, keywords, matched_nodes, impact:{pages,java,mybatis,sql,tables}, shared_tables:[{table,modules}] }`。
> Copilot はこの構造を読むだけでよく、ソースを再走査する必要はありません。

---

## よくある質問（早見表）

| 症状 | 原因 / 対処 |
|---|---|
| `python: command not found` | `python3` を使う。または Python 未導入/PATH 未設定。 |
| 構文エラー・型注釈エラー | Python が古い（<3.8）か Python 2。3.11/3.12 に。 |
| 走査ファイル数が 0 | `--root` が不正、または `.java/.jsp/.xml` が無い。 |
| 日本語要求で結果が出ない | `glossary.csv` に語を追加（例 `案件,anken`）、または英語識別子で検索。 |
| 影響チェーンの一部が欠ける | `docs/MAINTENANCE_ja.md`「トラブル対応表」を参照。症状を社内 AI に渡して解析ルールを直す。 |

> 解析ルールは一度で全書式を網羅できません。**初回は実プロジェクトで、よく知っている機能を 3〜5 個検索し、
> 漏れ/過剰を目視確認**してから正規表現を微調整してください。本ツールは「高再現率・人/AI が確認」する位置づけで、
> 100% 精密な自動化ではありません。
