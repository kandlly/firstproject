# 安装与运行指南（内网离线）

> 🌐 语言 / 言語：**中文**（本页） ・ [日本語](INSTALL_ja.md)

面向**使用者**。只要三步：装 Python → 跑扫描 → 跑查询。全程不联网、不装任何第三方库。

---

## 0. 先决条件：只需要 Python

这套工具**只用 Python 标准库**（`sqlite3`、`re`、`xml.etree`、`argparse`、`json`、`csv`、`os`、`pathlib`），
所以内网机器上：

| 需要 | 不需要 |
|---|---|
| ✅ Python **3.8 或以上** | ❌ pip / 联网装包 |
| （可选）`sqlite3` 命令行，仅用于手动查库 | ❌ 数据库服务器（SQLite 是 Python 自带的） |
| | ❌ Java / Node / Tomcat / OpenGrok / ast-grep |

> ⚠️ 没有 "Python 15" 这种版本。装 **3.11 或 3.12** 最稳。**别用 Python 2**（老机器默认可能是 2.x，跑不了）。

### 内网怎么装 Python（离线）
1. 在能上网的机器下载对应系统的 Python 离线安装包（Windows: `.exe`；Linux: 系统源或离线 rpm/deb）。
2. 拷进内网安装。装完开个终端敲：
   ```bash
   python --version      # 或 python3 --version
   ```
   看到 `Python 3.8.x` 以上就 OK，之后**全程可断网**。

---

## 1. 部署这套工具

**把 `imart-impact/` 解压到你工程目录的外面**（不要放进被扫的工程里，否则会扫到工具自带的
`samples/`，也会污染工程的 git 工作区）。放哪都行，例如：
```
C:\tools\imart-impact\        ← 推荐：专门放工具
或 C:\Git\imart-impact\        ← 与你的 wiseofficeplus 平级（在它外面）
```
**没有编译、没有安装步骤**，解压即用。
目录长这样（关键的就这几个）：

```
imart-impact/
  scanner/scan.py          # 第一步：扫描项目建库
  query/impact.py          # 第二步：查询影响链
  scanner/parsers/*.py     # 解析规则（出问题主要改这里）
  schema.sql               # 知识库表结构
  samples/                 # 自带样例（先用它验证工具能跑）
  docs/                    # 本文档 + 维护指南
```

### 先用样例确认工具本身能跑（强烈建议第一步先做这个）
在 `imart-impact/` 目录下执行：
```bash
python scanner/scan.py --root samples --out project.db --reset
python query/impact.py "案件検索" --db project.db
```
如果能打印出一份「影响分析」报告（页面 / Java / MyBatis / SQL / 表 / 共用表模块），
说明 **Python 环境和工具都正常**。接下来才轮到你的真实项目。

---

## 2. 对你的真实项目跑

### 第一步：扫描，建知识库

在**工具目录**（`imart-impact\`）下执行，`--root` 指向你的**单个业务工程文件夹**：
```bat
python scanner\scan.py --root C:\Git\wiseofficeplus\wiseoffice --out project.db --reset --glossary samples\glossary.csv
```
- `--root`：指向业务工程根（能看到 `src` / `src\main\java` 那一层）。
  ⚠️ **不要指到 `wiseofficeplus`**（那层下面有 `wiseoffice_juggling_BASE/IT/local/PRD` 等环境副本，会重复扫、结果串味）；就指**单个** `wiseoffice`（或你要分析的那个模块工程）。
- `--out`：生成的知识库文件名，默认 `project.db`（一个普通文件，可随便拷贝）。
- `--reset`：重建（每次代码有较大改动后重跑一次即可）。
- `--glossary`：中文词表路径（见下）。`target` 编译产物、`.git` 会被自动跳过。
- 跑完会打印扫描到的文件数（java / jsp / mybatis_xml）。

> **中文/日文需求词桥接（`glossary.csv`）**：两列 `业务词,代码标识`（如 `案件,anken`）。
> 用 `--glossary` 指向它即可（**推荐放在工具目录里**，如 `imart-impact\samples\glossary.csv`，
> 这样不会往你的 git 工程里丢文件）。不加 `--glossary` 时，工具会去 `--root` 目录下找 `glossary.csv`。
> 词表可随项目增量补充；也可以查询时直接用英文/罗马字（如 `anken`）绕过词表。

### 第二步：查询某个需求的影响链
```bash
# 给人看的报告
python query/impact.py "案件検索" --db project.db

# 给 Copilot 吃的 JSON
python query/impact.py "案件検索" --db project.db --json

# 也可以直接用英文/罗马字标识
python query/impact.py anken --db project.db
```
- 代码没变时，反复跑第二步就行（很快）。
- 代码大改了，重跑第一步刷新 `project.db`。
- `--shared-depth N`（默认 6）：某张表太"热门"导致共用模块列太多时，调小一点（如 `--shared-depth 3`）。

---

## 3. 把结果交给内网 Copilot

工具只做**确定性的图查询**，风险/修改顺序这类**推理**交给 Copilot。标准做法：

1. 跑出 JSON：
   ```bash
   python query/impact.py "案件検索" --db project.db --json > result.json
   ```
2. 把 `result.json` 的内容贴给 Copilot，并配这段提示词（可固定复用）：

```
下面是「案件検索」的影响分析 JSON（来自离线索引工具，是确定性的图查询结果，不是猜的）：
<在此粘贴 result.json 内容>

请基于它输出：
1. 需要修改的文件清单，按 页面 / Java / MyBatis / SQL 分组。
2. 建议修改顺序（一般：MyBatis SQL → Repository → Manager → Service → Controller → JSP）。
3. 风险点：shared_tables 里列出的其它模块会不会被联动影响？需要回归测试哪些功能？
4. 如果影响链有明显缺口（比如某页面没连上任何 Controller），指出来——可能是索引规则没覆盖到某种写法。
```

> JSON 结构：`{ query, keywords, matched_nodes, impact:{pages,java,mybatis,sql,tables}, shared_tables:[{table,modules}] }`。
> Copilot 直接读这个结构即可，不需要它再去翻源码。

---

## 常见问题速查

| 现象 | 可能原因 / 处理 |
|---|---|
| `python: command not found` | 用 `python3`；或 Python 没装/没进 PATH。 |
| 报语法错误、类型注解报错 | Python 版本太低（<3.8）或用了 Python 2。换 3.11/3.12。 |
| 扫描文件数是 0 | `--root` 路径不对，或项目里没有 `.java/.jsp/.xml`。 |
| 中文需求查不到结果 | 在项目根加/补 `glossary.csv`（如 `案件,anken`），或直接用英文标识查。 |
| 某功能的影响链缺了一块 | 见 `docs/MAINTENANCE_维护指南_给内网AI.md` 的「排错对照表」，把现象丢给内网 AI 让它改解析规则。 |

> 解析规则不可能一次覆盖所有写法。**首次在真实项目上，挑 3~5 个你很熟的功能查一遍，对照着看漏没漏、
> 多没多**，再按维护指南微调。这套工具定位是「高召回、给人/AI 复核」，不是 100% 精确的自动化。
