# 维护指南（给内网 AI / 开发者）

> 🌐 语言 / 言語：**中文**（本页） ・ [日本語](MAINTENANCE_ja.md)

> 读者：内网的 Copilot / AI 或维护者。目标：当影响链结果不对（漏连、错连、少表）时，
> 你能定位到**具体哪个文件、哪个函数、哪条正则**去改。
>
> 一句话原则：**这套工具追求"高召回"——宁可多连，不要漏连**；改规则时别为了去噪把召回改没了。
> 每条边都存了 `evidence`（触发它的原始代码片段），拿不准时先看 evidence。

---

## 1. 总体架构（三段）

```
源码 ──scan.py──▶ project.db(SQLite) ──impact.py──▶ 影响链(文本/JSON)
      扫描+解析        节点+边的关系图        关键词→BFS遍历
```

- **scanner/scan.py**：遍历源码根，按扩展名/内容分类，分派给对应解析器；解析器把结果写进 SQLite。
- **scanner/db.py**：`KnowledgeDB` 封装建库与幂等插入（`add_file/add_node/add_edge/add_glossary`）。
- **scanner/parsers/**：三个解析器 + `common.py` 公用工具。**出问题 90% 改这里。**
- **query/impact.py**：读 `edges` 建邻接表，从关键词命中的入口节点做 BFS，输出分组报告。
- **schema.sql**：SQLite 表结构（通用图模型，节点/边的 `kind` 是自由文本，加新类型不用改表）。

---

## 2. 数据模型与"键"约定（**排错最关键的一节**）

### 表
- `files(id, path, rel_path, type)` — 每个源文件。
- `nodes(id, file_id, kind, name, fqn, line)` — 唯一约束 `UNIQUE(kind, fqn)`。
- `edges(id, src_id, dst_id, kind, evidence, line)` — 唯一约束 `UNIQUE(src_id,dst_id,kind)`。
- `glossary(term_cn, keyword_code)` — 中文/日文词 → 代码标识。

### 节点类型 `kind`
`controller` `service` `manager` `mapper_interface` `class`（类级）、
`method` `mapper_method`（方法级）、`sql` `table` `jsp_page` `url`。

### 边类型 `kind`（方向 src→dst，即"需求向下扩散"的方向）
| 边 | 含义 | 由谁产生 |
|---|---|---|
| `routes` | url → controller方法 | java_parser（@RequestMapping） |
| `renders` | controller方法 → jsp | java_parser（return "*.jsp"） |
| `forward` | controller方法 → url | java_parser（return "forward:/…"） |
| `calls` | 类→方法 / 方法→方法 / 方法→mapper_method | java_parser |
| `maps_to` | mapper_method → sql | mybatis_parser |
| `queries` | sql → table | mybatis_parser |
| `includes` | jsp → jsp | jsp_parser |
| `ajax` | jsp/js → url | jsp_parser（form action / ajax url） |

### ⭐ 跨文件能连上，全靠两边生成**相同的 `fqn`**。约定如下：

| 节点 | fqn 约定 | 生成处 |
|---|---|---|
| controller/service/manager/mapper_interface/class | **类简名**（去掉尾部 `Impl`） | `java_parser._base_type` |
| method | `类简名.方法名` | java_parser |
| mapper_method | `类型简名.方法名` | java_parser（调用点/接口方法）**和** mybatis_parser（statement id） |
| sql | `namespace简名.statementId` | mybatis_parser |
| table | `大写表名` | mybatis_parser |
| jsp_page | `文件名去扩展名`（basename） | java_parser（return）/ jsp_parser（文件本身/include） |
| url | `norm_url(路径)`（去 EL/前缀/斜杠、小写） | java_parser（route/forward）/ jsp_parser（action） |

### 三个最容易断的"对接点"（断链先查这里）
1. **Service/Manager → Repository → SQL → 表**
   依赖链：Java 里 `字段类型简名` == 调用 `.方法名()` → `mapper_method = 类型简名.方法名`；
   XML 里 `namespace 最后一段` == `<select id="方法名">` → `sql = namespace简名.方法名`，且 `maps_to` 连 mapper_method→sql。
   **要连上，必须：Java 字段类型简名 == XML namespace 最后一段，且方法名 == statement id。**
   若你项目的 XML namespace 最后一段和接口简名不一致 → 改 `mybatis_parser._simple_ns`。
2. **Controller → JSP（renders）** 和 **JSP 文件本身**：都按 **basename** 建 jsp_page。
   不同目录下同名 JSP 会**合并成一个节点**（已知限制，见第 5 节）。
3. **JSP 表单 → Controller** 和 **Controller forward → Controller**：靠 `norm_url` 两边归一成同一串。
   若 JSP 的 `action` 路径风格和 `@RequestMapping` 的 value 风格不一致 → 改 `common.norm_url` 或对应抽取正则。

---

## 3. 每个解析器改什么（含关键正则/函数名）

### scanner/parsers/common.py（公用）
- `norm_url(url)`：去 `${...}` EL、去 `forward:`/`redirect:` 前缀、去查询串、去首尾斜杠、转小写。
  **URL 两边对不上就改这里。**
- `iter_methods(content)`：用花括号配对切出每个 Java 方法体（名、行、body）。方法体没切对就改这里。
- `basename_no_ext(path)`、`line_of(text, idx)`。

### scanner/parsers/java_parser.py（Controller/Service/Manager/Repository）
| 想改的行为 | 改哪里 |
|---|---|
| 哪种类算 controller/service/manager/repository | `_classify()`（按注解 `@Controller/@Service/@Mapper` 或类名后缀） |
| 认哪些依赖字段（注入） | `_FIELD_RE`（注解可选、修饰符可选、类型后缀 `Service/Manager/Repository/Dao`，排除裸 `Mapper`） |
| `new XxxImpl()` 依赖 | `_NEW_RE` |
| 路由 URL 抽取 | `_MAPPING_RE`（@RequestMapping/@GetMapping…）+ `_link_route` |
| return 的三种语义（jsp / forward / 视图名） | `_RETURN_STR_RE` + `_link_return` |
| 调用点 `变量.方法()` → 连 service/repo | `_CALL_RE` + `_link_call`（数据层连 mapper_method，其余连 method） |
| 接口→实现归一 | `_base_type`（去尾部 `Impl`）；若你项目实现类不叫 `XxxImpl`，在这里加映射 |

### scanner/parsers/mybatis_parser.py（SQL / 表）
| 想改的行为 | 改哪里 |
|---|---|
| 认哪些语句标签 | `_STMT_TAGS = {select,insert,update,delete}` |
| namespace → 简名 | `_simple_ns` |
| 从 SQL 抽表名 | `_TABLE_RE`（`FROM|JOIN|INTO|UPDATE|DELETE FROM` 后的标识符）+ `_extract_tables` |
| 误当成表名的 SQL 关键字 | `_STOP` 集合，往里加 |
| `<include refid>` 片段 | `_collect_sql_fragments` + `_statement_text`（**只在同一 XML 内解析**） |
- 抽表**不用前缀白名单**：表名有 `TB###/MA###/MB###/WA###/IAC_*` 等多种，一律抽 FROM/JOIN/INTO 后的标识符。
- DOCTYPE 会被 `_DOCTYPE_RE` 去掉（避免离线拉外部 DTD）。动态标签 `<where>/<if>/<foreach>/<trim>` 和 `<![CDATA[]]>` 由 `itertext()` 自动展平，无需特殊处理。

### scanner/parsers/jsp_parser.py（页面 / include / 表单）
| 想改的行为 | 改哪里 |
|---|---|
| `<jsp:include>` / `<%@ include%>` | `_INCLUDE_RE` |
| 表单/链接 URL（`<wo:form action>`、`<form action>`、`<a href>`） | `_ACTION_RE`（EL 由 norm_url 去掉） |
| JS 里的 ajax url | `_AJAX_RE` |

---

## 4. impact.py 查询逻辑（结果不对但解析没问题时看这里）

- `resolve_keywords(query)`：把输入拆成关键词 = 英文/数字片段 + `glossary` 里 `term_cn` 是输入子串的 `keyword_code`。
  **中文查不到 → 多半是 glossary 缺词。**
- `entry_nodes(keywords)`：对每个关键词 `LIKE %kw%` 匹配 `nodes.name / nodes.fqn / files.rel_path`，得到入口节点集。
- `bfs_forward(start)`：沿 `FORWARD_KINDS`（routes/renders/calls/maps_to/queries/includes/ajax/forward）向下遍历，得完整影响链。
- `bfs_undirected(表节点, block_kind="table")`：从命中的表**无向**扩散、排除正向集，得"共用这些表的其它模块"。
  `block_kind="table"` 让扩散不经由"表"再跳到无关模块；`--shared-depth` 控制深度。
- `build_report`：把结果按 页面/Java/MyBatis/SQL/表/共用模块 分组。"影响 Java"只列**类级**节点（`JAVA_CLASS_KINDS`），方法只参与遍历不单列。

---

## 5. 已知限制与如何扩展（结果有系统性缺口时对照）

| 限制 | 现象 | 怎么扩展 |
|---|---|---|
| **逗号连接** `FROM A, B, C` 只抽到 A | 少表 | 改 `mybatis_parser._extract_tables`：对 `FROM` 后到 `WHERE/GROUP/ORDER/JOIN` 之间按逗号切分再逐个抽表 |
| **跨文件 `<include>`** 片段不解析 | 引用别的 XML 的 `<sql>` 片段时可能少表 | 在 mybatis_parser 里预扫全项目所有 `<sql id>` 建全局片段表，再在 `_statement_text` 里跨文件解析 refid |
| **注解式 SQL**（接口方法上 `@Select("…")`）不解析 | 该 Repository 无 sql/表 | 在 java_parser 里对 `@Select/@Insert/@Update/@Delete("…")` 抽 SQL 文本，复用表名正则建 sql/queries |
| **接口→实现**靠去 `Impl` 后缀 | 实现类不叫 `XxxImpl` 时断链 | 改 `_base_type` 或在 `_classify` 后加自定义映射 |
| **同名 JSP** 不同目录合并 | 页面数偏少/串味 | 把 jsp_page 的 fqn 从 basename 改成相对视图根的完整路径（两处：java 的 `_link_return`、jsp 的文件登记与 include，需同步改） |
| **动态视图名**（`return 变量`）不解析 | 少 render 边 | 弱链路，一般靠 `jsp→url→controller` 兜底；必要时按约定补规则 |
| **非 Spring 路由**（im_action/JSSP 等） | controller/url 抽不到 | 在 java_parser 的注解规则处加你项目的入口写法 |

---

## 6. 调试配方（直接查 project.db）

```bash
# 某类节点有哪些
sqlite3 project.db "select kind,name,fqn from nodes where kind='table' order by name;"

# 某节点往下连了什么（换成你的 fqn）
sqlite3 project.db "
  select e.kind, n2.kind, n2.name, e.evidence
  from nodes n1 join edges e on e.src_id=n1.id join nodes n2 on n2.id=e.dst_id
  where n1.fqn='AnkenRepository.r0001';"

# 哪些 SQL 查了某张表（queries 边的 src 就是 sql 节点）
sqlite3 project.db "
  select s.name as sql_id, s.fqn from nodes s
  join edges e on e.src_id=s.id
  join nodes t on t.id=e.dst_id
  where t.fqn='TB070_CUSTOMER' and e.kind='queries';"

# 某个 mapper_method 有没有连到 sql（maps_to 断没断）
sqlite3 project.db "select * from edges where kind='maps_to';"
```
> 排链思路：从"漏掉的终点"往回查 `edges`，一段段看断在哪个 `kind` 的边，再回到第 3 节对应的解析器修规则。

---

## 7. 改完怎么验证（回归）

```bash
# 1) 内置样例必须仍然通过（案件↔顧客双向、共用 TB070_CUSTOMER）
python scanner/scan.py --root samples --out project.db --reset
python query/impact.py "案件検索" --db project.db     # 应含 4~5 张 TB/WA 表 + a01kokyaku 共用
python query/impact.py "顧客"     --db project.db     # 反向应共用出 b01anken

# 2) 真实项目抽查
python scanner/scan.py --root <真实项目> --out real.db --reset
python query/impact.py "<你很熟的功能>" --db real.db
# 人工对照：该列的漏没漏、多列的离不离谱；据此再微调正则
```

改任何正则后，**先跑样例**确认没把已通过的链路改断，再上真实项目。样例就是回归基线。

---

## 8. 给内网 AI 的自检清单（改代码前问自己）

- [ ] 这个问题是**解析**（节点/边没建对）还是**查询**（BFS/关键词）？前者改 `parsers/`，后者改 `impact.py`。
- [ ] 断链的两端 `fqn` 长一样吗？（第 2 节的键约定）用 `sqlite3` 查两端节点确认。
- [ ] 改的正则会不会误伤已通过的样例？改完必须重跑第 7 节。
- [ ] 是不是只是 `glossary.csv` 缺词？（中文查不到时优先排除）
- [ ] 保持高召回：不确定就多连一条边（有 `evidence` 供人复核），别为去噪而漏连。
