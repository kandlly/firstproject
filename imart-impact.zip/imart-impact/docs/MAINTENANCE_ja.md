# 保守ガイド（社内 AI / 開発者向け）

> 🌐 言語 / 语言：**日本語**（本ページ） ・ [中文](MAINTENANCE_维护指南_给内网AI.md)

> 読者：社内の Copilot / AI または保守担当。目的：影響チェーンの結果が正しくない（繋がらない/誤接続/
> テーブル漏れ）とき、**どのファイル・どの関数・どの正規表現**を直せばよいか特定できるようにする。
>
> 一言原則：**本ツールは「高再現率」を狙う——漏れよりも過剰接続を優先**。ルール修正時に、ノイズ除去の
> ために再現率を潰さないこと。各エッジには `evidence`（生成元のコード断片）が保存されているので、
> 迷ったらまず evidence を見る。

---

## 1. 全体アーキテクチャ（3 段）

```
ソース ──scan.py──▶ project.db(SQLite) ──impact.py──▶ 影響チェーン(テキスト/JSON)
      走査+解析          ノード+エッジのグラフ        キーワード→BFS 探索
```

- **scanner/scan.py**：ソースルートを走査し、拡張子/内容で分類、対応パーサーへ振り分け。パーサーが SQLite に書き込む。
- **scanner/db.py**：`KnowledgeDB` が DB 初期化と冪等挿入をラップ（`add_file/add_node/add_edge/add_glossary`）。
- **scanner/parsers/**：3 つのパーサー + `common.py`。**問題の 90% はここを直す。**
- **query/impact.py**：`edges` から隣接表を作り、キーワードにヒットした入口ノードから BFS してレポートを出力。
- **schema.sql**：SQLite スキーマ（汎用グラフモデル。ノード/エッジの `kind` は自由文字列なので、新種別追加でも表変更不要）。

---

## 2. データモデルと「キー」規約（**トラブル対応で最重要**）

### テーブル
- `files(id, path, rel_path, type)` — 各ソースファイル。
- `nodes(id, file_id, kind, name, fqn, line)` — 一意制約 `UNIQUE(kind, fqn)`。
- `edges(id, src_id, dst_id, kind, evidence, line)` — 一意制約 `UNIQUE(src_id,dst_id,kind)`。
- `glossary(term_cn, keyword_code)` — 日本語/中国語語 → コード識別子。

### ノード種別 `kind`
`controller` `service` `manager` `mapper_interface` `class`（クラスレベル）、
`method` `mapper_method`（メソッドレベル）、`sql` `table` `jsp_page` `url`。

### エッジ種別 `kind`（向きは src→dst ＝「要求が下流へ波及する」向き）
| エッジ | 意味 | 生成元 |
|---|---|---|
| `routes` | url → controller メソッド | java_parser（@RequestMapping） |
| `renders` | controller メソッド → jsp | java_parser（return "*.jsp"） |
| `forward` | controller メソッド → url | java_parser（return "forward:/…"） |
| `calls` | クラス→メソッド / メソッド→メソッド / メソッド→mapper_method | java_parser |
| `maps_to` | mapper_method → sql | mybatis_parser |
| `queries` | sql → table | mybatis_parser |
| `includes` | jsp → jsp | jsp_parser |
| `ajax` | jsp/js → url | jsp_parser（form action / ajax url） |

### ⭐ 跨ファイル接続は、両側が**同じ `fqn`** を生成することで成立。規約：

| ノード | fqn 規約 | 生成箇所 |
|---|---|---|
| controller/service/manager/mapper_interface/class | **クラス短名**（末尾 `Impl` を除去） | `java_parser._base_type` |
| method | `クラス短名.メソッド名` | java_parser |
| mapper_method | `型短名.メソッド名` | java_parser（呼び出し/interface メソッド）**と** mybatis_parser（statement id） |
| sql | `namespace短名.statementId` | mybatis_parser |
| table | `大文字テーブル名` | mybatis_parser |
| jsp_page | `拡張子を除いたファイル名`（basename） | java_parser（return）/ jsp_parser（ファイル自体/include） |
| url | `norm_url(パス)`（EL/接頭辞/スラッシュ除去・小文字） | java_parser（route/forward）/ jsp_parser（action） |

### 最も切れやすい 3 つの「接合点」（切れたらまずここ）
1. **Service/Manager → Repository → SQL → テーブル**
   Java の `フィールド型短名` == 呼び出し `.メソッド名()` → `mapper_method = 型短名.メソッド名`；
   XML の `namespace の最後の要素` == `<select id="メソッド名">` → `sql = namespace短名.メソッド名`、`maps_to` が mapper_method→sql を接続。
   **繋げるには：Java フィールド型短名 == XML namespace の最後の要素、かつ メソッド名 == statement id。**
   XML namespace 最後の要素とインターフェース短名が不一致なら → `mybatis_parser._simple_ns` を修正。
2. **Controller → JSP（renders）** と **JSP ファイル本体**：どちらも **basename** で jsp_page を作る。
   別ディレクトリの同名 JSP は**1 ノードに統合される**（既知の限界。第 5 節参照）。
3. **JSP フォーム → Controller** と **Controller forward → Controller**：`norm_url` が両側を同一文字列に正規化して成立。
   JSP の `action` のパス様式と `@RequestMapping` の value の様式が違うと繋がらない → `common.norm_url` か該当抽出正規表現を修正。

---

## 3. 各パーサーの修正箇所（主な正規表現/関数名つき）

### scanner/parsers/common.py（共通）
- `norm_url(url)`：`${...}` EL、`forward:`/`redirect:` 接頭辞、クエリ、先頭末尾スラッシュを除去し小文字化。
  **URL が両側で一致しないならここ。**
- `iter_methods(content)`：波括弧の対応で各 Java メソッド本体（名・行・body）を切り出す。本体が正しく切れないならここ。
- `basename_no_ext(path)`、`line_of(text, idx)`。

### scanner/parsers/java_parser.py（Controller/Service/Manager/Repository）
| 変えたい挙動 | 修正箇所 |
|---|---|
| どのクラスを controller/service/manager/repository と見なすか | `_classify()`（注解 `@Controller/@Service/@Mapper` またはクラス名サフィックス） |
| どの依存フィールド（注入）を拾うか | `_FIELD_RE`（注解任意・修飾子任意、型サフィックス `Service/Manager/Repository/Dao`、裸 `Mapper` は除外） |
| `new XxxImpl()` 依存 | `_NEW_RE` |
| ルート URL 抽出 | `_MAPPING_RE`（@RequestMapping/@GetMapping…）+ `_link_route` |
| return の 3 用法（jsp / forward / ビュー名） | `_RETURN_STR_RE` + `_link_return` |
| 呼び出し `変数.メソッド()` → service/repo 接続 | `_CALL_RE` + `_link_call`（データ層は mapper_method、それ以外は method） |
| interface→impl の寄せ | `_base_type`（末尾 `Impl` 除去）。実装クラスが `XxxImpl` でないならここでマッピング追加 |

### scanner/parsers/mybatis_parser.py（SQL / テーブル）
| 変えたい挙動 | 修正箇所 |
|---|---|
| どの文タグを認識するか | `_STMT_TAGS = {select,insert,update,delete}` |
| namespace → 短名 | `_simple_ns` |
| SQL からテーブル名抽出 | `_TABLE_RE`（`FROM|JOIN|INTO|UPDATE|DELETE FROM` 直後の識別子）+ `_extract_tables` |
| テーブル名と誤認する SQL キーワード | `_STOP` 集合に追加 |
| `<include refid>` 断片 | `_collect_sql_fragments` + `_statement_text`（**同一 XML 内のみ解決**） |
- テーブル抽出は**接頭辞ホワイトリストを使わない**：`TB###/MA###/MB###/WA###/IAC_*` など多様。FROM/JOIN/INTO 直後の識別子を一律抽出。
- DOCTYPE は `_DOCTYPE_RE` で除去（オフラインで外部 DTD を取りに行くのを防ぐ）。動的タグ `<where>/<if>/<foreach>/<trim>` と `<![CDATA[]]>` は `itertext()` が平坦化するので特別処理不要。

### scanner/parsers/jsp_parser.py（ページ / include / フォーム）
| 変えたい挙動 | 修正箇所 |
|---|---|
| `<jsp:include>` / `<%@ include%>` | `_INCLUDE_RE` |
| フォーム/リンク URL（`<wo:form action>`、`<form action>`、`<a href>`） | `_ACTION_RE`（EL は norm_url が除去） |
| JS 内の ajax url | `_AJAX_RE` |

---

## 4. impact.py の検索ロジック（解析は正しいのに結果が変なとき）

- `resolve_keywords(query)`：入力を キーワード = 英数字トークン + `glossary` で `term_cn` が入力の部分文字列である `keyword_code` に分解。
  **日本語で出ない → 多くは glossary の語不足。**
- `entry_nodes(keywords)`：各キーワードで `LIKE %kw%` を `nodes.name / nodes.fqn / files.rel_path` に照合し入口ノード集合を得る。
- `bfs_forward(start)`：`FORWARD_KINDS`（routes/renders/calls/maps_to/queries/includes/ajax/forward）に沿って下流へ探索し、影響チェーン全体を得る。
- `bfs_undirected(テーブルノード, block_kind="table")`：ヒットしたテーブルから**無向**拡散し、正方向集合を除外して「これらのテーブルを共用する他モジュール」を得る。
  `block_kind="table"` により、テーブル経由で無関係モジュールへ跳ばない。`--shared-depth` で深さ制御。
- `build_report`：結果を ページ/Java/MyBatis/SQL/テーブル/共用モジュール に分類。「影響 Java」は**クラスレベル**ノード（`JAVA_CLASS_KINDS`）のみ列挙。メソッドは探索のみ。

---

## 5. 既知の限界と拡張方法（結果に系統的な欠落があるとき）

| 限界 | 症状 | 拡張方法 |
|---|---|---|
| **カンマ結合** `FROM A, B, C` は A しか拾わない | テーブル漏れ | `mybatis_parser._extract_tables` を改修：`FROM` 直後〜`WHERE/GROUP/ORDER/JOIN` 手前をカンマ分割し各々抽出 |
| **跨ファイル `<include>`** 断片は未解決 | 別 XML の `<sql>` 断片参照でテーブル漏れ | mybatis_parser で全プロジェクトの `<sql id>` を事前収集し全体断片表を作り、`_statement_text` で refid を跨ファイル解決 |
| **注解式 SQL**（interface メソッドの `@Select("…")`）は未解析 | その Repository に sql/テーブルが出ない | java_parser で `@Select/@Insert/@Update/@Delete("…")` の SQL 文字列を抽出し、テーブル正規表現を再利用して sql/queries を作る |
| **interface→impl** を末尾 `Impl` 除去で判定 | 実装が `XxxImpl` でないと切れる | `_base_type` を改修、または `_classify` 後に独自マッピング追加 |
| **同名 JSP** の別ディレクトリ統合 | ページ数が少なめ/混同 | jsp_page の fqn を basename からビュールート相対の完全パスに変更（2 箇所：java の `_link_return`、jsp のファイル登録と include を同時に） |
| **動的ビュー名**（`return 変数`）未解析 | render エッジ漏れ | 弱いリンク。通常は `jsp→url→controller` で補完。必要なら規約に沿って追加 |
| **非 Spring ルート**（im_action/JSSP 等） | controller/url が拾えない | java_parser の注解ルール部にプロジェクトの入口書式を追加 |

---

## 6. デバッグ手順（project.db を直接照会）

```bash
# ある種別のノード一覧
sqlite3 project.db "select kind,name,fqn from nodes where kind='table' order by name;"

# あるノードが下流に何を繋いでいるか（自分の fqn に置換）
sqlite3 project.db "
  select e.kind, n2.kind, n2.name, e.evidence
  from nodes n1 join edges e on e.src_id=n1.id join nodes n2 on n2.id=e.dst_id
  where n1.fqn='AnkenRepository.r0001';"

# あるテーブルを照会している SQL（queries エッジの src が sql ノード）
sqlite3 project.db "
  select s.name as sql_id, s.fqn from nodes s
  join edges e on e.src_id=s.id
  join nodes t on t.id=e.dst_id
  where t.fqn='TB070_CUSTOMER' and e.kind='queries';"

# ある mapper_method が sql に繋がっているか（maps_to が切れていないか）
sqlite3 project.db "select * from edges where kind='maps_to';"
```
> 追跡の考え方：「漏れた終点」から `edges` を逆に辿り、どの `kind` のエッジで切れているかを段階的に確認。
> 該当エッジから第 3 節の対応パーサーに戻ってルールを直す。

---

## 7. 修正後の検証（回帰）

```bash
# 1) 同梱サンプルが引き続き通ること（案件↔顧客の双方向、TB070_CUSTOMER 共用）
python scanner/scan.py --root samples --out project.db --reset
python query/impact.py "案件検索" --db project.db     # TB/WA テーブル 4〜5 個 + a01kokyaku 共用 が出るはず
python query/impact.py "顧客"     --db project.db     # 逆方向で b01anken が共用として出るはず

# 2) 実プロジェクトのスポットチェック
python scanner/scan.py --root <実プロジェクト> --out real.db --reset
python query/impact.py "<よく知っている機能>" --db real.db
# 目視で：漏れ/過剰を確認し、正規表現を微調整
```

正規表現を変えたら、**まずサンプルを実行**して既存の通過リンクを壊していないか確認。サンプルが回帰基線。

---

## 8. 社内 AI 用セルフチェックリスト（コード修正前に自問）

- [ ] これは**解析**（ノード/エッジが作れていない）か**検索**（BFS/キーワード）の問題か？前者は `parsers/`、後者は `impact.py`。
- [ ] 切れた両端の `fqn` は同一か？（第 2 節のキー規約）`sqlite3` で両端ノードを確認。
- [ ] 変える正規表現は既存サンプルを壊さないか？修正後は必ず第 7 節を再実行。
- [ ] 単に `glossary.csv` の語不足では？（日本語で出ないとき最優先で除外）
- [ ] 高再現率を維持：迷ったらエッジを 1 本多く張る（`evidence` があり人が確認できる）。ノイズ削減のために漏らさない。
