# 実プロジェクト構成メモ（picture/ のスクショから整理、2026-07-08〜07-11）

> スキャナ解析ルールの校正用。情報源は Eclipse の工程構成スクショ 3 バッチ（ディレクトリツリー + 実コード）。

## プラットフォームと技術スタック（確認済み）

- **intra-mart Accel Platform**（スクショに "Accel Platform Library"）、アプリケーションサーバー **Resin v4.0**。
- Spring MVC 風のレイヤー分け + MyBatis。intra-mart 独自の **JSSP**（`WEB-INF/jssp`）も別の表現層として存在。
- ソースルート：`src/main/java`；フレームワークパッケージ `jp.co.nttdata.inet.fw`；業務パッケージ `jp.(wiseoffice…)`。

## 業務モジュール（`…/wiseoffice/` 配下）

`a01kokyaku`(顧客) `b01anken`(案件) `c01keiyaku`(契約) `c02tesuuryou`
`c03manki` `c04jigyouhoukokusho` `c05kaiyaku` `c06zandaka` `i01lifeEvent`
`navi`(相談ナビ、navi01〜06 を含む) `s02smtKokyaku` `bean` `bean.entity` `fw`

## 各業務モジュール内部のレイヤー

`a01kokyaku` を例に、サブパッケージ：
```
controller / service / manager / repository(.tenant) / bean / form / constants / util
```
呼び出しチェーン：**Controller → Service(interface+Impl) → Manager → Repository → MyBatis → SQL → テーブル**
（データ層に **Manager** と **Repository** の 2 層命名がある点に注意）

## 命名規約（クラス名スクショより）

| 層 | 命名 | 例 |
|---|---|---|
| Controller | `A01XxxController` | `A01SearchKokyakuTougouController` |
| Service | interface `XxxService` + 実装 `XxxServiceImpl`（`Abstract*` 含む） | `AbstractKokyakuService` / `…Impl` |
| Repository（データ層） | `XxxRepository` interface **+ 同名 `XxxRepository.xml`** | `fw/repository/tenant/UserRepository.java` + `UserRepository.xml` |

- **データ層は Repository（Mapper/Dao ではない）** → 依存型サフィックスに `Repository` を含める。
- **MyBatis XML は Repository interface と同一パッケージに同名で並ぶ**。`namespace` は当該 Repository interface の完全修飾名。
- Service は **interface + Impl**：呼び出しチェーンで `XxxService`（interface）を `XxxServiceImpl`（実装）に寄せる必要がある。正規表現では難しく、ast-grep（要件 #1）の価値がある点。

## JSP ビュー

- 位置：`webapp/WEB-INF/views/<モジュール>/*.jsp`。`inc/` サブディレクトリに include 用断片。
- 命名：`SC_NAVI03_001_SearchDisplayListOkyakusama.jsp`、`B01_SearchAnken.jsp`、`A01…` 等（モジュール接頭 + 機能名）。
- Controller の return はビューへの完全パス（下記の請求フロー参照）。
- intra-mart **JSSP**（`WEB-INF/jssp`）——分析対象に含めるかは未定。

## 請求フロー全体像（第 2 バッチ 15 枚のコードスクショ、2026-07-11 確認）

完全なチェーン（b01anken 案件検索を例に）：
```
JSP  B01_SearchAnken.jsp
  <wo:form action="${pageContext.request.contextPath}/b01anken/searchAnkenDSP">
  <button onclick="executeXxxForward('forward_xxx')">   → JS 呼び出し
JS   B01_anken.js
  form.event.value = 'forward_xxx'; form.submit();       → POST /b01anken/searchAnkenDSP?event=forward_xxx
Controller（extends AbstractController）3 種のメソッド：
  ① DSP  @RequestMapping(value=".../searchAnkenDSP", params="event=forward_xxx")
          return "forward:/b01anken/XxxBL";              → 内部で BL へ forward
  ② BL   @RequestMapping(".../XxxBL")
          input = beanMapper.map(form, XxxBvo.class);
          BLogicResult r = xxxService.executeService(input);   ← Controller→Service
          return "forward:/b01anken/XxxSCR";（r.getResultString() で switch）
  ③ SCR  @RequestMapping(".../XxxSCR")
          return "/b01anken/Xxx.jsp";                    → JSP をレンダー（return 文字列に .jsp が付く）
Service  XxxServiceImpl
  @Service @Transactional、implements XxxService（interface は executeService(bvo) のみ）
  2 通りの書き方：executeService() を直接実装 / extends AbstractNaviServiceImpl<Bvo> で executeLogic() を override
  依存取得：@Inject Manager / @Inject Repository / new XxxImpl() も
Manager → Repository → MyBatis(XxxRepository.xml, namespace=Repository interface) → SQL → テーブル
```

### 校正ポイント（解析ルールに必ず反映）

- **インジェクション注解は `@Inject`（JSR-330）、@Autowired ではない**。フィールド名≠型名（例 `DisplayAnkenIchiranService displayAnkenIchiranBLogic`）なので、変数→型でマッピング。**アクセス修飾子なしの @Inject フィールドもある**（例 `@Inject NAVI05MasterRepository nAVI05MasterRepository;`）ので修飾子は任意扱い。
- **依存型サフィックス**：データ/業務層は `Service` / `Manager` / `Repository`（**Mapper/Dao ではない**）。
- **裸の `Mapper` 型は除外**：`@Inject private Mapper beanMapper;` は Dozer 系の Bean コピー（`beanMapper.map(form, Xxx.class)`）であり **MyBatis ではない**。データアクセス扱いしない。
- **ジェネリクス**：`DepartmentManager<UserValueObject> departmentManager` —— フィールド正規表現は `<...>` をスキップできること。
- **`new XxxImpl()` の直接インスタンス化**も依存エッジ（例 `ExcelOperationManagerImpl x = new ExcelOperationManagerImpl();`）。@Inject だけ見ると漏れる。
- **Service の入口は 2 通り**：`executeService()`（直接実装）または `executeLogic()`（`AbstractNaviServiceImpl` を継承するテンプレートメソッド）——両方をその Service の業務入口として扱う。
- **Controller の `return` 3 用法**：
  - `".../Xxx.jsp"` → JSP レンダー（.jsp サフィックス付き、`WEB-INF/views` 相対の完全パス。ファイル名一致より確実）。
  - `"forward:/モジュール/XxxBL"` / `"forward:/モジュール/XxxSCR"` → 別 URL エンドポイントへ転送（routes エッジ）。
  - `getNaviErrorPage(...)` 等 → エラーページ。
- **DSP の振り分けは `params="event=forward_xxx"`**。JSP ボタン `onclick`/`name="forward_xxx"` + JS `form.event.value=...` で発火。JSP→Controller のエッジは `<wo:form action="...">` と event 値を認識。
- **JSP タグ**：intra-mart `<wo:form>` `<im:imAuthz uri="service://...">` `<imui:head>` + Spring `<form:hidden>` `<spring:message>` + JSTL `<c:if>`；include は `<jsp:include page="../commonGyomuHeader.jsp">`（相対）や `/WEB-INF/views/common/message.jsp`（絶対）。
- **認可の関連**（任意）：Controller `@Authz(uri="service://searchAnkenExe")` ↔ JSP `<im:imAuthz uri="service://...">`。
- パッケージ構成：`jp.wiseoffice.<モジュール>.{controller,service,manager,bean,form,constants,util}`；フレームワーク `jp.wiseoffice.fw.blogic.BLogicResult`。

## データ側後半（第 3 バッチ 14 枚の SQL スクショ、2026-07-11 確認）

チェーン接続：`Service → Manager → Repository → MyBatis XML → SQL → テーブル`

- **Manager Impl**（例 `YoukenHanteiManagerImpl`）：`@Inject private SharedFwRepository sharedFwRepository;`、メソッド内 `sharedFwRepository.selectYoukenHantei(searchMA270)` で Repository を呼ぶ。Manager は Service から直接 `@Inject` される場合もある。
- **Repository interface**：
  - 位置：`fw/repository/{shared,tenant}/*.java`（フレームワーク級）と `<モジュール>/repository/{shared,tenant}/*.java`（業務級）。各 `XxxRepository.java` の**隣に同名 `XxxRepository.xml`**。
  - `@Mapper`：**業務級 Repository には `@Mapper` あり**（例 `AnkenRepository`）；**fw 級には無し**（例 `SharedUserRepository`）。→ mapper interface 判定は「`@Mapper` 注解 **または** 名前が `Repository` で終わる **または** ある XML namespace から参照される」の和集合。
  - **メソッド名 == XML の statement id**（Javadoc に `sqlID "xxx" を実行する` と明記）。id は**コード**（`r0001`/`r0002`=参照系、`i0002`/`i0003`=更新系）の場合も、記述的な名前（`selectUserSchemaName`）の場合もある。→ id から業務を推測しない。グラフ探索で辿ればよい。
  - **メソッドのオーバーロード**：`r0001(Map)` と `r0001(Map, RowBounds)` は同一 sqlID を共用 → `Repository.メソッド名` で 1 つの mapper_method ノードに重複排除。
- **MyBatis XML**：標準的な書式。`<mapper namespace="jp.wiseoffice.<...>.XxxRepository">`；`<select|insert|update|delete id="...">`；namespace 短名 == Repository interface 短名 → java 側の `Type.method` と自動で接続（既存パーサーのキー設計は正しい）。
- **SQL の複雑さ（すべて itertext + FROM/JOIN/INTO 正規表現でカバー可能）**：
  - サブクエリ `SELECT * FROM (SELECT ...)`、`INNER/RIGHT OUTER/LEFT JOIN`、`EXISTS (...)`、`INSERT INTO ... SELECT`。
  - 動的タグ `<where> <if> <foreach> <trim>`；`<![CDATA[<=]]>` で比較演算子を囲む；`${item.columnName}` 動的カラム。
  - **Oracle 方言**（`ROW_NUMBER() OVER`、`TO_MULTI_BYTE`、`UTL_I18N.TRANSLITERATE`、`TRANSLATE`）→ DB は Oracle。
- **テーブル名の規則**：`TB###_*`(トランザクション) `MA###_*`/`MB###_*`(マスタ) `WA###_*`(ワーク/一時) **`IAC_*`(intra-mart フレームワークのコアテーブル)** 等。→ **テーブル抽出に接頭辞ホワイトリストは厳禁**。`FROM|JOIN|INTO|UPDATE|DELETE FROM` 直後の識別子を一律抽出。
- **エンティティクラス ≈ テーブル名**：`jp.wiseoffice.bean.entity.TB520_Anken_Related_Info`、`MA270_YoukenHantei`、`TB450_Anken_Market` —— エンティティクラス名がそのままテーブル名。Java↔テーブルの補助手掛かりに使える。

## 進捗と残課題

全チェーンを実コードで検証済み（JSP→JS→Controller→Service→Manager→Repository→MyBatis→SQL→テーブル）。これに基づき「校正版」スキャナを実装済み。

残（主チェーンはブロックしない）：
- **batch（要件 #2、保留中）**：batch は `wiseofficeplus/wiseofficeplus_batch/`（`wiseoffice` の外）にある。何をもって batch と判定するか、実 `.java` 1 本が必要。
