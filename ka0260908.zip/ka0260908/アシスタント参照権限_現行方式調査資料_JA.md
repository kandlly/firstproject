# アシスタント参照権限 機能追加 ─ 現行方式調査資料

| 項目 | 内容 |
|---|---|
| 文書名 | アシスタント参照権限 機能追加 現行方式調査資料 |
| 版数 | Rev. 1.0 |
| 作成日 | 2026-09-07 |
| 位置づけ | **実コードおよび客先資料から確認した「現状こうなっている」という事実のみ**をまとめた資料。方式の提案・判断は含まない |
| 関連資料 | `アシスタント参照権限_要件実現方針書`（大方針）／`アシスタント参照権限_基本設計検討資料`（実現方式の比較） |

> **本書の性格**
> 本書には**提案を書かない。** 実コードで確認できた事実と、客先資料に書かれている内容だけを記載する。
> 方式の検討・比較は `アシスタント参照権限_基本設計検討資料` を参照すること。
> 事実には参照元（ファイル名・行番号・スライド番号）を必ず明記する。

---

## 1. 権限の2層構造 ─ 本改修の前提

現行システムの権限は、**まったく別の2つの機構**で構成されている。

| 層 | 対象 | 実装 |
|---|---|---|
| **機能実行権限** | 「その画面・処理を実行してよいか」 | intra-mart の認可機構。controller メソッドに `@Authz(uri="service://kokyakuRegExe", action="execute")` を付与（`A01RegistUpdateKojinKokyakuController.java:358`） |
| **データ参照権限** | 「どのデータが見えるか」 | 独自実装。`DataAccessAuthCheck` ＋ mapper XML の参照権限条件 |

---

## 2. 権限情報の流れ（実コード確認済み）

| フェーズ | 処理 | ファイル：行 | 内容 |
|---|---|---|---|
| ログイン | ユーザ情報取得 | `UserContextFilter.java:217` | intra-mart の `AccountContext` から `groupId` / `userCd` を取得 |
| ログイン | UVO 組み立て | `UserManagerImpl.java:675` | `dataAccessAuthChek` をセット |
| ログイン | UVO 組み立て | `UserManagerImpl.java:1072` | `accountRoleAll` をセット |
| ログイン | session 格納 | `UserContextFilter.java` | `session.setAttribute(UserValueObject.USER_VALUE_OBJECT_KEY, uvo)` |
| ログイン | 補位 | `UserImartFilter.java` | user 情報が無い場合に空の UVO を詰め、後続のヌルポインタを防ぐ |
| 検索系 | 顧客契約一覧 | `Z99SearchBaseController.java:649` | session から UVO を取得し `SearchCommonBean` に詰める |
| 検索系 | 契約一覧 | `Z99SearchBaseController.java:728` | 同上 |
| 検索系 | 顧客一覧 | `Z99SearchBaseController.java:2777` | 同上 |
| 検索系 | 参照権限判定 | `AbstractSearchCommonService.java:1418〜` | `new DataAccessAuthCheck(uvo)` → mapper XML の参照権限条件で WHERE 句を注入 |
| 更新系 | 機能権限判定 | `A01RegistUpdateKojinKokyakuController.java:358` | `@Authz(uri="service://kokyakuRegExe", action="execute")` |
| 更新系 | UVO 受け渡し | `A01RegistUpdateKojinKokyakuController.java:550` | session の UVO を `RegistUpdateBvo` に渡す |
| 更新系 | 業務処理 | `UpdateKojinKokyakuServiceImpl.java:94〜` | `getUvo().getDairitenCd()` / `userCd` を利用。**このサービス内で権限を再計算はしていない** |
| 更新系 | 排他チェック | `UpdateKojinKokyakuServiceImpl.java:102` | 更新前の排他チェック |

### 図示

```
ログイン
  └ UserContextFilter.java:217（AccountContext → groupId / userCd）
      └ UserManagerImpl（:675 dataAccessAuthChek / :1072 accountRoleAll）
          └ UserValueObject を session（USER_VALUE_OBJECT_KEY）に保存
                ├─ 検索系：Z99SearchBaseController（:649 / :728 / :2777）
                │    └ SearchCommonBean に UVO を詰める
                │       └ AbstractSearchCommonService:1418〜  new DataAccessAuthCheck(uvo)
                │          └ mapper XML の参照権限条件で WHERE 句を注入
                └─ 更新系：A01RegistUpdateKojinKokyakuController:358 @Authz
                     └ :550 RegistUpdateBvo に UVO
                        └ UpdateKojinKokyakuServiceImpl:94〜（dairitenCd / userCd）
                           └ :102 排他チェック
```

---

## 3. データ参照ロール（`DataAccessAuthCheck.java` L48〜L68）

| 定数 | ロールID | 意味 | mapper での条件 |
|---|---|---|---|
| `USER_AUTH_TANTOSYA_ACCESS` | `tantosyaAccess` | 担当者情報参照権限 | `USER_CD_1 = #{userCd} OR USER_CD_2 = #{userCd}` |
| `USER_AUTH_SAME_ACCESS` | `sameAccess` | 同階層情報参照権限 | `VI001_USER_SAME` 経由 |
| `USER_AUTH_UNDER_ACCESS` | `underAccess` | 下階層情報参照権限 | `VI002_USER_UNDER` 経由 |
| `USER_AUTH_SAME_UNDER_ACCESS` | `sameUnderAccess` | 同下階層情報参照権限 | `VI003_USER_SAME_UNDER` 経由 |
| `USER_AUTH_ALL_ACCESS` | `allAccess` | 全情報参照権限 | 対応する `<if>` なし＝条件を出さない＝全件 |

### その他の定数（L33〜L43）

| 定数 | 値 | 意味 |
|---|---|---|
| `DATA_ACCESS_AUTH_CHECK_ON` | `"1"` | 参照権限設定：有効 |
| `DATA_ACCESS_AUTH_CHECK_OFF` | `"0"` | 参照権限設定：無効 |
| `DATA_ACCESS_AUTH_CHECK_ERROR` | `"errors.data.access.auth.check…"` | 権限が存在しない場合のエラーメッセージキー |

---

## 4. 参照権限の優先順位と判定ロジック

### 4.1 優先順位定義（L73〜L79）

```java
/** 情報参照権限優先順位 */
public static final String[][] USER_AUTH_LEVEL = {
    {USER_AUTH_ALL_ACCESS,        "5"},
    {USER_AUTH_SAME_UNDER_ACCESS, "4"},
    {USER_AUTH_UNDER_ACCESS,      "3"},
    {USER_AUTH_SAME_ACCESS,       "2"},
    {USER_AUTH_TANTOSYA_ACCESS,   "1"}
};
```

| ロールID | 優先度 |
|---|---|
| `allAccess` | 5 |
| `sameUnderAccess` | 4 |
| `underAccess` | 3 |
| `sameAccess` | 2 |
| `tantosyaAccess` | 1 |

### 4.2 フィールド（L84〜L94）

```java
/** ユーザ情報 */
private UserValueObject uvo = null;
/** ユーザが保持しているアクセス可能データのロールID */
private String roleId = null;
/** データ参照権限なしフラグ */
private boolean noAccessAuth = false;
```

### 4.3 コンストラクタ（L103〜L144）

```java
public DataAccessAuthCheck(UserValueObject uvo) {
    this.uvo = uvo;

    // ログインユーザの権限配列を取得
    AccountRoleInfo[] roles = this.uvo.getAccountRoleAll();

    // 情報参照権限優先度の設定
    Map<String, Integer> levelMap = new HashMap<String, Integer>();
    for (int i = 0; i < USER_AUTH_LEVEL.length; i++) {
        levelMap.put(USER_AUTH_LEVEL[i][0], Integer.parseInt(USER_AUTH_LEVEL[i][1]));
    }

    int level = -1;
    this.noAccessAuth = false;

    // 権限配列に参照権限がある判定する
    for (AccountRoleInfo role : roles) {
        String roleId = role.getRoleId();

        if (StringUtils.equals(USER_AUTH_TANTOSYA_ACCESS,   roleId)
         || StringUtils.equals(USER_AUTH_SAME_ACCESS,       roleId)
         || StringUtils.equals(USER_AUTH_UNDER_ACCESS,      roleId)
         || StringUtils.equals(USER_AUTH_SAME_UNDER_ACCESS, roleId)
         || StringUtils.equals(USER_AUTH_ALL_ACCESS,        roleId)) {
            this.noAccessAuth = true;

            int roleLevel = levelMap.get(roleId);

            if (level < roleLevel) {
                // 取得したロールの優先度が高い場合設定
                this.roleId = roleId;
                level = roleLevel;
            }
        }
    }
}
```

### 4.4 ★押さえるべき2つの事実

> **事実1：実効参照範囲は「ロールの和」ではなく「優先度の最大値1つ」である。**
> `accountRoleAll` を走査し、`if (level < roleLevel) { this.roleId = roleId; level = roleLevel; }` により、
> **優先度が最も高いロールID 1つだけ**を保持する。最終的に mapper へ渡るのは1つの `roleId` のみ。

> **事実2：`noAccessAuth` はフィールド名と意味が逆である。**
> コメントは「データ参照権限なしフラグ」だが、実装は「**権限が存在した場合に `true`**」。
> 改修時の誤読事故を防ぐため、この点は常に意識すること。

---

## 5. mapper XML の参照権限条件

`KokyakuRepo*.xml` / `KeiyakuRepo*.xml`（5340〜5382行付近）

```xml
<!-- ============================== -->
<!-- 参照権限条件                    -->
<!-- ============================== -->
<if test="user_auth_role_id == user_auth_tantosya_access">AND
    (USER_CD_1 = #{userCd} OR USER_CD_2 = #{userCd})
</if>
<if test="user_auth_role_id == user_auth_same_access">AND
    (
        USER_CD_1 IN (SELECT V01.ACCESS_USER_CD
                        FROM VI001_USER_SAME V01
                       WHERE V01.USER_CD = #{userCd} )
    OR  USER_CD_2 IN (SELECT V01.ACCESS_USER_CD
                        FROM VI001_USER_SAME V01
                       WHERE V01.USER_CD = #{userCd} )
    )
</if>
<if test="user_auth_role_id == user_auth_under_access">AND
    (
        USER_CD_1 IN (SELECT V02.ACCESS_USER_CD
                        FROM VI002_USER_UNDER V02
                       WHERE V02.USER_CD = #{userCd} )
    OR  USER_CD_2 IN (SELECT V02.ACCESS_USER_CD
                        FROM VI002_USER_UNDER V02
                       WHERE V02.USER_CD = #{userCd} )
    )
</if>
<if test="user_auth_role_id == user_auth_same_under_access">AND
    (
        USER_CD_1 IN (SELECT V03.ACCESS_USER_CD
                        FROM VI003_USER_SAME_UNDER V03
                       WHERE V03.USER_CD = #{userCd} )
    OR  USER_CD_2 IN (SELECT V03.ACCESS_USER_CD
                        FROM VI003_USER_SAME_UNDER V03
                       WHERE V03.USER_CD = #{userCd} )
    )
</if>
<if test="rownum != null and rownum != ''">AND
    ROWNUM <![CDATA[<=]]> #{rownum}
</if>
</where>
<!-- ============================== -->
<!-- ソート条件あり                  -->
```

### 読み取れる5つの事実

| # | 事実 |
|---|---|
| 1 | 参照権限は**行レベルの WHERE 条件**として注入される（ゲート方式ではない） |
| 2 | 担当者列は **`USER_CD_1` / `USER_CD_2` の2本**で、OR 判定 |
| 3 | 階層系の範囲は**ビュー**（`VI001_USER_SAME` / `VI002_USER_UNDER` / `VI003_USER_SAME_UNDER`）で `USER_CD → ACCESS_USER_CD` に展開されている |
| 4 | `allAccess` に対応する `<if>` は存在しない＝条件を出さない＝全件 |
| 5 | `<if>` は `user_auth_role_id` の一致で**排他的に1つだけ**成立する（`user_auth_role_id` は1つの値であるため） |

---

## 6. `UserValueObject` の構造

session に `USER_VALUE_OBJECT_KEY = "USER_VALUE_OBJECT"` で格納される。

### 6.1 主要フィールド

| 行 | フィールド | 意味 | 備考 |
|---|---|---|---|
| L57 | `serialVersionUID` | ─ | 明示的に宣言されている |
| L63 | `USER_VALUE_OBJECT_PROP_KEY` | 継承クラス指定キー | ─ |
| L69 | `USER_VALUE_OBJECT_KEY` | session 取得キー | `"USER_VALUE_OBJECT"` |
| L74 | `String sessionDir` | セッションディレクトリ | ─ |
| L79 | `AccountInfo accountInfo` | intra-mart アカウント情報 | ─ |
| L84 | `AccountRoleInfo[] accountRole` | intra-mart アカウントロール情報 | ─ |
| **L89** | **`AccountRoleInfo[] accountRoleAll`** | **すべての** intra-mart アカウントロール情報（サブロールも含む） | **`DataAccessAuthCheck` が参照するのはこちら** |
| L94 | `DepartmentInfo mainCompany` | メイン所属会社 | ─ |
| L99 | `DepartmentInfo mainDepartment` | メイン所属部署 | ─ |
| L104 | `List<DepartmentInfo> departmentList` | 所属部署リスト | **兼務がここに現れる** |
| L109 | `transient User userInfo` | intra-mart ユーザ情報 | `transient` |
| L114 | `SerializableUser userForSerializable` | シリアライズ用の独自格納領域 | ─ |
| L266 | `String dairitenCd` | 代理店コード | maxlength=20 |
| L275 | `String groupId` | グループID | maxlength=50 |
| L285 | `String userCd` | ユーザコード | maxlength=13 |
| L293 | `String gwid` | 共同GW利用ID | maxlength=32 |
| L298 | `String reCertiryKbn` | パスワード認証有無 | ─ |
| **L306** | **`String seihoBoshuninCd`** | **生保募集人コード** | maxlength=13。**「募集人」の概念は既にユーザマスタ側に存在する** |
| L325 | `String pdfPassword` | 帳票パスワード | ─ |
| L432 | `String userType` | ユーザタイプ | maxlength=20 |
| **L437** | **`String dataAccessAuthChek`** | **参照権限設定** | `"1"` / `"0"`。**※綴りは `Chek`** |
| L442 | `String sessionId` | セッションID | ─ |
| L447 | `String schemaName` | スキーマ名 | ─ |
| L452 | `String updateTimestamp` | 更新日時 | ─ |
| L457 | `String programId` | プログラムID | ─ |
| L462 | `String hihyouji_Flg` | 非表示フラグ | ─ |
| L467 | `String operatorId` | 操作者ID | ─ |

### 6.2 ★2つの注意事項

> **注意1：UVO は同時に画面 Form でもある。**
> クラスに `@FormNonEdiableClass` が付与され、各フィールドに
> `@Required` / `@MaxLength` / `@HankakuString` / `@StdChar` が
> `groups = { DairitenUserMasterForm.W02gyoumuMasterDairitenUserMasterRegistUpdate.class }`
> 付きで宣言されている。すなわち UVO は**代理店ユーザマスタ登録更新画面の入力チェック定義を兼ねている。**
> UVO にフィールドを追加する場合、この画面への影響を必ず確認すること。

> **注意2：`writeObject` / `readObject` を手書きしている**（L121〜L257）。
> `userInfo` が `transient` のため、`SerializableUser` に手動で詰め替えている。
> 通常フィールドは `defaultWriteObject` に乗るが、UVO を触る際はこの2メソッドを壊さないこと。

---

## 7. 現行の課題の技術的な所在

アシスタントに `sameAccess` を付与している
→ `DataAccessAuthCheck` が `roleId = "sameAccess"` を選ぶ
→ mapper で `VI001_USER_SAME` 経由の条件が出る
→ 同階層の全担当者のデータが見える。

> **つまり課題は「アシスタント専用の参照範囲という概念が存在しない」ことに尽きる。**
> 既存の5ロールはいずれも**「組織階層」で範囲を決めており**、
> 「特定個人との紐付け」で範囲を決める仕組みが無い。

---

## 8. 利用パターン別 可否マトリクス（客先資料 要望PPT P3〜P7）

> 本章は**客先資料に記載されている内容**であり、実コードの調査結果ではない。

### 8.1 4つのパターン

| パターン | 募集人 | アシスタント | 内容 |
|---|---|---|---|
| パターン1 | 単体 | 単体 | 募集人1名に対し、専属アシスタント1名が担当 |
| パターン2 | 単体 | 複数 | 募集人1名に対し、複数名の専属アシスタントが担当 |
| パターン3 | 複数 | 単体 | アシスタント1名が複数名の募集人を担当 |
| パターン4 | 複数 | 複数 | アシスタント複数名が、複数名の募集人を担当（同部署内をお互い全部担当する等） |

→ **募集人とアシスタントは多対多。**

### 8.2 パターン1：募集人A ／ アシスタントX（Aのアシスタント）

| データの担当者 | X の可否 | 備考 |
|---|---|---|
| A | ○ | 紐付けあり |
| B | × | 紐付けなし（Aさんから見えるかはAの参照権限次第） |
| C | × | 紐付けなし（同上） |
| X（自身） | ○ | アシスタント自身が募集人の場合（BR-03） |

**要望PPT P4 吹き出し**
- 「アシスタント専用に新設するロールは『担当者情報参照権限』相当で考えているため、「担当者」欄にAさんが指定されていなければXさんは参照不可。」
- 「現状、アシスタントに同階層情報参照権限などを与えてしまっているため、他担当者の契約・顧客情報が見えてしまう。**→本機能追加により参照不可とする。**」
- 「自身が募集人である場合も考慮が必要。」

### 8.3 パターン2：募集人A ／ アシスタントX・Y（両名ともAのアシスタント）

| データの担当者 | X | Y | 備考 |
|---|---|---|---|
| A | ○ | ○ | 中間テーブルに A-X / A-Y の2行 |
| B | × | × | ─ |
| C | × | × | ─ |
| X | ○（自身） | **×** | ★Y から見た「担当者X」は参照不可 |

**要望PPT P5 吹き出し**
- 「設定次第で担当者Xの顧客・契約データは参照可能だが、**アシスタントには基本的に、新設する参照ロール以外の参照ロールは付与しない思想**のため、参照不可となる想定。」

### 8.4 パターン3：アシスタントX（A兼B兼Dのアシスタント）／ Dは大阪支店

| データの担当者 | X の可否 | 備考 |
|---|---|---|
| A（東京） | ○ | ─ |
| B（東京） | ○ | ─ |
| C（東京） | × | ─ |
| X（自身） | ○ | ─ |
| D（大阪） | ○ | ★部署跨ぎ（BR-05） |

**要望PPT P6 吹き出し**
- 「**Xさんは大阪支店に所属が無くとも、「アシスタント設定画面」にて大阪支店Dさんのアシスタントとして指定されていれば参照可能とする**」

### 8.5 パターン4：アシスタントX（A兼B兼D）／ アシスタントY（A兼B）

| データの担当者 | X | Y | 備考 |
|---|---|---|---|
| A | ○ | ○ | ─ |
| B | ○ | ○ | ─ |
| C | × | × | ─ |
| X | ○（自身） | × | ─ |
| D | ○ | × | 中間テーブルに X-D の行のみ存在 |

---

## 9. 調査でまだ確認できていない事項

> 本書は「確認できた事実」のみを記載する方針のため、未確認事項はここに明示する。
> 詳細は `アシスタント参照権限_基本設計検討資料` 第8章を参照。

| # | 未確認事項 |
|---|---|
| 1 | 「参照権限条件」ブロックを持つ mapper XML の**本数と一覧**（確認できているのは `KokyakuRepo*.xml` / `KeiyakuRepo*.xml` の2本のみ） |
| 2 | `VI001_USER_SAME` / `VI002_USER_UNDER` / `VI003_USER_SAME_UNDER` の **DDL 定義** |
| 3 | `USER_CD_1` / `USER_CD_2` の**意味の違い**（主担当／副担当 等） |
| 4 | `seihoBoshuninCd`（L306）と `USER_CD_1` / `USER_CD_2` の**関係** |
| 5 | `USER_AUTH_LEVEL` の数値を**参照している箇所が他に無いか** |
| 6 | 契約データの**保険種目（生保／損保）を判定するカラム** |
| 7 | 明細（単票）画面に**個別の参照権限チェックがあるか** |
| 8 | 更新系処理に**担当者ベースの参照範囲チェックがあるか**（確認できているのは `@Authz` ＋ `dairitenCd` ＋ 排他チェックのみ） |
| 9 | `dataAccessAuthChek`（L437）が **OFF（`"0"`）の場合の挙動** |
| 10 | `DataAccessAuthCheck` から DAO / Mapper / SqlSession を**利用できるか**（DI されているか） |
| 11 | `new DataAccessAuthCheck(uvo)` の**生成箇所が何箇所あるか** |

---

## 10. 調査に使用した資料

| 資料 | 内容 |
|---|---|
| `DataAccessAuthCheck.java`（$Revision: 1.2 $） | データ参照権限の判定クラス |
| `UserValueObject.java` | セッション格納ユーザ情報。画面 Form を兼ねる |
| `KokyakuRepo*.xml` / `KeiyakuRepo*.xml` | 参照権限条件を含む mapper |
| `UserContextFilter.java` / `UserImartFilter.java` / `UserManagerImpl.java` | ログイン時の UVO 構築 |
| `Z99SearchBaseController.java` / `AbstractSearchCommonService.java` | 検索系の共通処理 |
| `A01RegistUpdateKojinKokyakuController.java` / `UpdateKojinKokyakuServiceImpl.java` | 更新系の処理 |
| 要望PPT（P1〜P8） | 客先要望、検討事項、利用パターン1〜4、アシスタント設定画面イメージ |
| `アシスタント参照権限_検討資料.md` | 客先作成の業務要件整理（全175行） |
| `既存権限ロール権限管理.md` | 現行実装の調査メモ |
